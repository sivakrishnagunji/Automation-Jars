assignRequestHeaders = function assignRequestHeaders() {
    try {
            var signedJWTFromCache = context.getVariable("signedJWTFromCache");
            var unsignedJWTFromCache = context.getVariable("unsignedJWTFromCache");
            var signedJWTFromCallout = context.getVariable("signedJWT.content");
            var unsignedJWT = context.getVariable("unsignedJWT");
            
            //context.setVariable();
            if (signedJWTFromCache && !(signedJWTFromCallout)){
                context.setVariable("request.header.X-JWT-Assertion", signedJWTFromCache);
            } else {
                context.setVariable("request.header.X-JWT-Assertion", signedJWTFromCallout);
            }
            if (unsignedJWTFromCache && !(unsignedJWT)){
                context.setVariable("request.header.XX-JWT-Assertion", unsignedJWTFromCache);
            } else {
                context.setVariable("request.header.XX-JWT-Assertion", unsignedJWT);
            }
            
    } catch(err){
        throw err;
    }
};