try { 
    assignRequestHeaders();
} catch(err) {
    throw err;
}