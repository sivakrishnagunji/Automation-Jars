try {
 
	logger(); // eslint-disable-line no-undef
} catch (err){
	throw err;
}