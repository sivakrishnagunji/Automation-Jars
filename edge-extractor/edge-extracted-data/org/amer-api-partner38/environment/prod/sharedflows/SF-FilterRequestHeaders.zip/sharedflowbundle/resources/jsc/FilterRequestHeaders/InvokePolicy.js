try {
	filterRequestHeaders();
} catch (err) {
	throw err;
}