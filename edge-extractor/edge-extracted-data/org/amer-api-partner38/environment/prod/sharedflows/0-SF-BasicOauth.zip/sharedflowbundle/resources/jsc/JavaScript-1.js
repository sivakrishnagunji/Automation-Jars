 var app_client_secret = context.getVariable('verifyapikey.Verify-API-Key-1.client_secret')
 var req_client_secret = context.getVariable('client_secret')
 
 if(!(app_client_secret === req_client_secret)){
     context.setVariable("triggerError", "true");
 }
