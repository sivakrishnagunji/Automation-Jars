generateLogContent = function generateLogContent() {
	try {
		var severity = "INFO";
		var logLevel = "Info";
		var loggingPayloadEnabled = context.getVariable("logging_payload_enabled") || false;
		var logger = "uk.co.virginmedia.logger";
		var thread = "[ApigeeRuntime]";

		if (loggingPayloadEnabled === true) {
			severity = "DEBUG";
			logLevel = "Debug";
		}

		var requestUri = context.getVariable("request.uri");
		var queryParamsToMask = context.getVariable("query_params_to_mask");
		var formParam = context.getVariable("message.formparams.names");
		var formParamsToMask = context.getVariable("form_params_to_mask");

		if (queryParamsToMask !== "" && queryParamsToMask !== null) {
			var maskedRequestUri = maskQueryParam(queryParamsToMask, requestUri);
		}

		// var flow = context.flow;
		var flow = context.getVariable("logFlow");
		if(context.getVariable("ContextFlowFlag")=="true")
		{
			flow = "ERROR";
		}
		
		if(formParam !== null) {
			var fparam = {};
			var formparamstr = formParam.toString();
			formparamstr = formparamstr.replace("[",""); formparamstr = formparamstr.replace("]",""); formparamstr = formparamstr.replace(" ", "");
			
			var formparamArray = formparamstr.split(",");
			for(var x=0; x<formparamArray.length; x++) {
				var ParamValue = context.getVariable("request.formparam."+formparamArray[x]+".values")+"";
				ParamValue = ParamValue.substr(1, ParamValue.length - 2);
				ParamValue = ParamValue.replace(/[\\]/g,'\\\\').replace(/["]/g, '\\"');
				fparam[formparamArray[x]] = ParamValue; 
			}
		}

		var logContent = {};
		var logContentMessage = logContent.message = {};
		var logContentProperties = logContent.properties = {};
		var date = new Date();
		var dateForLog = date.toISOString();
		var correlationId = context.getVariable("request.header.mwh-correlationid") || context.getVariable("mwCorrelationId");
		
		var headersToMask =  context.getVariable("headers_to_mask");
		var headerList = context.getVariable("message.headers.names");
		var headers = "";

		if(headerList != "[]") {
			var headerListStr = headerList.toString();
			headerListStr = headerListStr.replace("[",""); headerListStr = headerListStr.replace("]",""); headerListStr = headerListStr.replace(" ", "");
			
			var headerListArray = headerListStr.split(",");
			for(k=0; k<headerListArray.length; k++) {
				var hdrValue = context.getVariable("message.header."+headerListArray[k]+".values")+"";
				hdrValue = hdrValue.substr(1, hdrValue.length - 2);
				hdrValue = hdrValue.replace(/[\\]/g,'\\\\').replace(/["]/g, '\\"');
				headers = headers + ('"'+headerListArray[k]+'":"'+hdrValue+'",');

				if(headerListArray[k].search(/authorization/i) != -1) {
					var AuthHdrName = headerListArray[k];
				}
			}
			headers = headers.substr(0, headers.length - 1);
			headers = "{" + headers + "}";
			headers = JSON.parse(headers);
		}
		
		var headersToLog;
		if (headersToMask && headers) {
			headersToLog = maskHeaders(headersToMask, headers);
		} else {
			headersToLog = headers;
		}

		var queryStr = context.getVariable("message.querystring");
		if (queryStr && (queryParamsToMask !== "" && queryParamsToMask !== null)) {
			queryStr = maskQueryParam(queryParamsToMask, queryStr);
		}
		if (queryStr) {
			queryStr = queryStr.split("&");	
		}

		switch (flow) {
		case "PROXY_REQ_FLOW":
			logContent["severity"] = severity;
			logContent["logger"] = logger;
			logContent["thread"] = thread;
			logContentMessage["serviceVersion"] = context.getVariable("api_version");
			logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
			logContentMessage["logLevel"] = logLevel;
			logContentMessage["correlationId"] = correlationId;
			logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
			logContentMessage["httpHeaders"] = headersToLog;
			logContentMessage["layer"] = "MW-Apigee";
			logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
			logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
			logContentMessage["httpMethod"] = context.getVariable("request.verb");
			logContentMessage["logPoint"] = "INCOMING_REQUEST";
			logContentMessage["timestamp"] = dateForLog;
			logContentMessage["queryParams"] = queryStr;
			logContentProperties["correlationId"] = correlationId;
			logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
			break;
		case "TARGET_REQ_FLOW":
			logContent["severity"] = severity;
			logContent["logger"] = logger;
			logContent["thread"] = thread;
			logContentMessage["serviceVersion"] = context.getVariable("api_version");
			logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
			logContentMessage["logLevel"] = logLevel;
			logContentMessage["correlationId"] = correlationId;
			logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
			logContentMessage["httpHeaders"] = headersToLog;
			logContentMessage["layer"] = "MW-Apigee";
			logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
			logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
			logContentMessage["httpMethod"] = context.getVariable("request.verb");
			logContentMessage["logPoint"] = "OUTGOING_REQUEST";
			logContentMessage["timestamp"] = dateForLog;
			logContentMessage["downstreamURL"] = context.getVariable('target.url');
			logContentMessage["queryParams"] = queryStr;
			logContentProperties["correlationId"] = correlationId;
			logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
			break;
		case "TARGET_RESP_FLOW":
			logContent["severity"] = severity;
			logContent["logger"] = logger;
			logContent["thread"] = thread;
			logContentMessage["serviceVersion"] = context.getVariable("api_version");
			logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
			logContentMessage["logLevel"] = logLevel;
			logContentMessage["correlationId"] = correlationId;
			logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
			logContentMessage["httpHeaders"] = headersToLog;
			logContentMessage["layer"] = "MW-Apigee";
			logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
			logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
			logContentMessage["logPoint"] = "INCOMING_RESPONSE";
			logContentMessage["timestamp"] = dateForLog;
			logContentMessage["totalTimeTaken"] = context.getVariable("system.timestamp")-context.getVariable("client.received.end.timestamp");
			logContentMessage["totalTimeTakenByTarget"] = context.getVariable("system.timestamp")-context.getVariable("target.sent.end.timestamp");
			logContentMessage["httpResponseCode"] = context.getVariable("message.status.code");
			logContentProperties["correlationId"] = correlationId;
			logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
			break;
		case "PROXY_RESP_FLOW":
			logContent["severity"] = severity;
			logContent["logger"] = logger;
			logContent["thread"] = thread;
			logContentMessage["serviceVersion"] = context.getVariable("api_version");
			logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
			logContentMessage["logLevel"] = logLevel;
			logContentMessage["correlationId"] = correlationId;
			logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
			logContentMessage["httpHeaders"] = headersToLog;
			logContentMessage["layer"] = "MW-Apigee";
			logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
			logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
			logContentMessage["logPoint"] = "OUTGOING_RESPONSE";
			logContentMessage["timestamp"] = dateForLog;
			logContentMessage["totalTimeTaken"] = context.getVariable("system.timestamp")-context.getVariable("client.received.end.timestamp");
			logContentMessage["httpResponseCode"] = context.getVariable("message.status.code");
			logContentProperties["correlationId"] = correlationId;
			logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
			break;
		case "ERROR":
			var logPoint = context.getVariable("logPoint");
			if(logPoint == "response-in") {
				logContent["severity"] = "ERROR";
				logContent["logger"] = logger;
				logContent["thread"] = thread;
				logContentMessage["serviceVersion"] = context.getVariable("api_version");
				logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
				logContentMessage["logLevel"] = "Error";
				logContentMessage["correlationId"] = correlationId;
				logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
				logContentMessage["httpHeaders"] = headersToLog;
				logContentMessage["layer"] = "MW-Apigee";
				logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
				logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
				logContentMessage["logPoint"] = "INCOMING_RESPONSE";
				logContentMessage["timestamp"] = dateForLog;
				logContentMessage["totalTimeTaken"] = context.getVariable("system.timestamp")-context.getVariable("client.received.end.timestamp");
				logContentMessage["totalTimeTakenByTarget"] = context.getVariable("system.timestamp")-context.getVariable("target.sent.end.timestamp");
				logContentMessage["httpResponseCode"] = context.getVariable("message.status.code");
				logContentProperties["correlationId"] = correlationId;
				logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
				break;
			} else {
				logContent["severity"] = "ERROR";
				logContent["logger"] = logger;
				logContent["thread"] = thread;
				logContentMessage["serviceVersion"] = context.getVariable("api_version");
				logContentMessage["mwRequestId"] = context.getVariable("mwRequestId") || context.getVariable("request.header.mwh-requestid");
				logContentMessage["logLevel"] = "Error";
				logContentMessage["correlationId"] = correlationId;
				logContentMessage["inboundRequestPath"] = maskedRequestUri || requestUri;
				logContentMessage["httpHeaders"] = headersToLog;
				logContentMessage["layer"] = "MW-Apigee";
				logContentMessage["serviceName"] = context.getVariable('apiproxy.name');
				logContentMessage["flowName"] = context.getVariable('currentFlowName') || "";
				logContentMessage["logPoint"] = "OUTGOING_RESPONSE";
				logContentMessage["timestamp"] = dateForLog;
				logContentMessage["totalTimeTaken"] = context.getVariable("system.timestamp")-context.getVariable("client.received.end.timestamp");
				logContentMessage["httpResponseCode"] = context.getVariable("message.status.code");
				logContentProperties["correlationId"] = correlationId;
				logContentProperties["processorPath"] = context.getVariable("environment.qualifiedname");
				break;
			}
		}

		var payload	= context.getVariable("message.content");
		var accessPayloadSize = payload.length;
		// context.setVariable("accessPayloadSize", accessPayloadSize);
		var maxPayloadContentSize = context.getVariable("max_payload_content_size");

		if ((formParamsToMask !== null) && (formParam !== null)) {
			var formparams  = maskFormParam(formParamsToMask, fparam);
			formparams = JSON.stringify(formparams);
			formparams = formparams.replace("{","");
			formparams = formparams.replace("}","");
			formparams = formparams.replace(/:/g,"=");
			formparams = formparams.replace(/,/g,"&");
			formparams = formparams.replace(/["]/g,"");
		}

		if ((loggingPayloadEnabled === true) && (accessPayloadSize < maxPayloadContentSize)) {
			logContentMessage["message"] = formparams || payload || context.getVariable("message.content");
		} else {
			logContentMessage["message"] = "Redacted due to config";
		}

		if(context.getVariable("x_forwarded_proto_req") && context.getVariable("x_forwarded_port_req")) {
			if (context.getVariable("x_forwarded_host_req")) {
				logContent["server-name"] = context.getVariable("x_forwarded_proto_req") + "://" + context.getVariable("x_forwarded_host_req") + ":" + context.getVariable("x_forwarded_port_req");
			} else if (context.getVariable("x_forwarded_for_req")) {
				logContent["server-name"] = context.getVariable("x_forwarded_proto_req") + "://" + context.getVariable("x_forwarded_for_req") + ":" + context.getVariable("x_forwarded_port_req");
			} else {
				logContent["server-name"] = "";
			}
			
		} else {
			logContent["server-name"] = "";
		}

		logContent["clientIP"] = context.getVariable("client.ip");
		logContent["proxyClientIP"] = context.getVariable("proxy.client.ip");
		logContent["env-name"] = context.getVariable("environment.name");
		logContent["message-processor-uuid"] = context.getVariable("system.uuid");

		logContent["api-product"]= context.getVariable("apiproduct.name") || "";
		logContent["caller-app"]= context.getVariable("developer.app.name") || "";

		context.setVariable("logContent", JSON.stringify(logContent));
	} catch (err) {
		context.setVariable("logContent", JSON.stringify(logContent));		
		throw err;
	}
}

function maskHeaders(headersToMask, headers) {
	headersToMask = headersToMask.toLowerCase();
	headersList= headersToMask.split(",");

	if(response) {
		for(var i in response.headers) {
			if(i && headersList.indexOf(i.toLowerCase()) > -1 ) {
				headers[i] = "********";
			}
		}
	} else {
		for(var i in request.headers) {
			if(i && headersList.indexOf(i.toLowerCase()) > -1 ) {
				headers[i] = "********";
			}
		}
	}
	return headers;
};

function maskQueryParam(queryParamsToMask, inboundRequestUri) {
	queryParamsToMask = queryParamsToMask;
	var queryList= queryParamsToMask.split(",");
	var newString = inboundRequestUri;
	for(var i in queryList) {
		var re = new RegExp("[\\?&]{0,1}" + queryList[i] + "=([^&#]*)");
		var matches = re.exec(inboundRequestUri);
		if (newString.indexOf(queryList[i])>=0) {
				var delimeter = matches[0].charAt(0);
				// context.setVariable("delimeter", delimeter);
				if ((delimeter === "?") || (delimeter === "&")) {
					newString = newString.replace(re, delimeter + queryList[i] + "=" + "********");
				} else {
					newString = newString.replace(re, queryList[i] + "=" + "********");
				}
			}
		}
		return newString;
};

function maskFormParam(formParamsToMask, fparam){
	formParamsToMask = formParamsToMask.toLowerCase();
	var formParamList = formParamsToMask.split(",");

	for(var i in fparam) {
		if(i && formParamList.indexOf(i.toLowerCase()) > -1 ) {
			fparam[i] = "********";
		}
	}
	return fparam;
};