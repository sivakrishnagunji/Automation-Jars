
var AccessHeadersPropagationSB = require('../jsc/AccessHeadersSB/AccessHeadersPropagationSB.js');
describe('NetworkHttpStatus Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it ('Test : VF_INT_TRACE_ID exists', function() {
       context.setVariable("VF_INT_TRACE_ID_resp","value");     
       expect(accessHeadersSB()).toBe();
       expect(context.getVariable("message.header.VF_INT_TRACE_ID")).toBe("value");
    });

    it ('Test: VF_INT_TRACE_ID is undefined', function() {
        context.setVariable("VF_INT_TRACE_ID_resp","");     
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_INT_TRACE_ID")).toBe(undefined);
     });

     it ('Test: vfTraceTransactionId exists', function() {
        context.setVariable("vf_trace_transaction_id_resp","value");     
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.vf-trace-transaction-id")).toBe("value");
     });

     it ('Test: VF_INT_TRACK_ID exists', function() {
        context.setVariable("VF_INT_TRACK_ID_resp","value");    
        context.setVariable('apiproxy.name','TrustedContacts'); 

        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_INT_TRACK_ID")).toBe("value.TrustedContacts-apix");
     });

     it ('Test: VF_INT_CALLER_ID exists', function() {
        context.setVariable("VF_INT_CALLER_ID_resp",1);    
        
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_INT_CALLER_ID")).toBe(1);
     });

     it ('Test: VF_EXT_TRACE_ID exists', function() {
        context.setVariable("VF_EXT_TRACE_ID_resp",1);    
        
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_EXT_TRACE_ID")).toBe(1);
     });

     it ('Test: VF_EXT_REFERENCE_ID exists', function() {
        context.setVariable("VF_EXT_REFERENCE_ID_resp",1);    
        
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_EXT_REFERENCE_ID")).toBe(1);
     });

     it ('Test: VF_EXT_BP_ID exists', function() {
        context.setVariable("VF_EXT_BP_ID_resp",1);    
        
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_EXT_BP_ID")).toBe(1);
     });

     it ('Test: VF_INT_STATUS_FLOW exists', function() {
        context.setVariable("VF_INT_STATUS_FLOW_resp","status_flow");    
        
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_INT_STATUS_FLOW")).toBe("status_flow");
     });

     it ('Test: VF_INT_STATUS_FLOW not exists and 200<= statuscode <400', function() {
        context.setVariable("message.status.code",300) 
        expect(accessHeadersSB()).toBe();
        expect(context.getVariable("message.header.VF_INT_STATUS_FLOW")).toBe("ok");
     });
});