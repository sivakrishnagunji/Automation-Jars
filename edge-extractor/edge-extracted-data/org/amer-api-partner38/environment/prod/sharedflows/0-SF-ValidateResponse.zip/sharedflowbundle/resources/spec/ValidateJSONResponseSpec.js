/**
 * 
 */
var validateResponse = require('../jsc/4-JS-Validate-JSON/4-JS-Validate-JSON.js');

describe('Validate JSON Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
        
        var TV4 = function(){
        };
        TV4.prototype = {
            validate: function(payload, schema){
            if(typeof payload === schema.type){
                return true;
            }else{
                return false;
            }
            }
            
        };
        tv4 = new TV4();
    });

    it ('Test1: type object isnt good', function() {
       context.setVariable("response.content","{\"foo\":\"bar\"}");     
       context.setVariable("jsonSchemaResponse","{\"type\":\"array\",\"properties\":{\"foo\":{\"type\":\"int\"}},\"required\":[\"foo\"]}"); 
       expect(validateJSONResponse()).toBe();
       expect(context.getVariable("raiseFaultRuleSchemaValidation")).toBe("true");
       expect(context.getVariable("raiseFaultRuleSchemaValidationMessage")).toBe(undefined);
     
    });
    it ('Test2: type object is good', function() {
        
        context.setVariable("response.content","{\"foo\":\"bar\"}");     
        context.setVariable("jsonSchemaResponse","{\"type\":\"object\",\"properties\":{\"foo\":{\"type\":\"int\"}},\"required\":[\"foo\"]}"); 
        expect(validateJSONResponse()).toBe();
     });
     it ('Test3:schema is not present', function() {

        context.setVariable("response.content","{\"foo\":\"bar\"}");     
        expect(validateJSONResponse()).toBe();
     });

     it ('Test4: payload is not', function() {
        context.setVariable("response.content","");    
        expect(validateJSONResponse()).toBe();
        expect(context.getVariable("raiseFaultRuleSchemaValidation")).toBe("true");
        expect(context.getVariable("raiseFaultRuleSchemaValidationMessage")).toBe("Incoming request empty");
    });
   

    
});