/* eslint-disable */
validateJSONResponse = function ValidateJSONResponse() {
	/* eslint-enable */
	var schema = context.getVariable("jsonSchemaResponse");
	var payload = context.getVariable("response.content");

	if (payload === "") {
		context.setVariable("raiseFaultRuleSchemaValidation", "true");
		context.setVariable("raiseFaultRuleSchemaValidationMessage", "Incoming request empty");
	} else if (schema) {
		/* eslint-disable */
		var valid = tv4.validate(JSON.parse(payload), JSON.parse(schema));
		if (!valid) {
			context.setVariable("raiseFaultRuleSchemaValidation", "true");
			context.setVariable("raiseFaultRuleSchemaValidationMessage", tv4.error);
			context.setVariable("errorJSON", "a42_incoming_request_payload_not_valid");
		}
		/* eslint-enable */
	}
};