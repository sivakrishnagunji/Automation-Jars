/**
 * Script for unit test cases of SizeCheck.js
 */
require('../jsc/SizeCheck/SizeCheck.js');
describe('SizeCheck Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it ('Case 1: If Payload size is valid', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"2048\",\"max_header_size\": \"8192\",\"max_content_size\": \"2097152\"}");
        context.setVariable("proxy.url","http");   
        context.setVariable("message.content","message");
        context.setVariable("request.headers.names",'[Accept, accept-encoding]');
        context.setVariable('request.header.Accept','orice');
        context.setVariable('request.header.accept-encoding','orice');
        expect(executeSiteCheck()).toBe();
     });
    it ('Case 2: If Payload size is more', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"10\",\"max_header_size\": \"5\",\"max_content_size\": \"10\"}");
        context.setVariable("proxy.url","http");   
        context.setVariable("message.content","message1message2message3message4");
        context.setVariable("request.headers.names",'[Accept, accept-encoding]');
        context.setVariable('request.header.Accept','orice');
        context.setVariable('request.header.accept-encoding','orice');
        expect(executeSiteCheck).toThrow();
        expect(context.getVariable("errorJSON")).toBe("customizedErrorMessage");
     });
    it ('Case 3: If URI size is exceeds the limit', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"10\",\"max_header_size\": \"5\",\"max_content_size\": \"10\"}");
        context.setVariable("proxy.url","http://abcpqrenbcbnbcnbxncbxcnbcnbcbbnbnxcnbncbbcnxb.com");   
        context.setVariable("message.content","message1message2message3message4");
        context.setVariable("request.headers.names",'[Accept, accept-encoding]');
        context.setVariable('request.header.Accept','orice');
        context.setVariable('request.header.accept-encoding','orice');
        expect(executeSiteCheck).toThrow();
        expect(context.getVariable("errorJSON")).toBe("customizedErrorMessage");
     });
    it ('Case 4: If Header size is exceeds the limit', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"10\",\"max_header_size\": \"5\",\"max_content_size\": \"10\"}");
        context.setVariable("proxy.url","http://");   
        context.setVariable("message.content","message1");
        context.setVariable("request.headers.names",'[Accept, accept-encoding, Authorization]');
        context.setVariable('request.header.Accept','orice');
        context.setVariable('request.header.accept-encoding','orice');
        context.setVariable('request.header.Authorization','1234567890');
        expect(executeSiteCheck).toThrow();
        expect(context.getVariable("errorJSON")).toBe("customizedErrorMessage");
     });
    it ('Case 5: If KVM configuration is not present', function() {
        context.setVariable("max_request_size_proxy", "");
        context.setVariable("proxy.url","http");   
        context.setVariable("message.content","message");
        context.setVariable("request.headers.names",['header1']);
        context.setVariable('request.header.header1','orice');
        expect(executeSiteCheck).toThrow();
     });
    it ('Case 6: Config is present but fields are empty', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"\",\"max_header_size\": \"\",\"max_content_size\": \"\"}");
        context.setVariable("proxy.url","http");   
        context.setVariable("message.content","message");
        expect(executeSiteCheck).toThrow();
     });
    it ('Case 7: If Payload size is valid', function() {
        context.setVariable("max_request_size_proxy", "{\"max_request_uri_size\": \"2048\",\"max_header_size\": \"8192\",\"max_content_size\": \"2097152\"}");
        context.setVariable("proxy.url","http");   
        context.setVariable("message.content","message");
        expect(executeSiteCheck()).toBe();
     });
});