/* eslint-disable */
accessHeadersSB = function AccessHeadersSB() { 
/* eslint-enable */
	try {
		var statusCode = context.getVariable("message.status.code");
		var apiName = context.getVariable("apiproxy.name");

		var INT_TRACE_ID = context.getVariable("INT_TRACE_ID_resp") || context.getVariable("INT_TRACE_ID_req");
		var TraceTransactionId = context.getVariable("trace_transaction_id_resp") || context.getVariable("trace_transaction_id_req");
		var INT_TRACK_ID = context.getVariable("INT_TRACK_ID_resp") || context.getVariable("INT_TRACK_ID_req");
		var INT_CALLER_ID = context.getVariable("INT_CALLER_ID_resp") || context.getVariable("INT_CALLER_ID_req");
		var EXT_TRACE_ID = context.getVariable("EXT_TRACE_ID_resp") || context.getVariable("EXT_TRACE_ID_req");
		var EXT_REFERENCE_ID = context.getVariable("EXT_REFERENCE_ID_resp") || context.getVariable("EXT_REFERENCE_ID_req");
		var EXT_BP_ID = context.getVariable("EXT_BP_ID_resp") || context.getVariable("EXT_BP_ID_req");
		var INT_STATUS_FLOW = context.getVariable("INT_STATUS_FLOW_resp");

		if (INT_TRACE_ID) {
			context.setVariable("message.header.INT_TRACE_ID", INT_TRACE_ID);
		}
		if (TraceTransactionId) {
			context.setVariable("message.header.trace-transaction-id", TraceTransactionId);
		}
		if (INT_TRACK_ID) {
			context.setVariable("message.header.INT_TRACK_ID", INT_TRACK_ID + "." + apiName + "-apix");
		}
		if (INT_CALLER_ID) {
			context.setVariable("message.header.INT_CALLER_ID", INT_CALLER_ID);
		}
		if (EXT_TRACE_ID) {
			context.setVariable("message.header.EXT_TRACE_ID", EXT_TRACE_ID);
		}
		if (EXT_REFERENCE_ID) {
			context.setVariable("message.header.EXT_REFERENCE_ID", EXT_REFERENCE_ID);
		}
		if (EXT_BP_ID) {
			context.setVariable("message.header.EXT_BP_ID", EXT_BP_ID);
		}

		if (INT_STATUS_FLOW) {
			context.setVariable("message.header.INT_STATUS_FLOW", INT_STATUS_FLOW);
		} else if ((statusCode >= 200) && (statusCode < 400)) {
			context.setVariable("message.header.INT_STATUS_FLOW", "ok");
		} else {
			context.setVariable("message.header.INT_STATUS_FLOW", "failure");
		}
	} catch (err) {
		context.setVariable("errorJSON", "a42_generic_internal_server_error");
		throw err;
	}
};