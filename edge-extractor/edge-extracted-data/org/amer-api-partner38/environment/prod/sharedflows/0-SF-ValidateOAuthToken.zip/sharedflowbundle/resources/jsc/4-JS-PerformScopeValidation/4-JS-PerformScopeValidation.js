/* eslint-disable */
performScopeValidation = function PerformScopeValidation() {
    /* eslint-enable */
	try {
		var tokenscopes = context.getVariable("scope");
		tokenscopes = tokenscopes.split(" ");
		var apiScopes = context.getVariable("apiScopes");
		var validApiScopes = false;
		// API level scope Validation
		if (apiScopes){
			apiScopes = apiScopes.split(",");
			for (var i = 0 ; tokenscopes.length > i ; i++){
				if (apiScopes.indexOf(tokenscopes[i]) > -1){
					validApiScopes = true;
					break;
				}
			}
		}
		if (!validApiScopes) {
			context.setVariable("errorJSON", "a42_generic_invalid_scope_for_api");
			throw "insufficientScopeError";
		}
		// Resource Level Scope Validation
		var flowName = context.getVariable("current.flow.name");
		context.setVariable("currentFlowName", flowName);

		var validResourceScopes = false;
		var allowedScopes = context.getVariable("allowedScopes");
		var flowScopes;
		context.setVariable("test", "here");
		allowedScopesObject = JSON.parse(allowedScopes);
		context.setVariable("allowedScopesObject", allowedScopesObject);
        var allowedScopesArray = [];
        for(var k in allowedScopesObject)
            allowedScopesArray.push(allowedScopesObject[k]);
        context.setVariable("allowedScopesArray", allowedScopesArray);
		
		context.setVariable("test3", "here3");
		for (var j = 0 ; allowedScopesArray.length > j ; j++) {
		    context.setVariable("test4", "here4");
			if (allowedScopesArray[j].flowName === flowName){
				flowScopes = allowedScopesArray[j].allowedScopesList;
				context.setVariable("flowScopes", flowScopes);
				context.setVariable("test1", "here1");
				break;
			}
		}
		if (flowScopes) {
			flowScopes = flowScopes.split(",");
			for (var l = 0; flowScopes.length > l; l++) {
				if (tokenscopes.indexOf(flowScopes[l]) > -1) {
				    context.setVariable("flowScope", flowScopes[l]);
					validResourceScopes = true;
					context.setVariable("test2", "here2");
					break;
				}
			}
		}

		if (!validResourceScopes) {
			context.setVariable("errorJSON", "a42_generic_insufficient_scope");
			throw "insufficientScopeError";
		}
	} catch (err) {
		throw err;
	}
};