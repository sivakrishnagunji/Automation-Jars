try {

	var securityRequestXss = context.getVariable("security_request_xss");
	var securityRequestXssJson = JSON.parse(securityRequestXss);
	var security_request_xss_headers = securityRequestXssJson.security_request_xss_headers;
	var security_request_xss_query = securityRequestXssJson.security_request_xss_query;
	var security_request_xss_payload = securityRequestXssJson.security_request_xss_payload;
	var security_request_xml_escape = securityRequestXssJson.security_request_xml_escape;

	var isHeaderXssEnabled = false;
	var isQueryXssEnabled = false;
	var isPayloadXssEnabled = false;
	var isEscapeXssEnabled = false;

	if (security_request_xss_headers) {
		isHeaderXssEnabled = security_request_xss_headers.enabled;

		if (isHeaderXssEnabled) {
			var regex = new RegExp(escapeRegex(security_request_xss_headers.regex));
			var headerList = context.getVariable("request.headers.names");
			if ((headerList !== null) && (headerList != "[]")) {
				for (var headerName in request.headers) {
					var headerValue = context.getVariable("request.header." + headerName + ".values") + "";
					headerValue = headerValue.substr(1, headerValue.length - 2);
					var result = regex.test(headerValue);
					if (result) {
						context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
						throw "internalConfigError";
					}

				}
			}
		}
	}

	if (security_request_xss_query) {
		isQueryXssEnabled = security_request_xss_query.enabled;
		if (isQueryXssEnabled) {
			var regex = new RegExp(escapeRegex(security_request_xss_query.regex));
			var paramList = context.getVariable("request.queryparams.names") + "";
			paramList = paramList.substr(1, paramList.length - 2);
			var paramListArray = paramList.split(",");
			var params = request.queryparams + "";
			if ((paramList != null) && (paramList != "[]")) {
				for (var i in paramListArray) {
					var paramName = paramListArray[i];
					var paramValue = context.getVariable("request.queryparam." + paramName + "");
					var result = regex.test(paramValue);
					if (result) {
						context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
						throw "internalConfigError";
					}

				}
			}
		}
	}

	if (security_request_xss_payload) {
		isPayloadXssEnabled = security_request_xss_payload.enabled;
		if (isPayloadXssEnabled) {
			var regex = new RegExp(escapeRegex(security_request_xss_payload.regex));
			var contentType = context.getVariable("message.header.Content-Type");
			if (contentType.indexOf("json") > 0) {
				var payloadJson = JSON.parse(context.getVariable("message.content"));
				for (key in payloadJson) {
					var value = payloadJson[key];
					if (typeof value === "string") {
						var result = regex.test(value);
						if (result) {
							context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
							throw "internalConfigError";
						}
					}
				}
				context.setVariable("message.content", JSON.stringify(payloadJson));
			} else if (contentType.indexOf("form") > 0) {
				var paramList = context.getVariable("request.formparams.names");
				if ((paramList != null) && (paramList != "[]")) {
					for (var paramName in request.formparams) {
						var paramValue = context.getVariable("request.formparam." + paramName);
						var result = regex.test(paramValue);
						if (result) {
							print("Payload form");
							context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
							throw "internalConfigError";
						}
					}
				}
			}
		}
	}

	if (security_request_xml_escape) {
		isEscapeXssEnabled = security_request_xml_escape.enabled;
		if (isEscapeXssEnabled) {
			var xmlEscapeVars = security_request_xml_escape.xml - escape - vars;
			var xmlEscapeVarsList = xmlEscapeVars.split(",");
			for (var i = 0; i < xmlEscapeVarsList.length; i++) {
				var flowVariable = xmlEscapeVarsList[i];
				var value = context.getVariable(flowVariable);
				value = escapeXml(value);
				context.setVariable(flowVariable, value);
			}
		}
	}

} catch (err) {
	var errorJson = (context.getVariable("errorJSON") || "a42_generic_internal_config_error");
	context.setVariable("errorJSON", errorJson);
	throw "internalConfigError";
}

function escapeXml(unsafe) {
	return unsafe.replace(/[<>&'"]/g, function (c) {
		switch (c) {
			case "<": return "&lt;";
			case ">": return "&gt;";
			case "&": return "&amp;";
			case "'": return "&apos;";
			case "\"": return "&quot;";
		}
	});
}

function escapeRegex(regex) {
	return regex.replace(/[-\/\\^$*+?.()|{}<>]/g, "\\$&");
}