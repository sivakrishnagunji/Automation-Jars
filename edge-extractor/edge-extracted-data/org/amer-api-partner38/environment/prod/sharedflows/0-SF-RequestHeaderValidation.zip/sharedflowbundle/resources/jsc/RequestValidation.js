var messageId = context.getVariable("messageId");
var action = context.getVariable("action");

if(!(messageId && action)) {
    context.setVariable("timeStamp", new Date().toISOString());
    context.setVariable("errorCode", "SOAP-ENV:Server");
    context.setVariable("name", "Bad Request");
    context.setVariable("description", "The request is not valid");
    context.setVariable("severity", "Minor");
    context.setVariable("category", "Technical");
    context.setVariable("reasonCode", "400");
    context.setVariable("errorMessage", "The request is not valid");
    context.setVariable("failure", "Bad Request");
    context.setVariable("fault.name", "bad_request");
    throw "inValidRequest";
}