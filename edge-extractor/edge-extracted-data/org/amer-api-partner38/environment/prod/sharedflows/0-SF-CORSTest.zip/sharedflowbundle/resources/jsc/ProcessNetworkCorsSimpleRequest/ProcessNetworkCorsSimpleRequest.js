 corsSimpleRequest = function corsSimpleRequest() { // eslint-disable-line no-undef
	var isValidOrigin = (function (context) {
		var origin = context.getVariable("request.header.Origin");
		var allowedOrigins = context.getVariable("cors_allowed_origins");
		var accessControlAllowCredentials = context.getVariable("cors_allow_credentials");
		var accessControlExposeHeaders = context.getVariable("cors_expose_headers");
		if (origin) {
			if (!(allowedOrigins && accessControlAllowCredentials && accessControlExposeHeaders)) { // KVM variable needs to be set
				context.setVariable("errorJSON", "generic_internal_config_error");
				throw "internalConfigError";
			} else {
				var allowedOriginsArray = allowedOrigins.split(",");
				var originToCheck = origin.replace("http://", "");
				originToCheck = originToCheck.replace("https://", "");
				context.setVariable("originToCheck", originToCheck);
				if (allowedOriginsArray.indexOf(originToCheck) < 0) {
					return false;
				}
				context.setVariable("origin", origin);
				context.setVariable("accessControlAllowCredentials", accessControlAllowCredentials);
				context.setVariable("accessControlExposeHeaders", accessControlExposeHeaders);
				context.setVariable("isValidOriginPresent", true);
				return true;
			}
		}
		context.setVariable("isValidOriginPresent", false);
		return true; // if origin is not present, default to true
	}(context));

	var isValidMethod = (function (context) {
		var origin = context.getVariable("request.header.Origin");
		if (origin) {
			var requestMethod = context.getVariable("request.verb");
			var allowedCorsMethods = context.getVariable("cors_allowed_methods");
			if (!allowedCorsMethods) { // KVM variable needs to be set
				context.setVariable("errorJSON", "generic_internal_config_error");
				throw "internalConfigError";
			} else {
				var allowedCorsMethodsArray = allowedCorsMethods.split(",");
				if (allowedCorsMethodsArray.indexOf(requestMethod) < 0) {
					return false;
				}
				return true;
			}
		}
		return true; // if origin is not present , it will default to true
	}(context));

	if (!isValidOrigin) {
		context.setVariable("errorJSON", "generic_invalid_origin");
		throw "invalidCORSOrigin";
	}
	if (!isValidMethod) {
		context.setVariable("Allow", context.getVariable("cors_allowed_methods"));
		context.setVariable("errorJSON", "generic_invalid_method");
		throw "invalidMethodError";
	}
};