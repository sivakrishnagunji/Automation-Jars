/**
 * 
 */
var CheckHeadersVar = require('../jsc/CheckHeaders/CheckHeaders.js');
describe('CheckHeaders Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }/**,
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }**/, 
			proxyRequest :{ headers: ''},
        };
        context = new Context();
    });
	
	
     
    it ('Positive: valid headers list 1', function()
	{
    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
		context.setVariable("headersToValidate", JSON.stringify(headersJson));
		context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
		context.setVariable("currentFlowName", "create");
		context.setVariable("request.header.dhanashri", "DE");
		context.setVariable("request.verb", "POST");
		context.setVariable("request.header.Content-Type", "application/json");
		context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
		expect(checkHeaders()).toBe();
    }
	);
    
    it ('Positive: valid headers list 2', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders()).toBe();
    	    }
    		);
    it ('Positive: valid headers list 3', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[applicaation/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    it ('Positive: valid headers list 4', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "applicaation/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    it ('Positive: valid headers list 5', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashria", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    
    it ('Positive: valid headers list 6', function()
    		{
    	    	var headersJson = {"acceptValuesa":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    
    it ('Positive: valid headers list 7', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeVaalues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders()).toBe();
    	    }
    		);
    
    it ('Positive: valid headers list 8', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchVaalues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    it ('Positive: valid headers list 9', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"createa":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders()).toBe();
    	    }
    		);
    
    it ('Positive: valid headers list 10', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "GET");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders()).toBe();
    	    }
    		);
    
    it ('Positive: valid headers list 11', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "PATCH");
    			//context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    
    it ('Positive: valid headers list 12', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeaValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "POST");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    
    it ('Positive: valid headers list 13', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "POST");
    			//context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    it ('Positive: valid headers list 14', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "POST");
    			context.setVariable("request.header.Content-Type", "application/jsona");
    			context.setVariable("request.header.accept.values", "[application/json],[abc],[def],[ghi]");
    			expect(checkHeaders).toThrow();
    	    }
    		);
    
    it ('Positive: valid headers list 15', function()
    		{
    	    	var headersJson = {"acceptValues":["application/json","123","*/*"],"contentTypeValues":["application/json","123"],"contentTypePatchValues":["application/json","123"],"create":["dhanashri"]};
    			context.setVariable("headersToValidate", JSON.stringify(headersJson));
    			context.proxyRequest.headers={"msisdn":"004912346476879","countryCode":"DE"};
    			context.setVariable("currentFlowName", "create");
    			context.setVariable("request.header.dhanashri", "DE");
    			context.setVariable("request.verb", "POST");
    			context.setVariable("request.header.Content-Type", "application/json");
    			context.setVariable("request.header.accept.values", "[application/json;asd],[abc],[def],[ghi]");
    			expect(checkHeaders()).toBe();
    	    }
    		);
});