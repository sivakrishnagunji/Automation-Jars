checkHeaders = function checkHeaders() {// eslint-disable-line no-undef
    var headersArray = [];
	var customizedErrorMessage;
	try {
		var json = JSON.parse(context.getVariable("headersToValidate"));
		var verb = context.getVariable("request.verb");
		var contentTypeValKvm;
		var contentType;
		// Content-Type Validation
		if (verb === "PATCH") {
			contentTypeValKvm = json.contentTypePatchValues;
			if (contentTypeValKvm) {
				contentType = context.getVariable("request.header.Content-Type");
				if (contentType) {
					contentType = contentType.toLowerCase();
					if (contentTypeValKvm.indexOf(contentType) === -1) {
						customizedErrorMessage = {
							"statusCode": "415",
							"reasonPhrase": "Unsupported Media Type",
							"errorCode": "Unsupported Media Type",
							"errorDescription": "The value of the Content-Type header is invalid"
						};
						throw "invalidHeaderException";
					}
				} else {
					customizedErrorMessage = {
						"statusCode": "415",
						"reasonPhrase": "Unsupported Media Type",
						"errorCode": "Unsupported Media Type",
						"errorDescription": "The value of the Content-Type header is invalid"
					};
					throw "invalidHeaderException";
				}
			} else {
				customizedErrorMessage = {
					"statusCode": "500",
					"reasonPhrase": "Internal Server Error",
					"errorCode": "server_error",
					"errorDescription": "The service is currently not available. Please try again later"
				};
				context.setVariable("errorOccured", "Configuration not found for contentTypePatchValues");
				throw "invalidHeaderException";
			}
		} else if (verb === "PUT" || verb === "POST") {
			contentTypeValKvm = json.contentTypeValues;
			if (contentTypeValKvm) {
				contentType = context.getVariable("request.header.Content-Type");
				if (contentType) {
					contentType = contentType.toLowerCase();
					if (contentTypeValKvm.indexOf(contentType) === -1) {
						customizedErrorMessage = {
							"statusCode": "415",
							"reasonPhrase": "Unsupported Media Type",
							"errorCode": "Unsupported Media Type",
							"errorDescription": "The value of the Content-Type header is invalid"
						};
						throw "invalidHeaderException";
					}
				} else {
					customizedErrorMessage = {
						"statusCode": "415",
						"reasonPhrase": "Unsupported Media Type",
						"errorCode": "Unsupported Media Type",
						"errorDescription": "The value of the Content-Type header is invalid"
					};
					throw "invalidHeaderException";
				}
			} else {
				customizedErrorMessage = {
					"statusCode": "500",
					"reasonPhrase": "Internal Server Error",
					"errorCode": "server_error",
					"errorDescription": "The service is currently not available. Please try again later"
				};
				context.setVariable("errorOccured", "Configuration not found for contentTypeValues");
				throw "invalidHeaderException";
			}
		}

        if(context.getVariable("request.header.Accept")){
		var preferredMediaTypeHdrArray = context.getVariable("request.header.accept.values");
		var preferredMediaTypesKVMArray = json.acceptValues;
		var preferredMediaType;

		var accHdrStr = preferredMediaTypeHdrArray.toString();
		accHdrStr = accHdrStr.replace("[", "");
		accHdrStr = accHdrStr.replace("]", "");
		accHdrStr = accHdrStr.replace(" ", "");

		var accHdrArray = accHdrStr.split(",");


		for (var i = 0; i < preferredMediaTypesKVMArray.length; i++) {
			if (preferredMediaType) {
				break;
			}
			for (var j = 0; j < accHdrArray.length; j++) {
				if (preferredMediaType) {
					break;

				}
				var currAccHdrArray = accHdrArray[j];
				
				if (currAccHdrArray.includes(";")) {
					currAccHdrArray = currAccHdrArray.substring(0, currAccHdrArray.indexOf(";"));
				}
				if (preferredMediaTypesKVMArray[i] == currAccHdrArray) { // eslint-disable-line eqeqeq
					preferredMediaType = "application/json";
					context.setVariable("preferredMediaType", preferredMediaType);
				}
			}
		}
		if (!preferredMediaType) {
			customizedErrorMessage = {
				"statusCode": "406",
				"reasonPhrase": "Not Acceptable",
				"errorCode": "Not Acceptable",
				"errorDescription": "The Accept header is invalid"
			};
			throw "invalidAcceptHeader";
		}
            
    }

	} catch (e) {
		if (!customizedErrorMessage){
			context.setVariable("errorOccured", "true");
			customizedErrorMessage = {
				"statusCode": "500",
				"reasonPhrase": "Internal Server Error",
				"errorCode": "server_error",
				"errorDescription": "The service is currently not available. Please try again later"
			};
		}
		context.setVariable("errorJSON", "customizedErrorMessage");
		context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
		throw "error";
	}
};
