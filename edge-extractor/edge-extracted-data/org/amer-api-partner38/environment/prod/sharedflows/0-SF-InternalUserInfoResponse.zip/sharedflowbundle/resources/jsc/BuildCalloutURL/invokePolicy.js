try {
	buildCalloutUrl();
} catch (err) {
	throw err;
}