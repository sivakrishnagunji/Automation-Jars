try {
	calcCacheExpiry();
} catch (err) {
	throw err;
}