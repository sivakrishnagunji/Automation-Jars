try {
	createCachingJSON();
} catch (err) {
	throw err;
}