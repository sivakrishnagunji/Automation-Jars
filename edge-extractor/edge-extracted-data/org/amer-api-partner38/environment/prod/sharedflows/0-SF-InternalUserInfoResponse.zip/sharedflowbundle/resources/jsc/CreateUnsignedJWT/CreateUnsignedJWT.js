createUnsignedJWT = function createUnsignedJWT() {
    try {
	// context.setVariable('apiProfileResponse.content','{ "profile": { "email": "jhon.dow@vodafone.com", "organizationId": "1234", "mainRole": "PLATFORM_ADMINISTRATOR,ORG_ADMIN", "functionalUser": "M2M_CUSTOMER_ADMINISTRATOR" }, "fault": { "faultcode": "200", "faultstring": "OK", "detail": "Data retrieved successfully" } }');
    		var header = {
    			"alg": "none"
    		};
    	//	var signedJWTWSO2 =  context.getVariable("signedJWTWSO2.content");
    		var apiProfileResponse = context.getVariable("apiProfileResponse.content");
    		var apiProfileResponseJson = JSON.parse(apiProfileResponse);
    		apiProfileResponseJson = apiProfileResponseJson.profile;
    	//	context.setVariable("apiProfileResponseJson11",apiProfileResponseJson);
    		var claims = {"iss": "API_HUB"};
    		var  Roles=[];
    		claims.iat=getIssuedat();
    		
    		for(var prop in apiProfileResponseJson) {
    			if(prop == "email") {
    				claims.user=apiProfileResponseJson[prop];
    			}
    			if(prop == "organizationId") {
    				claims.org=apiProfileResponseJson[prop];
    			}
    			if(prop == "functionalUser") {
    				claims.functionalUser=apiProfileResponseJson[prop];
    			}
    			if(prop == "mainRole") {
    				claims.fn=apiProfileResponseJson[prop];
    				var rolesArray = apiProfileResponseJson[prop].split(",");
    				claims.roles = rolesArray;
    			}
    		}
    		context.setVariable("claims",JSON.stringify(claims));
    		context.setVariable("header",JSON.stringify(header));
    		var constructedJwtJSON = JSON.stringify(header) + ',' + JSON.stringify(claims);
    		context.setVariable("constructedJwtJSON",constructedJwtJSON);
    		context.setVariable("unsignedJWT",getUnsignedJWT());
    } catch (err) {
        throw err;
    }    		
    	
    		function getIssuedat() {
    			var now = new Date() ; 
    			var secondsSinceEpoch = now.getTime();
    			secondsSinceEpoch = secondsSinceEpoch + "";
    			var issuedAt = secondsSinceEpoch.substring(0, secondsSinceEpoch.length - 3);
    			issuedAt= parseInt(issuedAt);
    			return issuedAt;
    		}
    		function getUnsignedJWT() {
    			var joseHeader= JSON.stringify(header);
    			var payload = JSON.stringify(claims);
    			var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},_utf8_encode:function(e){e=e.replace(/\r\n/g,"\n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t}};  	
    			var encodedHeader = Base64.encode(joseHeader);
    			var encodedPayload = Base64.encode(payload);
    			var unsignedJWT = encodedHeader + "." + encodedPayload + ".";
    			return unsignedJWT;
    		}
};
