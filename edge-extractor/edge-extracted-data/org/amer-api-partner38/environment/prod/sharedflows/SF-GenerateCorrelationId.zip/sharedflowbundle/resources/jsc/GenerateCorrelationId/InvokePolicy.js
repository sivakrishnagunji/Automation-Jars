try {
    generateCorrelationId();
} catch (err) {
    throw err;
}