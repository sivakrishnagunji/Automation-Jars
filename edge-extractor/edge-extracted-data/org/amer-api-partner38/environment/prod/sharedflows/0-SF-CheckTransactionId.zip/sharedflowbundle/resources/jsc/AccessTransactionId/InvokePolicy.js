try {
	accessTransactionId(); // eslint-disable-line no-undef
} catch (err){
	context.setVariable("errorOccured", "true");
    var customizedErrorMessage = {
            "statusCode": "500",
            "reasonPhrase": "Internal Server Error",
            "errorCode": "server_error",
            "errorDescription": "The service is currently not available. Please try again later"
        };
    context.setVariable("errorJSON", "customizedErrorMessage");
    context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage)); 
	throw "internal_config_error";
}