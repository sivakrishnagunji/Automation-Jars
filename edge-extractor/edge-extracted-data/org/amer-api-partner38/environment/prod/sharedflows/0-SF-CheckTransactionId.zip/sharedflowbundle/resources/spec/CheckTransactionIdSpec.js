
var AccessTransaction = require('../jsc/AccessTransactionId/AccessTransactionId');
describe('AccessTransactionId Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });

    it("Case 1: transactionId exists", function(){
        context.setVariable("request.header.vf-trace-transaction-id", "123456676");
        var jsonString = "{\"enabled\":\"true\",\"logging_payload_enabled\":\"false\"}";
        context.setVariable("ulff_proxy", jsonString);
        expect(accessTransactionId()).toBe();
        context.getVariable("vf.trace.transaction.id", "123456676");
    });
   it("Case 2: x-vf-trace-transaction-id exists", function(){
	   context.setVariable("request.header.x-vf-trace-transaction-id", "123456676");
	   var jsonString = "{\"enabled\":\"true\",\"logging_payload_enabled\":\"false\"}";
        context.setVariable("ulff_default", jsonString);
        expect(accessTransactionId()).toBe();
        context.getVariable("vf.trace.transaction.id", "123456676");
    });
   it("Case 3:Transaction Id is not present", function(){
	   var jsonString = "{\"enabled\":\"true\",\"logging_payload_enabled\":\"false\"}";
        context.setVariable("ulff_default", jsonString);
        expect(accessTransactionId()).toBe();
    });
});