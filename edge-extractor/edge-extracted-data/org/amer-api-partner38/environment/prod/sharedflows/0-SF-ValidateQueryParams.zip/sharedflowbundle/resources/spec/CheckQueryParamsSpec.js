var CheckQueryParamsTest = require('../jsc/CheckQueryParams/CheckQueryParams.js');
describe('Check Query Params Suite', function() {
	beforeEach(function() {

	});

	// TO DO
	it('Query parameters are empty string 1', function() {
		var Context = function() {
		};
		Context.prototype = {
			setVariable : function(propertyName, propertyValue) {
				this[propertyName] = propertyValue;
			},
			getVariable : function(propertyName) {
				return this[propertyName];
			},
			proxyRequest : {
				"queryParams" : {
					"foo" : "asd"
				}
			},
		};
		context = new Context();

		context.setVariable("queryParamsToValidate", "{\"create\":[\"foo\"]}");
		context.setVariable("currentFlowName", [ 'create' ]);
		context.setVariable('request.queryparam', 'orice');
		expect(checkQueryParams()).toBe();
	});

	it('Query parameters are empty string 2', function() {
		var Context = function() {
		};
		Context.prototype = {
			setVariable : function(propertyName, propertyValue) {
				this[propertyName] = propertyValue;
			},
			getVariable : function(propertyName) {
				return this[propertyName];
			},
			proxyRequest : {
				"queryParams" : {
					"foo1" : "asd"
				}
			},
		};
		context = new Context();

		context.setVariable("queryParamsToValidate", "{\"create\":[\"foo\"]}");
		context.setVariable("currentFlowName", [ 'create' ]);
		context.setVariable('request.queryparam', 'orice');
		expect(checkQueryParams).toThrow();
	});

	it('Query parameters are empty string 3', function() {
		var Context = function() {
		};
		Context.prototype = {
			setVariable : function(propertyName, propertyValue) {
				this[propertyName] = propertyValue;
			},
			getVariable : function(propertyName) {
				return this[propertyName];
			},
			proxyRequest : {
				"queryParams" : {
					"foo1" : "asd"
				}
			},
		};
		context = new Context();

		context.setVariable("queryParamsToValidate", "{\"create\":[\"foo\"]}}");
		context.setVariable("currentFlowName", [ 'create' ]);
		context.setVariable('request.queryparam', 'orice');
		expect(checkQueryParams).toThrow();
	});
	it('Query parameters are empty string 4', function() {
		var Context = function() {
		};
		Context.prototype = {
			setVariable : function(propertyName, propertyValue) {
				this[propertyName] = propertyValue;
			},
			getVariable : function(propertyName) {
				return this[propertyName];
			},
			proxyRequest : {
				"queryParams" : {
					"foo1" : "asd"
				}
			},
		};
		context = new Context();

		context.setVariable("queryParamsToValidate", "{\"create\":[\"foo\"]}");
		context.setVariable("currentFlowName", [ 'create1' ]);
		context.setVariable('request.queryparam', 'orice');
		expect(checkQueryParams()).toBe();
	});


});