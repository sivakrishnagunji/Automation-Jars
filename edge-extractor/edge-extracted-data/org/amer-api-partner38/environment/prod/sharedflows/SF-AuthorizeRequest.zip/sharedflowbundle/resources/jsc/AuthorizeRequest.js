var adminFlag = context.getVariable("adminFlag");
if (adminFlag != true) {
    context.setVariable("adminFlag", "false");
    throw "notAdminError";
}