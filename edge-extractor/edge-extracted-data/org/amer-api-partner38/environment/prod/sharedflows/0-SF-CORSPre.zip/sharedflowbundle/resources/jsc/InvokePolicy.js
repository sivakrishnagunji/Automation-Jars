  try{
	corsPreflightRequest();
}catch(err){
	context.setVariable("isValidPreflightRequest", false);
}