 corsPreflightRequest = function corsPreflightRequest(){ // eslint-disable-line no-undef
	var isValidOrigin = (function (context) {
		var origin = context.getVariable("request.header.Origin");
		var allowedOrigins = context.getVariable("cors_allowed_origins");
		if (!(allowedOrigins && origin)) { // KVM variable needs to be set and for Options call Origin should be present
			return false;
		} else {
			var allowedOriginsArray = allowedOrigins.split(",");
			var originToCheck = origin.replace("http://", "");
			originToCheck = originToCheck.replace("https://", "");
			context.setVariable("originToCheck", originToCheck);
			if (allowedOriginsArray.indexOf(originToCheck) < 0) {
				return false;
			}
			context.setVariable("origin", origin);
			return true;
		}
	}(context));

	var isValidMethod = (function (context) {
		var accessControlRequestMethod = context.getVariable("request.header.Access-Control-Request-Method");
		var allowedCorsMethods = context.getVariable("cors_allowed_methods");
		if (!(allowedCorsMethods && accessControlRequestMethod)) {// KVM variable needs to be set and for preflight request, this header is required
			return false;
		} else {
			var allowedCorsMethodsArray = allowedCorsMethods.split(",");
			print("allowedCorsMethodsArray  "+allowedCorsMethodsArray);
			if (allowedCorsMethodsArray.indexOf(accessControlRequestMethod) < 0) {
				return false;
			}
			// for response we only give back requested method due to security
			context.setVariable("accessControlAllowMethod", accessControlRequestMethod);
			return true;
		}
	}(context));
	var isValidHeader = (function (context) {
		var accessControlRequestHeaders = context.getVariable("request.header.Access-Control-Request-Headers");
		var allowedHeaders = context.getVariable("cors_allowed_headers");
		if (!(allowedHeaders && accessControlRequestHeaders)) { // KVM variable needs to be set and for preflight request, this header is required
			return false;
		} else {
			var accessControlRequestHeaderValues = context.getVariable("request.header.Access-Control-Request-Headers.values") + "";
			var allowedHeadersArray = (allowedHeaders.toLowerCase()).split(",");
			if (accessControlRequestHeaderValues && accessControlRequestHeaderValues.indexOf("[") > - 1 && accessControlRequestHeaderValues.length > 2) { // eslint-disable-line max-len
				accessControlRequestHeaderValues = accessControlRequestHeaderValues.substring(1, accessControlRequestHeaderValues.length - 1);
			}
			accessControlRequestHeaderValues = accessControlRequestHeaderValues.trim();
			var accessControlRequestHeaderValuesArray = (accessControlRequestHeaderValues.toLowerCase()).split(",");
			for (var headerValue in accessControlRequestHeaderValuesArray) {
				if (allowedHeadersArray.indexOf((accessControlRequestHeaderValuesArray[headerValue].trim())) < 0) {
					return false;
				}
			}
			context.setVariable("accessControlAllowHeaders", accessControlRequestHeaderValues);
			return true;
		}
	}(context));

	var isValidPreflightRequest = (isValidOrigin && isValidMethod && isValidHeader);
	context.setVariable("isValidPreflightRequest", isValidPreflightRequest);
	context.setVariable("accessControlAllowCredentials", context.getVariable("cors_allow_credentials"));
	context.setVariable("accessControlMaxAge", context.getVariable("cors_max_age"));
};