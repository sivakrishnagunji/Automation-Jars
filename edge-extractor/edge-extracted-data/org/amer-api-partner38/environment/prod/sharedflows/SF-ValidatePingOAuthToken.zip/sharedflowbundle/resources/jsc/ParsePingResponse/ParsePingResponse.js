parsePingResponse = function parsePingResponse() {
    var pingResponse = JSON.parse(context.getVariable("ServiceCallout.response"));
    context.setVariable("pingResponse", pingResponse);

    if(pingResponse.firstName === "John") { //pingResponse.active === true
        if (pingResponse.lastName) { //pingResponse.client_id
    		var whitelistedClientApps = context.getVariable("whitelisted_client_apps").replace(/\s/g, "");
    		whitelistedClientApps = whitelistedClientApps.split(",");
    
    		context.setVariable("WhitelistedClientAppsArray", whitelistedClientApps.toString());
            context.setVariable("ArrayIndex", whitelistedClientApps.indexOf(pingResponse.lastName));
    
            if (whitelistedClientApps.indexOf(pingResponse.lastName) == -1) {
                context.setVariable("errorJSON", '{ "fault": { "faultstring": "Invalid or expired OAuth Token or belongs to unauthorized client", "detail": { "errorcode": "401 Unauthorized" } } }');
                context.setVariable("statusCode", "401");
                context.setVariable("reasonPhrase", "Unauthorized");
                throw "invalidOAuthException";
            }
        }
    } else {
        context.setVariable("errorJSON", '{ "fault": { "faultstring": "Invalid or expired OAuth Token or belongs to unauthorized client", "detail": { "errorcode": "401 Unauthorized" } } }');
        context.setVariable("statusCode", "401");
        context.setVariable("reasonPhrase", "Unauthorized");
        throw "invalidOAuthException";
    }
};