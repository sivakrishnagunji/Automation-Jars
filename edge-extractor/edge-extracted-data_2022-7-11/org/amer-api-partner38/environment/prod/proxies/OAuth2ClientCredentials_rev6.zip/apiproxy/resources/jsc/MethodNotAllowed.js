context.setVariable("exceptionName", "Method Not Allowed");
context.setVariable("statusCode", 405);
context.setVariable("reasonPhrase", "Method Not Allowed");
throw "invalidMethodError";