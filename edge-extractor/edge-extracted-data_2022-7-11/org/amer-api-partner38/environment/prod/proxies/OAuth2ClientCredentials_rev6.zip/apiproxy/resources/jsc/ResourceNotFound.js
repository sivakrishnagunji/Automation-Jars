context.setVariable("exceptionName", "Resource Not Found");
context.setVariable("statusCode", 404);
context.setVariable("reasonPhrase", "Not Found");
throw "invalidMethodError";