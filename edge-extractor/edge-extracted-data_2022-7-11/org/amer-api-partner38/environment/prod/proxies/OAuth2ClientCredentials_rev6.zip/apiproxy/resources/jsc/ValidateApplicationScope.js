	var appDetailsJson = context.getVariable("appDetailsJson");
	var scope = context.getVariable("scope");
	var error = "";
	var receivedScope = "";
	var receivedScopes = scope.split(" ");
	var obj = JSON.parse(appDetailsJson);
	var apiProductsList = obj.App.Credentials.Credential.ApiProducts.ApiProduct;
	context.setVariable("apiProductsList", JSON.stringify(apiProductsList));
	var appScopes = new Array();
	var productScope = "";
	var sandboxPrefix = context.getVariable("sandboxPrefix");

	if (!scope) {
		error = "invalid_scope";

	} else {

		if (apiProductsList instanceof Array) {
			for (var pro in apiProductsList) {
				if (apiProductsList[pro].Status.toLowerCase() === "approved") {
					productScope = apiProductsList[pro].Name;
					productScope = productScope.replace(sandboxPrefix, "");
					appScopes.push(productScope);
				}
			}
		} else if (apiProductsList.Status.toLowerCase() === "approved") {
			productScope = apiProductsList.Name;
			productScope = productScope.replace(sandboxPrefix, "");
			appScopes.push(productScope);
		}
		var appScopeSize = appScopes.length;
		var counter = 0;

		for (var i = 0 ; i < receivedScopes.length; i++) {
			counter = 0;
			receivedScope = receivedScopes[i];
			for (var j = 0; j < appScopes.length;j++) {
				var appScope = appScopes[j];
				context.setVariable("debugMessage", appScopes[j]);
				if (receivedScope !== appScope){
					counter++;
				}
			}
			if (counter === appScopeSize) {
				error = "invalid_scope";
				break;
			}
		}
	}

	if (error) {
		context.setVariable("exceptionName", error);
		context.setVariable("statusCode", 403);
		context.setVariable("reasonPhrase", "Forbidden");
		throw "invalid_scope";
	}