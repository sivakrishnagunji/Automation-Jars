require('../jsc/GenerateErrorVariables/GenerateErrorVariables');
describe('NetworkHttpStatus Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Case 1: Customized error json', function() {
        var errorJSON = { "statusCode": "500", "reasonPhrase": "Internal Server Error", "errorCode": "server_error", "errorDescription": "The authorization server encountered an unexpected condition that prevented it from fulfilling the request"};
        context.setVariable("errorJSON","customizedErrorJSON");
        context.setVariable("customizedErrorJSON",JSON.stringify(errorJSON));
        expect(generateErrorVariables()).toBe();
    });
    it ('Case 2: error json a42_generic_internal_config_error', function() {
        context.setVariable("errorJSON","a42_generic_internal_config_error");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Case 3: error json a42_generic_internal_config_error', function() {
        context.setVariable("fault.name","InvalidAPICallAsNoApiProductMatchFound");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 4: error json a42_generic_invalid_country_id', function() {
        context.setVariable("errorJSON","a42_generic_invalid_country_id");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('403');
    });
    it ('Case 5: error json a42_generic_developerapp_profile_access_error', function() {
        context.setVariable("errorJSON","a42_generic_developerapp_profile_access_error");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Case 6: error json a42_generic_invalid_origin', function() {
        context.setVariable("errorJSON","a42_generic_invalid_origin");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('403');
    });
    it ('Case 7: error json a42_generic_invalid_method', function() {
        context.setVariable("errorJSON","a42_generic_invalid_method");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('405');
    });
    it ('Case 8: error json a42_generic_invalid_ip', function() {
        context.setVariable("errorJSON","a42_generic_invalid_ip");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('403');
    });
    it ('Case 9: error json a42_generic_invalid_request_parameter', function() {
        context.setVariable("errorJSON","a42_generic_invalid_request_parameter");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 10: error json a42_generic_invalid_json_format', function() {
        context.setVariable("errorJSON","a42_generic_invalid_json_format");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 11: error json a42_generic_insufficient_scope', function() {
        context.setVariable("errorJSON","a42_generic_insufficient_scope");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('403');
    });
    it ('Case 12: error json a42_generic_invalid_scope_for_api', function() {
        context.setVariable("errorJSON","a42_generic_invalid_scope_for_api");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 13: error json a42_generic_resource_not_found', function() {
        context.setVariable("errorJSON","a42_generic_resource_not_found");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('404');
    });
    it ('Case 14: error json a42_generic_invalid_authorization_header', function() {
        context.setVariable("errorJSON","a42_generic_invalid_authorization_header");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 15: error json a42_generic_invalid_content_type_header', function() {
        context.setVariable("errorJSON","a42_generic_invalid_content_type_header");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('415');
    });
    it ('Case 16: error json a42_generic_invalid_accept_header', function() {
        context.setVariable("errorJSON","a42_generic_invalid_accept_header");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('406');
    });
    it ('Case 17: error json a42_generic_invalid_accept_charset', function() {
        context.setVariable("errorJSON","a42_generic_invalid_accept_charset");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('406');
    });
    it ('Case 18: error json a42_generic_internal_server_error', function() {
        context.setVariable("errorJSON","a42_generic_internal_server_error");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Case 19:Fault name as InvalidClientIdForGivenResource', function() {
        context.setVariable("fault.name","InvalidClientIdForGivenResource");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 20:Fault name as invalid_access_token', function() {
        context.setVariable("fault.name","invalid_access_token");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 21:Fault name as InvalidBasicAuthenticationSource', function() {
        context.setVariable("fault.name","InvalidBasicAuthenticationSource");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 22:Fault name as access_token_expired', function() {
        context.setVariable("fault.name","access_token_expired");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 23:Fault name as access_token_not_approved', function() {
        context.setVariable("fault.name","access_token_not_approved");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Case 24:Fault name as SpikeArrestViolation', function() {
        context.setVariable("fault.name","SpikeArrestViolation");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('429');
    });
    it ('Case 25:Fault name as QuotaViolation', function() {
        context.setVariable("fault.name","QuotaViolation");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('429');
    });
    it ('Case 26:Fault name as JsonPathParsingFailure', function() {
        context.setVariable("fault.name","JsonPathParsingFailure");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 27:Fault name as ServiceUnavailable', function() {
        context.setVariable("fault.name","ServiceUnavailable");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Case 28: error json a42_oauth_invalid_scope_combination', function() {
        context.setVariable("errorJSON","a42_oauth_invalid_scope_combination");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Case 30: if customized error, errorJSON and faultname is empty/not available', function() {
        context.setVariable("message.status.code","503");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('503');
    });
    it ('Case 31: if customized error, errorJSON and faultname is empty/not available', function() {
        context.setVariable("message.status.code","504");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('504');
    });
    it ('Case 32: if customized error, errorJSON and faultname is empty/not available', function() {
        context.setVariable("message.status.code","500");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Case 33: if customized error, errorJSON and faultname is empty/not available', function() {
        context.setVariable("message.status.code","502");
        expect(generateErrorVariables()).toBe();
        expect(context.getVariable("statusCode")).toBe('502');
    });
    
});