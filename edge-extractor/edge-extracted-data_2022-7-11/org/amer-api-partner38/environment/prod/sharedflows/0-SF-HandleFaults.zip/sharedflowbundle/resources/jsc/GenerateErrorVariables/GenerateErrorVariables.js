generateErrorVariables = function GenerateErrorVariables() { // eslint-disable-line no-undef
	var errorJSON = context.getVariable("errorJSON");
	var errorPayload = "";
	var reasonPhrase = "";
	var description = "";
	var errMessage = "";
	var statusCode = "";

	if (errorJSON && context.getVariable(errorJSON)) {
		errorPayload = JSON.parse(context.getVariable(errorJSON));
		reasonPhrase = errorPayload.reasonPhrase;
		description = errorPayload.errorDescription;
		errMessage = errorPayload.errorCode;
		statusCode = errorPayload.statusCode;

	} else if (errorJSON) {
		switch (errorJSON) {
		case "a42_generic_internal_config_error":
			statusCode = "500";
			reasonPhrase = "Internal Server Error";
			errMessage = "server_error";
			description = "The service is currently not available. Please try again later";
			break;
		case "a42_generic_invalid_country_id":
			statusCode = "403";
			reasonPhrase = "Forbidden";
			errMessage = "invalid_request";
			description = "Service is not whitelisted for this country";
			break;
		case "a42_generic_developerapp_profile_access_error":
			statusCode = "500";
			reasonPhrase = "Internal Server Error";
			errMessage = "server_error";
			description = "Incorrect developer app profile";
			break;
		case "a42_generic_invalid_origin":
			statusCode = "403";
			reasonPhrase = "Forbidden";
			errMessage = "invalid_request";
			description = "Invalid origin";
			break;
		case "a42_generic_invalid_method":
			statusCode = "405";
			reasonPhrase = "Method Not Allowed";
			errMessage = "Method Not Allowed";
			description = "The request method is not supported by this resource";
			break;
		case "a42_generic_invalid_ip":
			statusCode = "403";
			reasonPhrase = "Forbidden";
			errMessage = "invalid_request";
			description = "Invalid IP";
			break;
		case "a42_generic_invalid_request_parameter":
			statusCode = "400";
			reasonPhrase = "Bad Request";
			errMessage = "invalid_request";
			description = "The request parameter is invalid";
			break;
		case "a42_generic_invalid_json_format":
			statusCode = "400";
			reasonPhrase = "Bad Request";
			errMessage = "invalid_request";
			description = "The request payload is not in a valid JSON format";
			break;
		case "a42_generic_insufficient_scope":
			statusCode = "403";
			reasonPhrase = "Forbidden";
			errMessage = "insufficient_scope";
			description = "The request requires higher privileges than provided by the access token";
			break;
		case "a42_generic_invalid_scope_for_api":
			statusCode = "400";
			reasonPhrase = "Bad Request";
			errMessage = "invalid_scope";
			description = "The scope is valid but not associated with this API";
			break;
		case "a42_oauth_invalid_scope_combination":
			statusCode = "400";
			reasonPhrase = "Bad Request";
			errMessage = "invalid_scope";
			description = "Invalid Scope Combination";
			break;
		case "a42_generic_resource_not_found":
			statusCode = "404";
			reasonPhrase = "Not Found";
			errMessage = "Resource Not Found";
			description = "URI does not represent a recognised resource";
			break;
		case "a42_generic_invalid_authorization_header":
			statusCode = "401";
			reasonPhrase = "Unauthorized";
			errMessage = "access_denied";
			description = "Service Error - Invalid Authorization header";
			break;
		case "a42_generic_invalid_content_type_header":
			statusCode = "415";
			reasonPhrase = "Unsupported Media Type";
			errMessage = "Unsupported Media Type";
			description = "The value of the Content-Type header is invalid";
			break;
		case "a42_generic_invalid_accept_header":
			statusCode = "406";
			reasonPhrase = "Not Acceptable";
			errMessage = "Not Acceptable";
			description = "The Accept header is invalid";
			break;
		case "a42_generic_invalid_accept_charset":
			statusCode = "406";
			reasonPhrase = "Not Acceptable";
			errMessage = "Not Acceptable";
			description = "The server cannot return a response that satisfies the Accept-Charset Header";
			break;
		default:
			statusCode = "500";
			description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
			errMessage = "server_error";
			reasonPhrase = "Internal Server Error";
			break;
		}
	} else {
		var faultName = context.getVariable("fault.name");
		if (faultName) {
			switch (faultName) {
			case "access_token_expired":
				statusCode = "401";
				reasonPhrase = "Unauthorized";
				errMessage = "invalid_token";
				description = "The access token expired";
				break;
			case "invalid_access_token":
				statusCode = "401";
				reasonPhrase = "Unauthorized";
				errMessage = "invalid_token";
				description = "The access token is invalid";
				break;
			case "SpikeArrestViolation":
				statusCode = "429";
				reasonPhrase = "Too Many Requests";
				errMessage = "Too Many Requests";
				description = "Spike Arrest Violation";
				break;
			case "QuotaViolation":
				statusCode = "429";
				reasonPhrase = "Too Many Requests";
				errMessage = "Too Many Requests";
				description = "App Quota limit reached";
				break;
			case "InvalidAPICallAsNoApiProductMatchFound":
				statusCode = "401";
				reasonPhrase = "Unauthorized";
				errMessage = "access_denied";
				description = "The app is not authorized for this API";
				break;
			case "InvalidClientIdForGivenResource":
				statusCode = "400";
				reasonPhrase = "Bad Request";
				errMessage = "invalid_scope";
				description = "missing or invalid scope";
				break;
			case "access_token_not_approved":
				statusCode = "401";
				reasonPhrase = "Unauthorized";
				errMessage = "invalid_token";
				description = "The access token has been revoked";
				break;
			case "InvalidBasicAuthenticationSource":
				statusCode = "401";
				reasonPhrase = "Unauthorized";
				errMessage = "access_denied";
				description = "Service Error - Invalid Authorization header";
				break;
			case "JsonPathParsingFailure":
				statusCode = "400";
				reasonPhrase = "Bad Request";
				errMessage = "invalid_request";
				description = "The request payload is not in a valid JSON format";
				break;
			default:
				statusCode = "500";
				description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
				errMessage = "server_error";
				reasonPhrase = "Internal Server Error";
				break;
			}
		} else {
			var httpStatusCode = context.getVariable("message.status.code");
			switch (httpStatusCode) {
			case "502":
				statusCode = "502";
				reasonPhrase = "Bad Gateway";
				errMessage = "server_error";
				description = "Error connecting to an upstream server";
				break;
			case "503":
				statusCode = "503";
				reasonPhrase = "Service Unavailable";
				errMessage = "server_error";
				description = "An upstream server is unavailable";
				break;
			case "504":
				statusCode = "504";
				reasonPhrase = "Gateway Time-out";
				errMessage = "server_error";
				description = "A time-out occurred connecting to an upstream server";
				break;
			default:
				statusCode = "500";
				description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
				errMessage = "server_error";
				reasonPhrase = "Internal Server Error";
				break;
			}

		}
	}

	context.setVariable("reasonPhrase", reasonPhrase);
	context.setVariable("description", description);
	context.setVariable("errMessage", errMessage);
	context.setVariable("statusCode", statusCode);

	context.setVariable("flow.error.message", errMessage);
	context.setVariable("flow.error.status", statusCode);

	var dateForFault = new Date().toISOString();
	context.setVariable("dateForFault", dateForFault);
};
