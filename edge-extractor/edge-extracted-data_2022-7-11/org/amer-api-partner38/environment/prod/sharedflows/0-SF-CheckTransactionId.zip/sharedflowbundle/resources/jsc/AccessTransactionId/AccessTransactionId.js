function generateUUID() { // eslint-disable-line no-use-before-define
	var d = new Date().getTime();
	var uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
		function(c) {
			var r = ((d + (Math.random() * 16)) % 16) | 0; // eslint-disable-line no-bitwise
			d = Math.floor(d / 16);
			return (c === "x" ? r : ((r & 0x3) | 0x8)).toString(16); // eslint-disable-line no-bitwise
		});
	return uuid;
}
accessTransactionId = function accessTransactionId(){ // eslint-disable-line no-undef
	var transactionId = context.getVariable("request.header.transactionId");
	if (transactionId) {
		context.setVariable("transactionId", transactionId);
	} else {
		transactionId = generateUUID();
		context.setVariable("transactionId", transactionId);
	}
};