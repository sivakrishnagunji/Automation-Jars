try {
	generateLogContent();
} catch (err) {
	throw err;
}