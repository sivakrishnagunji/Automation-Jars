try {
	checkHeaders(); // eslint-disable-line no-undef
} catch (e){
	throw error;
}