function validateHeaders(HeaderList, validationOutHeaders) {
	if (HeaderList !== "[]") {
		var validationOHeader = validationOutHeaders.toLowerCase();
		var validationOHeadersArray = validationOHeader.split(",");
		validationOHeadersArray = validationOHeadersArray.map(function (el) {
			return el.trim();
		});
		var HeaderListArray = HeaderList.split(",");

		for (var i = 0; i < HeaderListArray.length; i++) {
			var headerNameInLowerCase = HeaderListArray[i].trim().toLowerCase();

			if (validationOHeadersArray.indexOf(headerNameInLowerCase) === -1) {
				context.removeVariable("response.header." + headerNameInLowerCase);
			}
		}
		return 1;
	} else {
		return -1;
	}
}
/* eslint-disable */
accessOutHeaders = function AccessOutHeaders() {
	/* eslint-enable */
	try {
		var validationOutHeaders = context.getVariable("validation_out_headers");
		var HeaderList = context.getVariable("response.headers.names") + ""; // any type of variable concatenate with string result a string
		var errorJSON;

		if (validationOutHeaders) {
			validateHeaders(HeaderList, validationOutHeaders);
			/** if (HeaderList !== "[]") {
				validationOutHeaders = validationOutHeaders.toLowerCase();
				var validationOutHeadersArray = validationOutHeaders.split(", ");

				HeaderList = HeaderList.substr(1, HeaderList.length - 2);
				var HeaderListArray = HeaderList.split(", ");

				for (var i = 0;i < HeaderListArray.length;i++) {
					if (validationOutHeadersArray.indexOf(HeaderListArray[i].toLowerCase()) === -1) {
						context.removeVariable("response.header." + HeaderListArray[i]);
					}
				}
			} **/
		} else {
			errorJSON = "a42_generic_internal_config_error";
			context.setVariable("errorJSON", errorJSON);
			throw "internalConfigError";
		}
	} catch (err) {
		throw err;
	}
};