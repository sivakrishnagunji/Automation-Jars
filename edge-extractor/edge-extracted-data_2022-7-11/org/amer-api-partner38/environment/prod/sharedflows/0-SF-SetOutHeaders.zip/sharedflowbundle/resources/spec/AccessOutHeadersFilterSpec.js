var AccessOutHeadersFilterVar = require('../jsc/AccessOutHeadersFilter/AccessOutHeadersFilter.js');
describe('AccessOutHeadersFilter Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });
	
	it ('Negative: Empt header list', function()
	{
		context.setVariable("validation_out_headers","Content-Type, Host, Access-Control-Request-Headers, Accept");
		context.setVariable("response.headers.names","[]");
		// context.setVariable("response.header.ACcept","ACcept");
		// context.setVariable("response.header.Access-Control-Request-Headers","Access-Control-Request-Headers");
		// context.setVariable("response.header.Access-Control-Request-Method","Access-Control-Request-Method");
		// context.setVariable("response.header.Content-Length","Content-Length");

		expect(accessOutHeaders()).toBe();

		// expect(context.getVariable("response.header.ACcept")).toBe("ACcept");
		// expect(context.getVariable("response.header.Access-Control-Request-Headers")).toBe("Access-Control-Request-Headers");
		// expect(context.getVariable("response.header.Access-Control-Request-Method")).toBe("");
		// expect(context.getVariable("response.header.Content-Length")).toBe("");
    }
	);
     
    it ('Positive: RemoveFewHeaders-few invalid', function()
	{
		context.setVariable("validation_out_headers","Content-Type, Host, Access-Control-Request-Headers, Accept");
		context.setVariable("response.headers.names","[ACcept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length]");
		// context.setVariable("response.header.ACcept","ACcept");
		// context.setVariable("response.header.Access-Control-Request-Headers","Access-Control-Request-Headers");
		// context.setVariable("response.header.Access-Control-Request-Method","Access-Control-Request-Method");
		// context.setVariable("response.header.Content-Length","Content-Length");

		expect(accessOutHeaders()).toBe();

		// expect(context.getVariable("response.header.ACcept")).toBe("ACcept");
		// expect(context.getVariable("response.header.Access-Control-Request-Headers")).toBe("Access-Control-Request-Headers");
		// expect(context.getVariable("response.header.Access-Control-Request-Method")).toBe("");
		// expect(context.getVariable("response.header.Content-Length")).toBe("");
    }
	);
	it ('Positive: DontRemoveHeaders-all valid', function()
	{
		context.setVariable("validation_out_headers","Content-Type, Host, Access-Control-Request-Headers, Accept");
		context.setVariable("response.headers.names","[ACcept, Access-Control-Request-Headers]");
		context.setVariable("response.header.ACcept","ACcept");
		context.setVariable("response.header.Access-Control-Request-Headers","Access-Control-Request-Headers");

		expect(accessOutHeaders()).toBe();

		expect(context.getVariable("response.header.ACcept")).toBe("ACcept");
		expect(context.getVariable("response.header.Access-Control-Request-Headers")).toBe("Access-Control-Request-Headers");
    }
	);
	
	it ('Negative: Novalidation_out_headers', function()
	{
		context.setVariable("response.headers.names","[content-type, HOST, LocAtIon, accept, Origin, Access-Control-Request-Headers]");

		expect(accessOutHeaders).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: Nullvalidation_out_headers', function()
	{
		context.setVariable("validation_out_headers","");
		context.setVariable("response.headers.names","[content-type, HOST, LocAtIon, accept, Origin, Access-Control-Request-Headers]");

		expect(accessOutHeaders).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	
	it ('Negative: No/NullHeaderList', function()
	{
		
		var validationInHeaders= {
			"content-type": {
				"validate": true,
				"format": "ACCEPT_HEADER"
			}

	};
	context.setVariable("response.headers.names","[something,something]");
		context.setVariable("validation_out_headers","Content-Type, Host, Location, Accept");
		
		expect(accessOutHeaders()).toBe();
    }
	);

	it ('Negative: response.headers.names is array', function()
	{
		context.setVariable("validation_out_headers","[content-type]");
		context.setVariable("response.headers.names",["content-type"]);

		expect(accessOutHeaders()).toBe();
    }
	);
	
});