function typeFormatter(formatSpecified) {
	var regex;
	switch (formatSpecified) {
	case "EMAIL":
		regex = new RegExp(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/);
		return regex;

	case "DATE_TIME":
		regex = new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i);
		return regex;

	case "ACCEPT_HEADER":
		regex = new RegExp(/^[ A-Za-z0-9*./;,=+]*$/);
		return regex;

	case "ALPHA_NUMERIC":
		regex = new RegExp(/^[A-Za-z0-9]*$/);
		return regex;

	case "NUMERIC":
		regex = new RegExp(/^[0-9]*$/);
		return regex;

	case "COUNTRY_CODE":
		regex = new RegExp(/^[A-Z]{2}$/);
		return regex;
	default :
		return regex;

	}

}

function isValidDateTimeFormat(dateTime) {
	var patt = new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i);
	return patt.test(dateTime);
}

function checkType(validationHeaderObject, headerValue){
	if (validationHeaderObject.validate && validationHeaderObject.type) {
		switch (validationHeaderObject.type) {
		case "string":
			if (typeof headerValue !== "string") {
				context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
				throw "internalConfigError";
			}
			break;
		case "number":
			if (typeof headerValue !== "number") {
				context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
				throw "internalConfigError";
			}
			break;
		case "dateTime":
			if (!isValidDateTimeFormat()) {
				context.setVariable("errorJSON", "a42_generic_invalid_request_header_date_format");
				throw "internalConfigError";
			}
			break;
		default:
			break;
		}
	} else if (!validationHeaderObject.type){
		// var formatSpecified = validationHeaderobject.format;
		var myRegex = typeFormatter(validationHeaderObject.format);
		if (myRegex){
			var result = myRegex.test(headerValue);
			if (!result) {
				context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
				throw "internalConfigError";
			}
		}
	}
}

function isJSON(myStr){
	if (typeof(myStr) === "string"){
		return false;
	}
	context.setVariable("isJson", true);
	return true;
}

/* eslint-disable */
accessInHeadersFilter = function AccessInHeadersFilter() {
	/* eslint-enable */
	try {
		var validationInHeaders = context.getVariable("validation_in_headers");
		var HeaderList = context.getVariable("request.headers.names") + "";
		var HeaderListArray = HeaderList.split(", ");
		var errorJSON;

		if (!validationInHeaders){
			errorJSON = "a42_generic_internal_config_error";
			context.setVariable("errorJSON", errorJSON);
			throw "internalConfigError";
		} else if (validationInHeaders && isJSON(validationInHeaders) && HeaderList !== "[]") {
			var j = 0;
			HeaderList = HeaderList.substr(1, HeaderList.length - 2);
			for (j = 0;j < HeaderListArray.length;j++) {
				var headerNameInLowerCase = HeaderListArray[j].toLowerCase();
				headerNameInLowerCase = headerNameInLowerCase.substr(0, headerNameInLowerCase.length - 2);
				var validationHeaderobject = validationInHeaders[headerNameInLowerCase];
				if (validationHeaderobject === undefined) {
					context.removeVariable("request.header." + HeaderListArray[j]);
				} else {
					context.setVariable("headerObject" + headerNameInLowerCase, JSON.stringify(validationHeaderobject));
					var headersValue = context.getVariable("request.header." + HeaderListArray[j]);
					checkType(validationHeaderobject, headersValue);
				}
			}
		} else if (HeaderList !== "[]") {
			validationInHeaders = validationInHeaders.toLowerCase();
			var validationInHeadersArray = validationInHeaders.split(", ");
			HeaderList = HeaderList.substr(1, HeaderList.length - 2);
			for (var i = 0;i < HeaderListArray.length;i++) {
				if (validationInHeadersArray.indexOf(HeaderListArray[i].toLowerCase()) === -1) {
					context.removeVariable("request.header." + HeaderListArray[i]);
				}
			}
		}
	} catch (err) {
		throw err;
	}
};


