/**
 * 
 */
var AccessHeadersPropagationNB = require('../jsc/AccessHeadersNB/AccessHeadersPropagationNB.js');
describe('NetworkHttpStatus Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it ('Test : VF_EXT_BP_ID exists', function() {
       context.setVariable("VF_EXT_BP_ID_req","value");     
       expect(accessHeadersNB()).toBe();
       expect(context.getVariable("request.header.VF_EXT_BP_ID")).toBe("value");
    });

    it ('Test : VF_EXT_REFERENCE_ID exists', function() {
        context.setVariable("VF_EXT_REFERENCE_ID_req","value");     
        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_EXT_REFERENCE_ID")).toBe("value");
     });

     it ('Test : VF_EXT_TRACE_ID exists', function() {
        context.setVariable("VF_EXT_TRACE_ID_req","value");     
        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_EXT_TRACE_ID")).toBe("value");
     });

     it ('Test : VF_INT_CALLER_ID exists', function() {
        context.setVariable("VF_INT_CALLER_ID_req","value_id");     
        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_INT_CALLER_ID")).toBe("value_id");
     });

     it ('Test : VF_INT_CALLER_ID not exists but orgUUID exists', function() {
        context.setVariable("app.vf_app_org_uuid","value");    
        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_INT_CALLER_ID")).toBe("value");
        expect(context.getVariable("VF_INT_CALLER_ID_req")).toBe("value");
     });

     it ('Test : VF_INT_TRACK_ID exists', function() {  
        context.setVariable("VF_INT_TRACK_ID_req","value");   
        context.setVariable("apiproxy.name","TrustedContacts");

        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_INT_TRACK_ID")).toBe("value.TrustedContacts-apix");
        expect(context.getVariable("VF_INT_TRACK_ID_req")).toBe("value.TrustedContacts-apix");
     });

     it ('Test : VF_INT_TRACE_ID exists and vfTraceTransactionId not exists', function() {  
        context.setVariable("VF_INT_TRACE_ID_req","value");   

        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_INT_TRACE_ID")).toBe("value");
        expect(context.getVariable("request.header.vf-trace-transaction-id")).toBe("value");
        expect(context.getVariable("vfTraceTransactionId_req")).toBe("value");
     });

     it ('Test : VF_INT_TRACE_ID not exists and vfTraceTransactionId exists', function() {  
        context.setVariable("vfTraceTransactionId_req","v");

        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.vf-trace-transaction-id")).toBe("v");

     });

     it ('Test : VF_INT_TRACE_ID exists and vfTraceTransactionId exists', function() {  
        context.setVariable("vfTraceTransactionId_req","v");
        context.setVariable("VF_INT_TRACE_ID_req","value"); 

        expect(accessHeadersNB()).toBe();
        expect(context.getVariable("request.header.VF_INT_TRACE_ID")).toBe("value");
        expect(context.getVariable("request.header.vf-trace-transaction-id")).toBe("v");

     });

    
});