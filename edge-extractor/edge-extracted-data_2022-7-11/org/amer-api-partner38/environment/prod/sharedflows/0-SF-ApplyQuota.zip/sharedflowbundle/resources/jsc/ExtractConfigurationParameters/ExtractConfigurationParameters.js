// Javascript policy for reading the list of parameters configured in Baas for the API Proxy
/* eslint-disable */
extractConfigurationParameters = function ExtractConfigurationParameters() {
	/* eslint-enable */
	var payload = context.getVariable("apiConfig");
	var jsonObject = JSON.parse(payload);

	// Loop through the KVM response and create a variable for each entry found
	/* eslint-disable */
	for (var key in jsonObject) {
		context.setVariable(key, jsonObject[key]);
	}
	/* eslint-enable */
};