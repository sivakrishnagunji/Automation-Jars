var applyQuotaSpec = require('../jsc/ExtractConfigurationParameters/ExtractConfigurationParameters.js');

describe('ExtractQuotas Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it(" apiConfig is present",function() {
        context.setVariable("apiConfig","{\"key\":\"value\"}");
        expect(extractConfigurationParameters()).toBe();
        expect(context.getVariable("key")).toBe("value");
    });

    it("apiConfig is empty ",function() {
        context.setVariable("apiConfig","{}");
        expect(extractConfigurationParameters()).toBe();
    });

  
    it("apiConfig is empty ",function() {
        context.setVariable("apiConfig","{}");
        expect(extractConfigurationParameters()).toBe();
    });
    
});