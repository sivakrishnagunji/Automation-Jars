try {
	parsePingResponse();
} catch (err) {
	throw err;
}