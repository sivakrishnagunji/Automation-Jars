var tokenscopes = context.getVariable("accesstoken.scope");
tokenscopes =  tokenscopes.split(" ");

var scopeConfig = JSON.parse(context.getVariable("private.scopeConfig"));

var apiScopes = scopeConfig.api_scopes;
var valid_api_scopes = false;

//API level scope Validation
if(apiScopes) {
	apiScopes =  apiScopes.split(",");
	for (var i = 0; tokenscopes.length > i; i++) {
		if(apiScopes.indexOf(tokenscopes[i]) > -1) {
			valid_api_scopes = true;
			break;
		}
	}
}

if(!valid_api_scopes) {
	context.setVariable("errorJSON", '{ "fault": { "faultstring": "The scope of the access_token is not valid for this this API", "detail": { "errorcode": "403 Forbidden" } } }');
	context.setVariable("statusCode", "403");
	context.setVariable("reasonPhrase", "Forbidden");
	throw "invalidScopeError";
}

//Resource Level Scope Validation
var flowName = context.getVariable("current.flow.name");
var valid_resource_scopes = false;
var flowScopes;

flowScopes = scopeConfig[flowName].allowedScopesList;

context.setVariable("flowScopes", flowScopes);

if (flowScopes) {
	flowScopes =  flowScopes.split(",");
	for(var i = 0; flowScopes.length > i; i++) {
		if(tokenscopes.indexOf(flowScopes[i]) > -1) {
			valid_resource_scopes = true;
			break;
		}
	}	
}

if (!valid_resource_scopes) {
	context.setVariable("errorJSON", '{ "fault": { "faultstring": "The request requires higher privileges (scope) than provided by the access token", "detail": { "errorcode": "403 Forbidden" } } }');
	context.setVariable("statusCode", "403");
	context.setVariable("reasonPhrase", "Forbidden");
	throw "insufficientScopeError";
}