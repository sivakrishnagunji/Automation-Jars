// Javascript policy for reading the list of parameters configured in Baas for the API Proxy
/* eslint-disable */
VerifyApiSecret = function VerifyApiSecret() {
	/* eslint-enable */
	var app_client_secret = context.getVariable('verifyapikey.Verify-API-Key-1.client_secret')
    var req_client_secret = context.getVariable('client_secret')

	/* eslint-disable */
	if(!(app_client_secret === req_client_secret)){
     context.setVariable("triggerError", "true");
    }
	/* eslint-enable */
};