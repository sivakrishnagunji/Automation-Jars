loggingContent = function LoggingContent() {

	try{
		var transactionID = context.getVariable('transactionId') ;
		var loggingPayloadEnabled = context.getVariable('logging_payload_enabled') || true;
		var oauthTokenDetails =  context.getVariable("oauthTokenDetails");
		var scheme = context.getVariable("target.scheme");
		var host = context.getVariable("target.host");
		var port = context.getVariable("target.port");
		var uri = context.getVariable("request.uri");
		var inboundRequestUri = context.getVariable("proxy.url");
		var errorJSON = context.getVariable("errorJSON");
		var err = context.getVariable("err");
		var desc = context.getVariable("description");
		var correlationId = context.getVariable('correlationId') || '';
		var HeaderList = context.getVariable('message.headers.names');
		var headers = '';
		var formParam = context.getVariable("message.formparams.names");
		var date = new Date();
		var dateForLog = date.toISOString();
		var payload = '';
		var oauthClientId = context.getVariable('client_id') || '';
		var reasonPhrase = '';
		var statusCode = '';
		var errorDescription = '';
		var errorCode = '';
		var envName = context.getVariable("environment.name");
		var spikeArrest = context.getVariable("spikearrest");
		var apiQuotaLimit = context.getVariable("quota");
		var callerId = context.getVariable("INT_CALLER_ID_req");
		var verb = context.getVariable("request.verb");
		var component= context.getVariable("apiproxy.name")
		//var flow = context.flow;
		var flow = context.getVariable(context.flow.name);
		if(context.getVariable("ContextFlowFlag")=="true")
		{
			flow = "ERROR";
		}
	var	logContent = {
				"transactionId":transactionID,
				"correlationTrackingId": correlationId,
				"envName":envName,
				"layer":"apix",
				"host":host,
				"port":port,
				"throttlingLimit":spikeArrest,
				"apiQuotaLimit":apiQuotaLimit,
				"callerId":callerId,
				"verb":verb,
				"component":component
				};
		if(errorJSON){
			errorJSON = JSON.parse(context.getVariable(errorJSON));
			if(errorJSON){
			reasonPhrase = errorJSON.reasonPhrase;
			statusCode = errorJSON.statusCode;
			errorDescription = errorJSON.errorDescription;
			errorCode=errorJSON.errorCode;}
		}
		if(loggingPayloadEnabled){
		
				logContent["payload"]=context.getVariable('message.content');
				logContent["contentType"]=context.getVariable('request.header.Content-Type');
				logContent["timestampIn"]=dateForLog;
				logContent["timestampOut"]='';
				logContent["inboundRequestURI"]=context.getVariable('request.path');
			context.setVariable("loggingContent", JSON.stringify(logContent));
			
		}
	}
	catch (err) {
	    context.setVariable("loggingContent", JSON.stringify(errorJSON));		
		throw err;
	}
		

};