var contenttype = context.getVariable ("request.header.Content-Type"); 
var Accept = context.getVariable ("request.header.Accept");

if (contenttype === "" && Accept === "") {
    throw "error";
} else if ( contenttype === "" && Accept !== ""){
  /*  var responsecontenttype = Accept ;*/
    context.setVariable("ws.responsecontenttype", Accept);
    
} else if ( contenttype !== "" && Accept === ""){
    /*var responsecontenttype = contenttype ;*/
    context.setVariable("ws.responsecontenttype", contenttype);
} else if ( contenttype !== "" && Accept !== ""){
    /*var responsecontenttype = Accept ;*/
     context.setVariable("ws.responsecontenttype", Accept);
}
    