try {
	populateErrorResponse();
} catch (err) {
	throw err;
}