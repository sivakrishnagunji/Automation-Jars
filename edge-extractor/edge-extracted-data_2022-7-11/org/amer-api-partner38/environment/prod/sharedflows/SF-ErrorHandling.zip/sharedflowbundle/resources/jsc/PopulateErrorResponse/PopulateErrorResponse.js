var errorJSON, messageContent, parsedJSON, statusCode, reasonPhrase, errorResponse, allowHeader;
populateErrorResponse = function populateErrorResponse() {
	try {
		errorJSON = context.getVariable("errorJSON");
		messageContent = context.getVariable("message.content");
		if (errorJSON) {
			parsedJSON = JSON.parse(errorJSON);
			statusCode = context.getVariable("statusCode");
			reasonPhrase = context.getVariable("reasonPhrase");
			context.setVariable("message.status.code", statusCode);
			context.setVariable("message.reason.phrase", reasonPhrase);
		} else if (messageContent) {
			parsedJSON = JSON.parse(messageContent);
			statusCode = context.getVariable("message.status.code");
			reasonPhrase = context.getVariable("message.reason.phrase");
		}
		// context.setVariable("parsedJSONFault", parsedJSON.fault);
		if (parsedJSON.fault) {
			// context.setVariable("InsideErrorHandler", "NotPassThru");
			errorResponse = {};
			errorResponse.requestId = context.getVariable("mwRequestId");
			errorResponse.correlationId = context.getVariable("mwCorrelationId");
			if (statusCode >= 400 && statusCode < 500) {
				errorResponse.code = "10-1-200" + statusCode;
				errorResponse.severity = "CRITICAL";
				errorResponse.description = "Client Error: " + parsedJSON.fault.faultstring;
			} else if (statusCode >= 500) {
				errorResponse.code = "10-0-100" + statusCode;
				errorResponse.severity = "ERROR";
				errorResponse.description = "Server Error: " + parsedJSON.fault.faultstring;
			}
			errorResponse.sourceSystem = "Middleware";
			context.setVariable("message.content", JSON.stringify(errorResponse));

			allowHeader = context.getVariable("allowHeader");
			if (allowHeader) {
				context.setVariable("message.header.Allow", allowHeader);
			}
		}
	} catch (err) {
		throw err;
	}
};