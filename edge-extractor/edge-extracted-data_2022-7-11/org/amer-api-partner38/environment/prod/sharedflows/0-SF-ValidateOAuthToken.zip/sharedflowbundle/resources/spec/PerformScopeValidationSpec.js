// To validate the query params. If not, set the error message
var performScopeValidationSpec = require('../jsc/4-JS-PerformScopeValidation/4-JS-PerformScopeValidation.js');

describe('performScopeValidationTest Suite', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
	
	 it ('Positive case 1: apiScopes Present', function() {
		context.setVariable("accesstoken.scope","TRUSTED_CONTACTS_READ");
		context.setVariable("apiScopes","TRUSTED_CONTACTS_READ");
		context.setVariable("current.flow.name","myAddressBook");
		context.setVariable("allowedScopes", "[{\"flowName\":\"home\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ,TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"myAddressBook\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"myAddressBookPatch\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactLists\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"CreateContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"ModifyContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"updateContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"deleteContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"}]");
        expect(performScopeValidation()).toBe();
    });
	
	 it ('Positive case 1: apiScopes not Present', function() {
		context.setVariable("accesstoken.scope","TRUSTED_CONTACTS_READ");
		context.setVariable("apiScopes","");
        expect(performScopeValidation).toThrow("insufficientScopeError");
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_scope_for_api");
    });
	 it ('Positive case 1: incorrect flow', function() {
		context.setVariable("accesstoken.scope","TRUSTED_CONTACTS_READ");
		context.setVariable("apiScopes","TRUSTED_CONTACTS_READ");
		context.setVariable("current.flow.name","noflowName");
		context.setVariable("allowedScopes","[{\"flowName\":\"home\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ,TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"myAddressBook\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"myAddressBookPatch\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactLists\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"CreateContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"ModifyContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"updateContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"deleteContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"}]");
        expect(performScopeValidation).toThrow("insufficientScopeError");
		expect(context.getVariable("errorJSON")).toBe("a42_generic_insufficient_scope");
    });
	 it ('Negative case 1: incorrect scope', function() {
		context.setVariable("accesstoken.scope","TRUSTED_CONTACTS");
		context.setVariable("apiScopes","TRUSTED_CONTACTS_WRITE");
		context.setVariable("current.flow.name","myAddressBook");
		context.setVariable("allowedScopes","[{\"flowName\":\"home\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ,TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"myAddressBook\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"myAddressBookPatch\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactLists\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"CreateContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"ModifyContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"updateContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"deleteContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"}]");
        expect(performScopeValidation).toThrow("insufficientScopeError");
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_scope_for_api");
    });
	it ('Negative case 1: incorrect allowed scope', function() {
		context.setVariable("accesstoken.scope","TRUSTED_CONTACTS_WRITE");
		context.setVariable("apiScopes","TRUSTED_CONTACTS_WRITE");
		context.setVariable("current.flow.name","myAddressBook");
		context.setVariable("allowedScopes","[{\"flowName\":\"home\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ,TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"myAddressBook\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"myAddressBookPatch\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactLists\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"CreateContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"ModifyContactList\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"getContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_READ\"},{\"flowName\":\"updateContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"},{\"flowName\":\"deleteContactListsByContactListId\",\"allowedScopesList\":\"TRUSTED_CONTACTS_WRITE\"}]");
        expect(performScopeValidation).toThrow("insufficientScopeError");
		expect(context.getVariable("errorJSON")).toBe("a42_generic_insufficient_scope");
    });
	
});