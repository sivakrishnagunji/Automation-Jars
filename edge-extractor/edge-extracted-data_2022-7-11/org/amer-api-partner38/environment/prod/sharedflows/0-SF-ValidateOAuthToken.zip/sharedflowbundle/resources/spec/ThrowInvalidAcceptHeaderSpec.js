var ThrowInvalidAcceptHeaderTest = require('../jsc/4-JS-InvalidAuthorizationHeader/4-JS-InvalidAuthorizationHeader.js');
describe('Throw Invalid Accept Header Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

it ('Negative: invalid Method ', function() {
		context.setVariable("errorJSON","a42_generic_invalid_authorization_header");
        expect(throwInvalidAcceptHeader).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_authorization_header");
    });

});