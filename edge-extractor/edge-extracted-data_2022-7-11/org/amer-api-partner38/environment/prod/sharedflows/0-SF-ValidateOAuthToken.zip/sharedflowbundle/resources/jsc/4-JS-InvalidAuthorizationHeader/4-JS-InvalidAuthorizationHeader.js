/* eslint-disable */
// raise fault for invalid Authorization Header
throwInvalidAcceptHeader = function ThrowInvalidAcceptHeader() {
    /* eslint-enable */
	context.setVariable("errorJSON", "a42_generic_invalid_authorization_header");
	throw "invalidAuthorizationheaderError";
};