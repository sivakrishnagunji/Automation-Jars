/* eslint-disable */
accessHeadersNB = function AccessHeadersNB() {
	/* eslint-enable */
	try {
		var INT_TRACE_ID = context.getVariable("INT_TRACE_ID_req");
		var TraceTransactionId = context.getVariable("transactionId_req");

		var INT_TRACK_ID = context.getVariable("correlationId_req");
		var apiName = context.getVariable("apiproxy.name");

		var INT_CALLER_ID = context.getVariable("INT_CALLER_ID_req");
		var orgUUID = context.getVariable("app.app_org_uuid") || "";

		var EXT_TRACE_ID = context.getVariable("EXT_TRACE_ID_req");
		var EXT_REFERENCE_ID = context.getVariable("EXT_REFERENCE_ID_req");
		var EXT_BP_ID = context.getVariable("EXT_BP_ID_req");

		if ((!INT_TRACE_ID) && (!TraceTransactionId)) {
			context.setVariable("request.header.transactionId", context.getVariable("transactionId"));
			context.setVariable("TraceTransactionId_req", context.getVariable("transactionId"));
		} else if ((INT_TRACE_ID) && (!TraceTransactionId)) {
			context.setVariable("request.header.INT_TRACE_ID", INT_TRACE_ID);
			context.setVariable("request.header.transactionId", INT_TRACE_ID);
			context.setVariable("TraceTransactionId_req", INT_TRACE_ID);
		} else if ((!INT_TRACE_ID) && (TraceTransactionId)) {
			context.setVariable("request.header.transactionId", TraceTransactionId);
		} else if ((INT_TRACE_ID) && (TraceTransactionId)) {
			context.setVariable("request.header.INT_TRACE_ID", INT_TRACE_ID);
			context.setVariable("request.header.transactionId", TraceTransactionId);
		}

		if (INT_TRACK_ID) {
			context.setVariable("request.header.correlationId", INT_TRACK_ID + "." + apiName + "-apix");
			context.setVariable("INT_TRACK_ID_req", INT_TRACK_ID + "." + apiName + "-apix");
			context.setVariable("correlationId",context.getVariable("request.header.correlationId"));
		} else {
			context.setVariable("request.header.correlationId", apiName + "-apix");
			context.setVariable("INT_TRACK_ID_req", apiName + "-apix");
			context.setVariable("correlationId",context.getVariable("request.header.correlationId"));
		}

		if (INT_CALLER_ID) {
			context.setVariable("request.header.INT_CALLER_ID", INT_CALLER_ID);
		} else if (orgUUID) {
			context.setVariable("request.header.INT_CALLER_ID", orgUUID);
			context.setVariable("INT_CALLER_ID_req", orgUUID);
		} else {
			context.setVariable("request.header.INT_CALLER_ID", "unknown");
			context.setVariable("INT_CALLER_ID_req", "unknown");
		}

		if (EXT_TRACE_ID) {
			context.setVariable("request.header.EXT_TRACE_ID", EXT_TRACE_ID);
		}
		if (EXT_REFERENCE_ID) {
			context.setVariable("request.header.EXT_REFERENCE_ID", EXT_REFERENCE_ID);
		}
		if (EXT_BP_ID) {
			context.setVariable("request.header.EXT_BP_ID", VF_EXT_BP_ID);
		}
	} catch (err) {
		context.setVariable("errorJSON", "a42_generic_internal_server_error");
		throw err;
	}
};