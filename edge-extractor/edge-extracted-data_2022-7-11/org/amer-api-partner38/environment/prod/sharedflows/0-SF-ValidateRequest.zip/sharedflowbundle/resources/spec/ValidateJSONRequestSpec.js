var validateJSON = require('../jsc/4-JS-Validate-JSON/4-JS-Validate-JSON.js');

describe('Validate JSON Suite', function() {
  beforeEach(function(){
      var Context = function(){
      };
      Context.prototype = {
          setVariable: function(propertyName, propertyValue){
          this[propertyName] = propertyValue;
          },
          getVariable: function(propertyName){
            return this[propertyName];
          }
      };
      context = new Context();
      var TV4 = function(){
   };
   TV4.prototype = {
       validate: function(payload, schema){
       if(typeof payload === schema.type){
           return true;
       }else{
           return false;
       }
       }
       
   };
       tv4 = new TV4();
  });


  it ('Test if playload is not present', function() {
   context.setVariable("request.content","");
   expect(validateJSONRequest()).toBe();
   expect(context.getVariable("raiseFaultRuleSchemaValidation")).toBe("true");
   expect(context.getVariable("raiseFaultRuleSchemaValidationMessage")).toBe("Incoming request empty");

});

it ('Test if Request Verb is wrong with POST', function() {
    context.setVariable("request.content","");
    context.setVariable("request.verb","POST");
    expect(validateJSONRequest).toThrow();
 });

 it ('Test if Request Verb is wrong with PUT', function() {
    context.setVariable("request.content","");
    context.setVariable("request.verb","PUT");
    expect(validateJSONRequest).toThrow();
 });

 it ('Test if Request Verb is wrong with PATCH', function() {
    context.setVariable("request.content","");
    context.setVariable("request.verb","PATCH");
    expect(validateJSONRequest).toThrow();
 });


  it ('Test if type object is not good  ', function() {
   context.setVariable("request.content","{\"foo\":\"bar\"}"); 
  // context.setVariable("request.verb","");    
   context.setVariable("jsonSchema","{\"type\":\"array\",\"properties\":{\"foo\":{\"type\":\"String\"}},\"required\":[\"foo\"]}");
   expect(validateJSONRequest).toThrow();
   expect(context.getVariable("raiseFaultRuleSchemaValidation")).toBe("true");
   expect(context.getVariable("raiseFaultRuleSchemaValidationMessage")).toBe(undefined);
});

it ('Test if type object is good', function() {
   context.setVariable("request.content","{\"foo\":\"bar\"}");   
  // context.setVariable("request.verb","");
   context.setVariable("jsonSchema","{\"type\":\"object\",\"properties\":{\"foo\":{\"type\":\"String\"}},\"required\":[\"foo\"]}");
   expect(validateJSONRequest()).toBe();    
});

it ('Test if schema is not present', function() {
   context.setVariable("request.content","{\"foo\":\"bar\"}");    
   context.setVariable("");
   expect(validateJSONRequest()).toBe();

});


 
});