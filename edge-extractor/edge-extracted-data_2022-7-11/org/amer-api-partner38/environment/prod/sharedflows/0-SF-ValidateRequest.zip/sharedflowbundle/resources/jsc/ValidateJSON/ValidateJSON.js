validateJSONRequest = function ValidateJSONRequest() {  // eslint-disable-line no-undef
	var schema = context.getVariable("jsonSchema");
	var payload = context.getVariable("request.content");
	var reqVerb = context.getVariable("request.verb");
	var jsonData = "";
	if (payload) {
		//context.setVariable("raiseFaultRuleSchemaValidation", "true");
		//context.setVariable("raiseFaultRuleSchemaValidationMessage", "Incoming request empty");
		if (reqVerb === "POST" || reqVerb === "PUT" || reqVerb === "PATCH") {
			try{
				jsonData = JSON.parse(payload);
			}catch(err){
				var customizedErrorMessage = {
						"statusCode": "400",
						"reasonPhrase": "Bad Request",
						"errorCode": "invalid_request",
						"errorDescription": "The request payload is not in valid JSON format"
					};
				context.setVariable("errorJSON", "customizedErrorMessage");
				context.setVariable("customizedErrorMessage", JSON
					.stringify(customizedErrorMessage));
				throw "invalidJSONException";
			}
		}
	} 
	if (schema) {
		/* eslint-disable */
		var valid = tv4.validate(jsonData, JSON.parse(schema));
		if (!valid) {
            context.setVariable("raiseFaultRuleSchemaValidation", "true");
            context.setVariable("raiseFaultRuleSchemaValidationMessage", tv4.error);
            context.setVariable("errorJSON", "a42_incoming_request_payload_not_valid");
            throw err;
		}
        /* eslint-enable */
	}
};
