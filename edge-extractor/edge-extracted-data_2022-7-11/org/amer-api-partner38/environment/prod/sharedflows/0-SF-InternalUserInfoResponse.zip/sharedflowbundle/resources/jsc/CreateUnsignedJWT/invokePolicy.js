try {
	createUnsignedJWT();
} catch (err) {
	throw err;
}