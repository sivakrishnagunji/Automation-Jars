createCachingJSON = function createCachingJSON() {
    try {
         var signedJWT = context.getVariable("signedJWT.content");
         var unsignedJWT = context.getVariable("unsignedJWT");
         
         var cachingJSON = {} ;
         cachingJSON.signedJWTFromWSO2 = signedJWT;
         cachingJSON.unsignedJWTFromAPIProfile = unsignedJWT;
         
         context.setVariable("userInfoResponse", JSON.stringify(cachingJSON));
    } catch (err) {
        throw err;
    }
};