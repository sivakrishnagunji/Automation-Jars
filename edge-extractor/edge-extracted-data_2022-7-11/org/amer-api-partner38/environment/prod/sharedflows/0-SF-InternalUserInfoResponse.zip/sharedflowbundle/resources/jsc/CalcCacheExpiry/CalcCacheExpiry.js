calcCacheExpiry = function calcCacheExpiry() {
    try {
		var accesstokenExp = JSON.parse(context.getVariable("jwt.2-DJ-DecodeNBJWT.payload-json"));
		accesstokenExp = accesstokenExp.exp;
		var date = new Date(0);
		date.setUTCSeconds(accesstokenExp);
		var dateInMs = date.getTime();
		var errorJSON = "";

		var currentDate = new Date();
		var currentDateInMs = currentDate.getTime();
		
		context.setVariable("dateInMs",JSON.stringify(dateInMs));
        context.setVariable("currentDateInMs", JSON.stringify(currentDateInMs));
		
		 
		if (dateInMs > currentDateInMs) {
			var ExpiresIn = dateInMs - currentDateInMs;
            ExpiresIn = ExpiresIn + "";
			ExpiresIn = ExpiresIn.substring(0, ExpiresIn.length - 3);
			ExpiresIn = parseInt(ExpiresIn);
			context.setVariable("cacheExpiry", JSON.stringify(ExpiresIn));
		} else {
			errorJSON = "generic_internal_server_error";
			context.setVariable("errorJSON", errorJSON);
			throw "missingJwsException";
		}
		
	} catch (err) {
		throw err;
	}
};