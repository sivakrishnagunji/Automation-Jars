buildCalloutUrl = function buildCalloutUrl() {
    try {
        	var targets = context.getVariable("TargetsServiceCallout");
        	var stubHeader = context.getVariable("request.header.target-stub");
        	var targetJson = JSON.parse(targets);
        	
        	context.setVariable("JWKSPath", targetJson["JWKSResponseURL"]["Path"]);
        	context.setVariable("UserInfoResponsePath", targetJson["UserInfoResponseURL"]["Path"]);
        	context.setVariable("APIProfileResponsePath", targetJson["APIProfileResponseURL"]["Path"]);
        	context.setVariable("TTL", targetJson["JWKSResponseURL"]["TTL"]);
        	context.setVariable("CacheSuffix", targetJson["JWKSResponseURL"]["CacheSuffix"]);
        	
        	if(stubHeader == "true") {
        	    
                context.setVariable("JWKSResponseUrlHost", targetJson["JWKSResponseURL"]["StubURLHost"]);
                context.setVariable("UserInfoResponseUrlHost", targetJson["UserInfoResponseURL"]["StubURLHost"]);
                context.setVariable("APIProfileResponseUrlHost", targetJson["APIProfileResponseURL"]["StubURLHost"]);
                	 
        	} else {
                context.setVariable("JWKSResponseUrlHost", targetJson["JWKSResponseURL"]["URLHost"]);
                context.setVariable("UserInfoResponseUrlHost", targetJson["UserInfoResponseURL"]["URLHost"]);
                context.setVariable("APIProfileResponseUrlHost", targetJson["APIProfileResponseURL"]["URLHost"]);
        
        	}
        } catch (err) {
            throw err;
        }
	
};