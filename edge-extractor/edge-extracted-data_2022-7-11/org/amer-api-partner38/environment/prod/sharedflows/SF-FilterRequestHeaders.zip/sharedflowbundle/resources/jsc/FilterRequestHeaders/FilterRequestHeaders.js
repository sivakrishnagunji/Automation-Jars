filterRequestHeaders = function filterRequestHeaders() {
	var filterReqHeadersConfig = JSON.parse(context.getVariable("private.filterReqHeadersConfig"));
	// context.setVariable("filterReqHeadersConfig", JSON.stringify(filterReqHeadersConfig));

	if (filterReqHeadersConfig) {
		var valid_req_headers = filterReqHeadersConfig.valid_req_headers;
		var headerList = context.getVariable("request.headers.names") + "";
		var validReqHeadersArray, headerListArray, i, headerNameInLowerCase;
		if (headerList !== "[]") {
			valid_req_headers = valid_req_headers.toLowerCase();
			validReqHeadersArray = valid_req_headers.split(",");
			validReqHeadersArray = validReqHeadersArray.map(function (el) {
				return el.trim();
			});

			headerList = headerList.substr(1, headerList.length - 2);
			headerListArray = headerList.split(",");
			for (i=0; i < headerListArray.length; i++) {
				headerNameInLowerCase = headerListArray[i].trim().toLowerCase();
				if (validReqHeadersArray.indexOf(headerNameInLowerCase) === -1) {
					context.removeVariable("request.header." + headerNameInLowerCase);
				}
			}
		}
	}
};