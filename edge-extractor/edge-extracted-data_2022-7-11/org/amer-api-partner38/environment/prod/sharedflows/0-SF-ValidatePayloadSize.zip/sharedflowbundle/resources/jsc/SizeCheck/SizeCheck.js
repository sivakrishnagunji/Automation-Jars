/**
 * This javascript resource checks the size of request URI/Payload/Headers and
 * generate TimestampIn.
 */
executeSizeCheck = function ExecuteSizeCheck() { // eslint-disable-line no-undef
	var maxRequestUriSize = 0;
	var maxContentSize = 0;
	var maxHeaderSize = 0;

	try {

		var maxHeaderSizeStr = context.getVariable("max_header_size");
		var maxContentSizeStr = context.getVariable("max_content_size");
		var maxRequestUriSizeStr = context.getVariable("max_request_uri_size");

		if ((maxHeaderSizeStr !== null) && (maxHeaderSizeStr !== "")) {
			maxHeaderSize = parseInt(maxHeaderSizeStr);
		}
		if ((maxContentSizeStr !== null) && (maxContentSizeStr !== "")) {
			maxContentSize = parseInt(maxContentSizeStr);
		}
		if ((maxRequestUriSizeStr !== null) && (maxRequestUriSizeStr !== "")) {
			maxRequestUriSize = parseInt(maxRequestUriSizeStr);
		}

		var requestUri = context.getVariable("proxy.url");
		var requestUriSize = requestUri.length;
		var clientRequestPayload = context.getVariable("message.content");
		var clientRequestPayloadSize = clientRequestPayload.length;
		var headerSize = 0;

		var headerNamesList = context.getVariable("request.headers.names");
		if (headerNamesList){
			headerNamesList = headerNamesList + "";
			headerNamesList = headerNamesList.substring(1, headerNamesList.length - 1);
			var headerNames = headerNamesList.split(", ");

			for (var i = 0; i < headerNames.length; i++) {
				var headerValue = context.getVariable("request.header." + headerNames[i]);
				headerSize = headerSize + (headerValue.length);
			}
		}
		var customizedErrorMessage;
		// Size check for headers/payload/requestURI
		if (requestUriSize > maxRequestUriSize) {
			customizedErrorMessage = {
				"statusCode": "414",
				"reasonPhrase": "Request URI Too Long",
				"errorCode": "Request URI Too Long",
				"errorDescription": "Request-URI is too long"
			};
			context.setVariable("requestUriSize", requestUriSize);
		} else if (clientRequestPayloadSize > maxContentSize) {
			customizedErrorMessage = {
				"statusCode": "413",
				"reasonPhrase": "Payload Too Large",
				"errorCode": "Payload Too Large",
				"errorDescription": "The request payload exceeds a maximum size"
			};
			context.setVariable("clientRequestPayloadSize",
				clientRequestPayloadSize);
		} else if (headerSize > maxHeaderSize) {
			customizedErrorMessage = {
				"statusCode": "431",
				"reasonPhrase": "Request Header Fields Too Large",
				"errorCode": "Request Header Fields Too Large",
				"errorDescription": "The server is unwilling to process the request because either an individual header field, or all the header fields collectively, are too large" // eslint-disable-line max-len
			};
			context.setVariable("headerSize", headerSize);
		}

		if (customizedErrorMessage) {
			context.setVariable("errorJSON", "customizedErrorMessage");
			context.setVariable("customizedErrorMessage", JSON
				.stringify(customizedErrorMessage));
			throw "sizeCheckException";
		}
	} catch (err) {
		throw "err";
	}
};