var role = context.getVariable("jwt.Verify_JWT_Token.claim.Role");
var httpverb = context.getVariable("request.verb");
var proxypathsuffix = context.getVariable("proxy.pathsuffix");
var usertryresrouce = httpverb + proxypathsuffix;

if (role == "Representative" ) {
    var resource = ["GET/fhir/List", "GET/fhir/MedicationKnowledge"];
   /* var Accessgranted = resources.ingclude ("usertryresrouce");*/
    if (resource.indexOf(usertryresrouce) !== -1) {
        var Access="Granted";
   
    }else{
        Access="Not-Granted";
        context.setVariable("message.status.code", 403);
        throw "error";
    }
    
} else if (role == "BluecrossroleAdmin") {
    var resource = ["GET/fhir/List","GET/fhir/MedicationKnowledge","POST/fhir/MedicationKnowledge/create", "POST/fhir/List/create"];
   if (resource.indexOf(usertryresrouce) !== -1){
         Access="Granted";
    }else{
        Access="Not-Granted";
        context.setVariable("message.status.code", 403);
        throw "error";
    }
    
}else {
    faultDetails="Your role is not exit  or you dont have access on provided resoruce.";
}