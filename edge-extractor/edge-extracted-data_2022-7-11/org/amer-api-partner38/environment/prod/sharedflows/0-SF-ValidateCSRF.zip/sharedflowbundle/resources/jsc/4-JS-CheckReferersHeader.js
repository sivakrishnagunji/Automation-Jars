try {
    var securityHeadersCSRF = context.getVariable("security_request_csrf_list");
    var refererHeader = context.getVariable("request.header.Referer");
    if (refererHeader) {
        if (securityHeadersCSRF) {
            var securityHeadersCSRFArray = securityHeadersCSRF.split(",");
            if (securityHeadersCSRFArray.indexOf(refererHeader) == -1) {
                throw err;
            }
        }
    } else if (securityHeadersCRF) {
        throw err;
    }
} catch (err) {
		var errorJson = (context.getVariable("errorJSON") || "a42_referer_header_not_valid_error");
		context.setVariable("errorJSON", errorJson);
		throw "internalConfigError";
}