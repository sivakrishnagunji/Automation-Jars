checkQueryParams = function CheckQueryParams() { // eslint-disable-line no-undef
	var queryArray = [];
	var customizedErrorMessage;
	try {
		var json = JSON.parse(context.getVariable("queryParamsToValidate"));
		var currentFlowName = context.getVariable("currentFlowName");
		if (json[currentFlowName] !== undefined) {
			queryArray = json[currentFlowName];
			for (var queryParam in queryArray) { // eslint-disable-line guard-for-in
				var queryValue = context.proxyRequest.queryParams[queryArray[queryParam]]+"";
				context.setVariable(queryArray[queryParam], queryValue);
				if (queryValue == null || queryValue == "" || queryValue == "undefined") { // eslint-disable-line eqeqeq,no-eq-null
					customizedErrorMessage = {
						"statusCode": "400",
						"reasonPhrase": "Bad Request",
						"errorCode": "invalid_request",
						"errorDescription": "The request is missing the mandatory parameter "
								+ queryArray[queryParam]
					};
					throw "missingQuery";
				}
			}
		}
	} catch (e) {
		if (!customizedErrorMessage) {
			context.setVariable("errorOccured", "true");
			customizedErrorMessage = {
				"statusCode": "500",
				"reasonPhrase": "Internal Server Error",
				"errorCode": "server_error",
				"errorDescription": "The service is currently not available. Please try again later"
			};
		}
		context.setVariable("errorJSON", "customizedErrorMessage");
		context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
		throw "error";
	}
};
