package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FaultRule {

	private boolean alwaysEnforce;
	private StepOuter[] steps;
	private String description;
	private Object[] faultRules;
	private Object[] flows;
	private String name;
}
