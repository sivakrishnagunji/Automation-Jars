package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Certificate {
	private String basicConstraints;
	private String expiryDate;
	private String isValid;
	private String issuer;
	private String publicKey;
	private String serialNumber;
	private String sigAlgName;
	private String subject;
	private String[] subjectAlternativeNames;
	private String validFrom;
	private int version;

}
