package com.infy.apigee.utils;

public class Constants {
	  public static final String DATE_FORMAT = "EEE  dd MMM yyyy HH:mm:ss z";	  
	  public static final String SSL_CIPHERS = "ssl_ciphers";	  
	  public static final String SSL_PROTOCOLS = "ssl_protocols";
	}
