package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.Developer;
import com.infy.apigee.beans.Developers;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DeveloperReport implements IReport {
 
	public static Logger logger = LoggerFactory.getLogger(DeveloperReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);  
  private FileWriter fw = null;
    private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.S z");  
  public DeveloperReport(String env) throws APIReportException {
    this.format.setTimeZone(TimeZone.getTimeZone("MST"));
  }
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> developers = new ArrayList();
      developers.add(Arrays.asList(new String[] { 
              "Org Name", "User Name", "First Name", "Last Name", "Email", "Developer Id", "Apps", "Status", "CreatedAt", "CreatedAt (Frmted)", 
              "CreatedBy", "LastModifiedAt", "LastModifiedAt (Frmted)", "LastModifiedBy" }));
      for (String org : orgs) {
        DeployedAPIProxies deployedApiProxies = APIConfig.getInstance().getDeployedAPIProxies(org);
        String orgName = deployedApiProxies.getName();
        String attr = (String)props.get("Developers");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        String httpURI = uri.replaceAll("ORG_NAME", orgName);
        String url = hostname + httpURI;
        String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        Developers devs = (Developers)this.mapper.readValue(result, Developers.class);
        for (Developer dev : devs.getDeveloper()) {
          for (String devApp : dev.getApps()) {
            List<String> apiDevsInner = new ArrayList();
            apiDevsInner.add(orgName);
            apiDevsInner.add(dev.getUserName());
            apiDevsInner.add(dev.getFirstName());
            apiDevsInner.add(dev.getLastName());
            apiDevsInner.add(dev.getEmail());
            apiDevsInner.add(dev.getDeveloperId());
            apiDevsInner.add(devApp);
            apiDevsInner.add(dev.getStatus());
            apiDevsInner.add(dev.getCreatedAt() + "");
            this.date.setTime(dev.getCreatedAt());
            apiDevsInner.add(this.format.format(this.date));
            apiDevsInner.add(dev.getCreatedBy());
            apiDevsInner.add(dev.getLastModifiedAt() + "");
            this.date.setTime(dev.getLastModifiedAt());
            apiDevsInner.add(this.format.format(this.date));
            apiDevsInner.add(dev.getLastModifiedBy());
            developers.add(apiDevsInner);
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Developers Report took in ms:{}", (System.currentTimeMillis() - start) );
      System.out.println("Developers Report Completed");
      return developers;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

