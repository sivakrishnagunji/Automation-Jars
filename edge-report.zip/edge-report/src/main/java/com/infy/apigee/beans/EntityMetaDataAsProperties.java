package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EntityMetaDataAsProperties {
	private String bundle_type;
	private String lastModifiedBy;
	private String createdBy;
	private String lastModifiedAt;
	private String subType;
	private String createdAt;
}
