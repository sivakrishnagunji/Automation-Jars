package com.infy.apigee.reports;


import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.ResourceFile;
import com.infy.apigee.beans.Resources;
import com.infy.apigee.beans.Revision;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.BSync;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ResourceReportThreadRunner implements IThreadRunner {
	public static Logger logger = LoggerFactory.getLogger(ResourceReportThreadRunner.class);
  private String[] orgs = null;  
  private String hostname = null;  
  private HTTPConnection httpConn = HTTPConnection.getInstance();  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private String uri;  
  private List<List<String>> apiResources = new ArrayList();  
  private BSync bSync;
  
  public void setContext(String[] orgs, String hostname, String uri, BSync bSync) {
    this.hostname = hostname;
    this.orgs = orgs;
    this.uri = uri;
    this.bSync = bSync;
  }	
  
  public List<List<String>> getResult() {
    return this.apiResources;
  }
  
  public void run() {
    try {
      long start = System.currentTimeMillis();
     /* log.info("[APIPLATRPT] Starting Thread:{} " ,Thread.currentThread().getName());*/
      for (String org : this.orgs) {
        DeployedAPIProxies deployedApiProxies = APIConfig.getInstance().getDeployedAPIProxies(org);
        String orgName = deployedApiProxies.getName();
        for (DeployablesInEnvironment deployedApiProxy : deployedApiProxies.getEnvironment()) {
          String envName = deployedApiProxy.getName();
          DeployedAPIProxy[] apiProxies = deployedApiProxy.getAPIProxy();
          for (DeployedAPIProxy apiProxy : apiProxies) {
            String apiName = apiProxy.getName();
            for (Revision revision : apiProxy.getRevision()) {
              String revName = revision.getName();
              String httpURI = this.uri.replaceAll("ORG_NAME", orgName);
              httpURI = httpURI.replaceAll("API_NAME", apiName);
              httpURI = httpURI.replaceAll("REV_NAME", revName);
              String url = this.hostname + httpURI;
              String result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
              if (result.length() != 0) {
                Resources apiRsrcs = (Resources)this.mapper.readValue(result, Resources.class);
                for (ResourceFile resourceFile : apiRsrcs.getResourceFile()) {
                  List<String> apiResourcesInner = new ArrayList();
                  apiResourcesInner.add(orgName);
                  apiResourcesInner.add(envName);
                  //apiResourcesInner.add(apiName);
                 // apiResourcesInner.add(revName);
                  apiResourcesInner.add(resourceFile.getName());
                  apiResourcesInner.add(resourceFile.getType());
                  this.apiResources.add(apiResourcesInner);
                } 
              } 
            } 
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Completed Thread:{}, total time in ms:{} ", Thread.currentThread().getName(),(System.currentTimeMillis() - start));
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}", (Throwable)jme);
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
      } 
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}", (Throwable)jpe);
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
      } 
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}", ioe.getMessage());
        
      } 
    } catch (APIReportException are) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.[]", (Throwable)are);
        logger.error("[APIPLATRPT] Exception occurred.[]",are.getMessage());
      } 
    } finally {
      this.bSync.waitForAll();
    } 
  }
}

