package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Flow {
	private String condition;
	private String description;
	private String name;
	private Children request;
	private Children response;
}
