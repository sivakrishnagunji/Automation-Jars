package com.infy.apigee.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedSharedFlow;
import com.infy.apigee.beans.DeployedSharedFlows;
import com.infy.apigee.beans.KVMs;
import com.infy.apigee.beans.SharedFlows;

public class APIConfig {
	private Map<String, List<String>> orgEnvs = new HashMap();
	private Map<String, DeployedAPIProxies> deployedAPIProxies = new HashMap();
	private List<List<String>> apiResources = new ArrayList();
	private List<List<Object>> apiProxyURIResources = new ArrayList();
	private List<List<String>> apiDevApps = new ArrayList();
	private List<List<String>> apiRPs = new ArrayList();
	private String userPass;
	private Map<String, DeployedSharedFlows> deployedSharedFlows = new HashMap();
	private Map<String, KVMs> kvms = new HashMap();

	private static class SingletonHolder {
		private static final APIConfig INSTANCE = new APIConfig();
	}

	public static APIConfig getInstance() {
		return SingletonHolder.INSTANCE;
	}

	public DeployedAPIProxies getDeployedAPIProxies(String org) {
		return this.deployedAPIProxies.get(org);
	}
	public KVMs getKVMs(String org) {
		return this.kvms.get(org);
	}
	public void setDeployedSharedFlows(String org, DeployedSharedFlows deployedSharedFlows) {
		this.deployedSharedFlows.put(org, deployedSharedFlows);
	}
	public DeployedSharedFlows getDeployedSharedFlows(String org) {
		return this.deployedSharedFlows.get(org);
	}

	public void setDeployedAPIProxies(String org, DeployedAPIProxies deployedAPIProxies) {
		this.deployedAPIProxies.put(org, deployedAPIProxies);
	}
	public void setKVMs(String org, KVMs kvms) {
		this.kvms.put(org, kvms);
	}

	public Map<String, List<String>> getOrgEnvs() {
		return this.orgEnvs;
	}

	public void putOrgEnvs(String key, List<String> value) {
		this.orgEnvs.put(key, value);
	}

	public String getUserPass() {
		return this.userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public List<List<String>> getApiResources() {
		return this.apiResources;
	}

	public void setApiResources(List<List<String>> apiResources) {
		this.apiResources = apiResources;
	}

	public List<List<String>> getApiDevApps() {
		return this.apiDevApps;
	}

	public void setApiDevApps(List<List<String>> apiDevApps) {
		this.apiDevApps = apiDevApps;
	}

	public List<List<String>> getApiRPs() {
		return this.apiRPs;
	}

	public void setApiRPs(List<List<String>> apiRPs) {
		this.apiRPs = apiRPs;
	}

	public List<List<Object>> getApiProxyURIResources() {
		return this.apiProxyURIResources;
	}

	public void setApiProxyURIResources(List<List<Object>> apiProxyURIResources) {
		this.apiProxyURIResources = apiProxyURIResources;
	}

	private APIConfig() {
	}

	
}
