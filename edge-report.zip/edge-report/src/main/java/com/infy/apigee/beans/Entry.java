package com.infy.apigee.beans;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Entry {

	private ArrayList<?> name;
	private ArrayList<?> value;
	public String toString() {
	    return "KVM [name="+ this.name + ", value=" + this.value + " ]"; 
	    
	}
}
