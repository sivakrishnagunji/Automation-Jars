package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Keystores {
	private String[] certs;
	private String[] keys;
	private String name;
	private KeystoreAlias[] aliases;
}
