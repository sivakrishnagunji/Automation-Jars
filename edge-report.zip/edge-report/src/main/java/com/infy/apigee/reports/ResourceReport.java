package com.infy.apigee.reports;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;


public class ResourceReport implements IReport {
 
	public static Logger logger = LoggerFactory.getLogger(ResourceReport.class);
  public ResourceReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    long start = System.currentTimeMillis();
    List<List<String>> apiResources = APIConfig.getInstance().getApiResources();
    apiResources.add(0, Arrays.asList(new String[] { "Org Name", "Env Name", "Resource Name", "Resource Type" }));
    logger.info("[APIPLATRPT] API Proxies Resources Report took:{} " ,(System.currentTimeMillis() - start));
    System.out.println("Resource Report Completed");
    return apiResources;
  }
}
