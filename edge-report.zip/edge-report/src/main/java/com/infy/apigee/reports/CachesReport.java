package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.Caches;
import com.infy.apigee.beans.ExpirySettings;
import com.infy.apigee.beans.KVM;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CachesReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(CachesReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public CachesReport(String env) throws APIReportException {}  
  @SuppressWarnings("unchecked")
public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> cachesAll = new ArrayList<List<String>>();
      int j=0;
      cachesAll.add(Arrays.asList(new String[] { 
             "S.No", "Org Name", "Env Name", "Cache Name" , "description" , "diskSizeInMB" , "distributed" ,  "inMemorySizeInKB" , "maxElementsInMemory" , "maxElementsOnDisk" , "overflowToDisk" , "persistent" , "timeoutInSec"  }));
      for (String org : orgs) {
	        String orgName = org;
	        String attr = (String)props.get("Caches");
	        String uri = attr.split(",")[0];
	        Class<?> x = attr.split(",")[1].getClass();
	       String uri1 = uri.replaceAll("ORG_NAME", orgName);
	        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
	        for (String env : envs) {
	        	String uri_2 = uri1.replaceAll("ENV_NAME", env);
	            String url = hostname + uri_2;
	            String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
	          
	          String[] caches = (String[])this.mapper.readValue(result, String[].class);
	          for (String cache : caches) {
	        	 String url2 = url + "/" + cache;
	            result = httpConn.openURL(url2, APIConfig.getInstance().getUserPass());
	            /*System.out.println(result);*/
	            Caches cs = (Caches)this.mapper.readValue(result, Caches.class);
	            
	            List<String> csInner = new ArrayList<String>();
	            j++;
	            csInner.add(""+ j + "");
	            csInner.add(orgName);
	            csInner.add(env);
	            csInner.add(cs.getName()); 
	            csInner.add((cs.getDescription() ==null)?cs.getDescription().toString() : "");
                csInner.add(cs.getDiskSizeInMB().toString());
                csInner.add(cs.getDistributed());
                csInner.add(cs.getInMemorySizeInKB().toString());
                csInner.add(cs.getMaxElementsInMemory().toString());
                csInner.add(cs.getMaxElementsOnDisk().toString());
                csInner.add(cs.getOverflowToDisk().toString());
                csInner.add(cs.getPersistent().toString());
                if(result.contains("timeoutInSec")) {
                csInner.add((cs.getExpirySettings().getTimeoutInSec().getValue() != null ? cs.getExpirySettings().getTimeoutInSec().getValue() : ""));
                }else {
                	csInner.add("");
                }
            cachesAll.add(csInner);
            
          } 
        } 
      } 
      
      logger.info("[APIPLATRPT] Caches Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Caches Report Completed");
      return cachesAll;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Caches Report Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Caches Report ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Caches Report Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Caches Report Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}


