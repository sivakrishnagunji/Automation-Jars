package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.KVMs;
import com.infy.apigee.beans.Revision;
import com.infy.apigee.beans.TargetServer;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.Entry;
import com.infy.apigee.beans.FlowHooks;
import com.infy.apigee.beans.KVM;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FlowHookReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(FlowHookReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public FlowHookReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
	  try {
	      long start = System.currentTimeMillis();
	      System.out.println("FlowHook Report");
	      HTTPConnection httpConn = HTTPConnection.getInstance();
	      List<List<String>> flowhookslist = new ArrayList();
	      flowhookslist.add(Arrays.asList(new String[] { 
	              "Org Name", "Env Name", "FlowHook Name", "ContinueOn Error", "SharedFlow" , "State" }));
	      for (String org : orgs) {
	        String orgName = org;
	        String attr = (String)props.get("FlowHooks");
	        String uri = attr.split(",")[0];
	        uri = uri.replaceAll("ORG_NAME", orgName);
	        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
	        for (String env : envs) {
	        	String uri_2 = uri.replaceAll("ENV_NAME", env);
	            String url = hostname + uri_2;
	            String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
	          
	          String[] flowhooks = (String[])this.mapper.readValue(result, String[].class);
	          for (String flowhook : flowhooks) {
	        	String  url2 = url + "/" + flowhook;
	           String result2 = httpConn.openURL(url2, APIConfig.getInstance().getUserPass());
	            /*System.out.println(result);*/
	            FlowHooks fh = (FlowHooks)this.mapper.readValue(result2, FlowHooks.class);
	            List<String> flowhookInner = new ArrayList<String>();
	            flowhookInner.add(orgName);
	            flowhookInner.add(env);
	            flowhookInner.add(flowhook); 
	            flowhookInner.add(fh.getContinueOnError());
	            flowhookInner.add((fh.getSharedFlow() != null) ? fh.getSharedFlow() : "");
	            flowhookInner.add((fh.getState() != null) ? fh.getState() : "");
	            
	            flowhookslist.add(flowhookInner);
	          } 
	        } 
          }
        
      
      logger.info("[APIPLATRPT] FlowHooks Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("FlowHook Report Completed");
      return flowhookslist;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] FlowHooks Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  FlowHooks ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] FlowHooks Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] FlowHooks Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}


