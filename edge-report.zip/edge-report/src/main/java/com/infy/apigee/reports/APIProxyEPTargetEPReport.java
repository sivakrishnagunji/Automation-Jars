package com.infy.apigee.reports;

import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.infy.apigee.utils.BSync;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class APIProxyEPTargetEPReport implements IReport {
 
  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  public static Logger logger = LoggerFactory.getLogger(APIProxyEPTargetEPReport.class);
  private FileWriter fw = null;
  
  private BSync bSync = new BSync();
  
  private List<String> placeHolderList = new ArrayList();
  
  public APIProxyEPTargetEPReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    long start = System.currentTimeMillis();
    HTTPConnection httpConn = HTTPConnection.getInstance();
    List<List<String>> apiFinalList = new ArrayList();
    apiFinalList.add(Arrays.asList(new String[] { 
            "Org Name", "Env Name", "API Proxy Name", "Rev Name", "Base Path", "Proxy EP name", "VirtualHost", "Target EP Name", "Target URL", "Use Proxy", 
            "Use Proxy Tunnelling", "Keep Alive Timeout", "Conn Timeout", "IO Timeout", "Target Key Alias", "Target KeyStore", "Target TrustStore", "Target Protocols" }));
    int PROXY_EP_NUMBER_OF_FIELDS = 7;
    int PROXY_EP_START_INDEX = 0;
    int TARGET_EP_NUMBER_OF_FIELDS = 11;
    int TARGET_EP_START_INDEX = 4;
    for (int i = 0; i < TARGET_EP_NUMBER_OF_FIELDS; i++)
      this.placeHolderList.add(""); 
    String[] threadRunners = ((String)props.get("ThreadRunners")).split(",");
    this.bSync.setCount(threadRunners.length + 1);
    Map<String, List<List<String>>> resultsMap = new HashMap();
    Map<String, IThreadRunner> trMap = new HashMap();
    for (int j = 0; j < threadRunners.length; j++) {
      IThreadRunner tr = ThreadRunnerFactory.getThreadRunner(threadRunners[j]);
      trMap.put(threadRunners[j], tr);
      String attr_ = (String)props.get(props.get(threadRunners[j] + ".uri"));
      String uri_ = attr_.split(",")[0];
      tr.setContext(orgs, hostname, uri_, this.bSync);
      Thread thread = new Thread(tr);
      thread.setName(threadRunners[j]);
      thread.start();
    } 
    this.bSync.waitForAll();
    Iterator<String> trIt = trMap.keySet().iterator();
    while (trIt.hasNext()) {
      String trName = trIt.next();
      IThreadRunner tr = trMap.get(trName);
      resultsMap.put(trName, tr.getResult());
    } 
    List<List<String>> apiProxyEPs = resultsMap.get("ProxyEndpoints");
    List<List<String>> apiTargets = resultsMap.get("TargetEndpoints");
    List<List<String>> apiResources = resultsMap.get("Resources");
    APIConfig.getInstance().setApiResources(apiResources);
    List<List<String>> apiDevApps = resultsMap.get("DevApps");
    APIConfig.getInstance().setApiDevApps(apiDevApps);
   // List<List<String>> apiRPs = resultsMap.get("Roles");
  //  APIConfig.getInstance().setApiRPs(apiRPs);
    long startCons = System.currentTimeMillis();
    if (apiProxyEPs != null)
      for (List<String> apiProxyEP : apiProxyEPs) {
        String org2 = apiProxyEP.get(0);
        String env2 = apiProxyEP.get(1);
        String api2 = apiProxyEP.get(2);
        String rev2 = apiProxyEP.get(3);
        List<String> apiFinalInnerList = null;
        boolean matchFound = false;
        for (List<String> apiTarget : apiTargets) {
          String org1 = apiTarget.get(0);
          String env1 = apiTarget.get(1);
          String api1 = apiTarget.get(2);
          String rev1 = apiTarget.get(3);
          if (org1.equals(org2) && env1
            .equals(env2) && api1
            .equals(api2) && rev1
            .equals(rev2)) {
            matchFound = true;
      /*      String attr = (String)props.get("ApiEndpoints");
            String uri = attr.split(",")[0];
           String uri1 = uri.replaceAll("ORG_NAME", org1);
            String uri2=uri1.replaceAll("API_NAME", api1);
            String uri3=uri2.replaceAll("REV_NO", rev1);
            String uri4=uri3.replaceAll("ENV_NAME", env1);
            String url = hostname + uri4;
          String  result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());*/
            apiFinalInnerList = new ArrayList();
            int m;
            for (m = PROXY_EP_START_INDEX; m < PROXY_EP_NUMBER_OF_FIELDS; m++)
              apiFinalInnerList.add(apiProxyEP.get(m)); 
            for (m = TARGET_EP_START_INDEX; m < TARGET_EP_START_INDEX + TARGET_EP_NUMBER_OF_FIELDS; m++)
              apiFinalInnerList.add(apiTarget.get(m)); 
            apiFinalList.add(apiFinalInnerList);
          } 
        } 
        if (!matchFound) {
          apiFinalInnerList = new ArrayList();
          for (int m = PROXY_EP_START_INDEX; m < PROXY_EP_NUMBER_OF_FIELDS; m++)
            apiFinalInnerList.add(apiProxyEP.get(m)); 
          apiFinalInnerList.addAll(this.placeHolderList);
          apiFinalList.add(apiFinalInnerList);
        } 
      }  
    logger.info("[APIPLATRPT] API Proxies Proxies and Targets consolidation took in ms:{} ",(System.currentTimeMillis() - startCons));
    logger.info("[APIPLATRPT] API Proxies Target Report took in ms:{} ",(System.currentTimeMillis() - start));
    System.out.println("API Proxies Target Report Completed");
    return apiFinalList;
  }
}
