package com.infy.apigee.reports;



import lombok.extern.slf4j.Slf4j;
import org.slf4j.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.infy.apigee.beans.AccessToken;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;


public class AlertsReport implements IReport {
  
  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  public static Logger logger = LoggerFactory.getLogger(AlertsReport.class);
  public AlertsReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
	  try {
	      long start = System.currentTimeMillis();
	      
	      HttpURLConnection connection1 = null;
	      HttpURLConnection connection2 = null;
	      int j=0;
	      String accesstoken="";
	      List<List<String>> allCollections = new ArrayList();
	      allCollections.add(Arrays.asList(new String[] { 
	              "S.No" , "Org Name", "Environment", "UUID", "Alert Name" , "enabled" , "Discription" , "Conditions" , "Playbook" , "ThrottleIntervalSeconds" , "Self" , "Feed" , "ReportEnabled" , "ReportUUID" , "Notifications" , "AlertType" , "alertSubType" , "UpdatedAt" , "UpdatedBy" }));
	     
	        String attr = (String)props.get("Oauth2");
	       
	        String tokenresult="";
	        System.setProperty("https.protocols", "TLSv1.2");
	        URL httpurl = new URL(attr);
	        
	        connection1 = (HttpURLConnection) httpurl.openConnection();
	        connection1.setRequestMethod("POST");
	        connection1.setRequestProperty("Authorization", "Basic ZWRnZWNsaTplZGdlY2xpc2VjcmV0" ); 
	         
	         BufferedReader in = new BufferedReader(new InputStreamReader(connection1.getInputStream(), "UTF-8"));
		      String str = "";
		      
		      while ((str = in.readLine()) != null) {
		       String Oauthresult = tokenresult + str; 
		       AccessToken at = (AccessToken)this.mapper.readValue(Oauthresult, AccessToken.class);
		      accesstoken =at.getAccess_token();
		      }
		      String attr2=(String)props.get("Alerts");
		      String url=attr2;
		      URL httpurl2 = new URL(url);
		      connection2=(HttpURLConnection)httpurl2.openConnection();
		      connection2.setRequestProperty("Authorization", "Bearer " + accesstoken);
		     		      
		      BufferedReader results = new BufferedReader(new InputStreamReader(connection2.getInputStream(), "UTF-8"),8*1024);
		      
		      String str2;
		     
		      while((str2 = results.readLine()) != null){
		    	  String key=str2;
//		    	  JSONObject collection=new JSONObject(key);
		    	  JSONArray collection = new JSONArray(key);
		    	  for(int i = 0;i<collection.length();i++) {
		    		  JSONObject json = collection.getJSONObject(i);
		    		  //CollectionsResult result = new CollectionsResult();
		    		  List<String> csInner = new ArrayList<String>();
		    		    j++;
		    		    csInner.add(""+ j + "");
				    	csInner.add(json.get("organization").toString());
			            csInner.add(json.get("environment").toString());
			            csInner.add(json.get("uuid").toString());
			            csInner.add(json.get("name").toString());
			            csInner.add(json.get("enabled").toString()); 
			            csInner.add((String) ((json.get("description").toString() != null) ? json.get(("description").toString()): ""));
			            csInner.add(json.get("conditions").toString());
			            csInner.add(json.get("playbook").toString()); 
			            csInner.add(json.get("throttleIntervalSeconds").toString());
			            csInner.add(json.get("self").toString());
			            csInner.add(json.get("feed").toString());
			            csInner.add(json.get("reportEnabled").toString()); 
			            csInner.add(json.get("reportUUID").toString());
			            csInner.add(json.get("notifications").toString());
			            csInner.add(json.get("alertType").toString());
			            csInner.add(json.get("alertSubType").toString()); 
			            csInner.add(json.get("updatedAt").toString());
			            csInner.add(json.get("updatedBy").toString());
			       
			            allCollections.add(csInner);
		    	  }
		    	  		    	 
			    	
		          }  
		    
	     
      logger.info("[APIPLATRPT] Alerts Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Alerts Report Completed");
      return allCollections;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Alerts Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Alerts ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Alerts Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Alerts Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}



