package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiSpecifications {

	private String id;
	private String kind;
	private String name;
	private String created;
	private String creator;
	private String modified;
	private String isTrashed;
	private String permissions;
	private String self;
	private String content;
	private String contents;
	private String folder;
	private String folderId;
	private String body;

}
