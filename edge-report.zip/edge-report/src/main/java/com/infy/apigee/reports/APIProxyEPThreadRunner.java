package com.infy.apigee.reports;

import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.ProxyEP;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.BSync;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

	
public class APIProxyEPThreadRunner implements IThreadRunner {
  
	public static Logger logger = LoggerFactory.getLogger(APIProxyEPThreadRunner.class);
  private String[] orgs = null;  
  private String hostname = null;  
  private HTTPConnection httpConn = HTTPConnection.getInstance();  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private String uri;  
  private List<List<String>> apiProxyEPs = new ArrayList();  
  private List<List<Object>> apiProxyEPURIResources = new ArrayList();  
  private BSync bSync;
  
  public void setContext(String[] orgs, String hostname, String uri, BSync bSync) {
    this.hostname = hostname;
    this.orgs = orgs;
    this.uri = uri;
    this.bSync = bSync;
  }
  
  public List<List<String>> getResult() {
    return this.apiProxyEPs;
  }
  
  public void run() {
    try {
      long start = System.currentTimeMillis();
     /* log.info("[APIPLATRPT] Starting Thread:{} ",Thread.currentThread().getName());*/
      for (String org : this.orgs) {
        DeployedAPIProxies deployedApiProxies = APIConfig.getInstance().getDeployedAPIProxies(org);
        String orgName = deployedApiProxies.getName();
        for (DeployablesInEnvironment deployablesInEnvironment : deployedApiProxies.getEnvironment()) {
          String envName = deployablesInEnvironment.getName();
          DeployedAPIProxy[] apiProxies = deployablesInEnvironment.getAPIProxy();
          for (DeployedAPIProxy deployedAPIProxy : apiProxies) {
            String apiName = deployedAPIProxy.getName();
            for (ApiProxiesRevision apiRevs : deployedAPIProxy.getApiRev()) {
              String revName = apiRevs.getRevision();
              String httpURI = this.uri.replaceAll("ORG_NAME", orgName);
              httpURI = httpURI.replaceAll("API_NAME", apiName);
              httpURI = httpURI.replaceAll("REV_NAME", revName);
              String url = this.hostname + httpURI;
              if (apiRevs.getProxyEndpoints() != null)
                for (String proxyEndpoint : apiRevs.getProxyEndpoints()) {
                  url = this.hostname + httpURI + "/proxies/" + proxyEndpoint.replaceAll(" ", "%20");
                  String result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
                  ProxyEP proxyEP = (ProxyEP)this.mapper.readValue(result, ProxyEP.class);
                  List<Object> apiProxyEPsURIsInner = new ArrayList();
                  apiProxyEPsURIsInner.add(orgName);
                  apiProxyEPsURIsInner.add(envName);
                  apiProxyEPsURIsInner.add(apiName);
                  apiProxyEPsURIsInner.add(revName);
                  apiProxyEPsURIsInner.add(proxyEP.getFlows());
                  this.apiProxyEPURIResources.add(apiProxyEPsURIsInner);
                  for (String vHost : proxyEP.getConnection().getVirtualHost()) {
                    List<String> apiProxyEPsInner = new ArrayList();
                    apiProxyEPsInner.add(orgName);
                    apiProxyEPsInner.add(envName);
                    apiProxyEPsInner.add(apiName);
                    apiProxyEPsInner.add(revName);
                    apiProxyEPsInner.add((proxyEP.getConnection().getBasePath() != null) ? ((proxyEP.getConnection().getBasePath() != null) ? proxyEP.getConnection().getBasePath() : "") : "");
                    apiProxyEPsInner.add((proxyEP.getName() != null) ? proxyEP.getName() : "");
                    apiProxyEPsInner.add(vHost);
                    this.apiProxyEPs.add(apiProxyEPsInner);
                  } 
                }  
            } 
          } 
        } 
      } 
      APIConfig.getInstance().setApiProxyURIResources(this.apiProxyEPURIResources);
      logger.info("[APIPLATRPT] Completed Thread{} in ms:{} " ,Thread.currentThread().getName(),(System.currentTimeMillis() - start));
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ", (Throwable)jme);
        logger.error("[APIPLATRPT] JsonMappingException occurred.Exception:{}",jme.getMessage());
      } 
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ", (Throwable)jpe);
        logger.error("[APIPLATRPT] JsonParseException occurred.Exception:{}",jpe.getMessage());
      } 
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.Exception:{} ", ioe.getMessage());
        
      } 
    } catch (APIReportException are) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ", (Throwable)are);
        logger.error("[APIPLATRPT] APIReportException occurred.{} ",are.getMessage());
      } 
    } finally {
      this.bSync.waitForAll();
    } 
  }
}

