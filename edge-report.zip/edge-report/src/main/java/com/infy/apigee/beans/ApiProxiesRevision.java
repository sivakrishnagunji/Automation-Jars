package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiProxiesRevision {

	private ConfigurationVersion configurationVersion;
	private String contextInfo;
	private long createdAt;
	private String createdBy;
	private String description;
	private String displayName;
	private long lastModifiedAt;
	private String lastModifiedBy;
	private String manifestVersion;
	private String name;
	private String[] policies;
	private String[] proxyEndpoints;
	private Object resourceFiles;
	private String[] resources;
	private String revision;
	private String[] targetEndpoints;
	private String[] targetServers;
	private String[] basepaths;
	private String[] proxies;
	private String[] targets;
	private Object connection;
	private String connectionType;
	private FaultRule defaultFaultRule;
	private String spec;
	private FaultRule[] faultRules;
	private Flow[] flows;
	private Flow postClientFlow;
	private Flow postFlow;
	private Flow preFlow;
	private String[] sharedFlows;
	private String subType;
	private RouteRule[] routeRule;
	private String[] routeRuleNames;
	private String type;
	private EntityMetaDataAsProperties entityMetaDataAsProperties;

}
