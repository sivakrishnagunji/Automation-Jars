package com.infy.apigee.reports;

import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.Revision;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DeployedAPIReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(DeployedAPIReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private FileWriter fw = null;  
  private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.S z");  
  public DeployedAPIReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> apis = new ArrayList();
      apis.add(Arrays.asList(new String[] { 
              "Org Name", "Env Name", "API Proxy Name", "Deployed Revision", "Deployment Status", "CreatedAt", "CreatedAt (Frmted)", "CreatedBy", "LastModifiedAt", "LastModifiedAt (Frmted)", 
              "LastModifiedBy" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("DeployedAPIs");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        uri = uri.replaceAll("ORG_NAME", orgName);
        String url = hostname + uri;
        String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        DeployedAPIProxies deployedApiProxies = (DeployedAPIProxies)this.mapper.readValue(result, DeployedAPIProxies.class);
        APIConfig.getInstance().setDeployedAPIProxies(orgName, deployedApiProxies);
        for (DeployablesInEnvironment deployedApiProxy : deployedApiProxies.getEnvironment()) {
          String envName = deployedApiProxy.getName();
          DeployedAPIProxy[] apiProxies = deployedApiProxy.getAPIProxy();
          for (DeployedAPIProxy apiProxy : apiProxies) {
            String apiName = apiProxy.getName();
            for (Revision revision : apiProxy.getRevision()) {
              String attrR = (String)props.get("APIProxiesRevision");
              String uriR = attrR.split(",")[0];
              String revName = revision.getName();
              String httpURI = uriR.replaceAll("ORG_NAME", orgName);
              httpURI = httpURI.replaceAll("API_NAME", apiName);
              httpURI = httpURI.replaceAll("REV_NAME", revName);
              String urlR = hostname + httpURI;
              String resultRev = httpConn.openURL(urlR, APIConfig.getInstance().getUserPass());
              if (resultRev.length() != 0) {
                ApiProxiesRevision apiRev = (ApiProxiesRevision)this.mapper.readValue(resultRev, ApiProxiesRevision.class);
                apiProxy.getApiRev().add(apiRev);
                List<String> apiInner = new ArrayList();
                apiInner.add(orgName);
                apiInner.add(envName);
                apiInner.add(apiName);
                apiInner.add(revision.getName());
                apiInner.add(revision.getState());
                apiInner.add(apiRev.getCreatedAt() + "");
                this.date.setTime(apiRev.getCreatedAt());
                apiInner.add(this.format.format(this.date));
                apiInner.add((apiRev.getCreatedBy() != null) ? apiRev.getCreatedBy() : "");
                apiInner.add(apiRev.getLastModifiedAt() + "");
                this.date.setTime(apiRev.getLastModifiedAt());
                apiInner.add(this.format.format(this.date));
                apiInner.add(apiRev.getLastModifiedBy());
                apis.add(apiInner);
              } 
            } 
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Deployed Proxies Report took in ms: " ,(System.currentTimeMillis() - start));
      System.out.println("Deployed API Proxies Report Completed");
      return apis;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

