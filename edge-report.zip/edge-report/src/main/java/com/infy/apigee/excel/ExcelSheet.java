package com.infy.apigee.excel;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelSheet {
	private Workbook wb = null;
	private String filePath = null;
	private CellStyle redCellStyle = null;
	private CellStyle aquaCellStyle = null;
	private CellStyle yellowCellStyle = null;
	private CellStyle redBoldCellStyle = null;
	private CellStyle aquaBoldCellStyle = null;
	private CellStyle yellowBoldCellStyle = null;

	public void createWorkbook(String filePath) {
		this.wb = (Workbook) new XSSFWorkbook();
		createCellStyles();
		this.filePath = filePath;
	}

	private void createCellStyles() {
		this.redCellStyle = this.wb.createCellStyle();
		this.redCellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
		this.redCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		this.aquaCellStyle = this.wb.createCellStyle();
		this.aquaCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		this.aquaCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		this.yellowCellStyle = this.wb.createCellStyle();
		this.yellowCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		this.yellowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		Font font = this.wb.createFont();
		font.setBold(true);
		this.redBoldCellStyle = this.wb.createCellStyle();
		this.redBoldCellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
		this.redBoldCellStyle.setFont(font);
		this.redBoldCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		this.aquaBoldCellStyle = this.wb.createCellStyle();
		this.aquaBoldCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		this.aquaBoldCellStyle.setFont(font);
		this.aquaBoldCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		this.yellowBoldCellStyle = this.wb.createCellStyle();
		this.yellowBoldCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		this.yellowBoldCellStyle.setFont(font);
		this.yellowBoldCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	}

	public Workbook openWorkbook(String filePath) {
		try {
			FileInputStream fis = new FileInputStream(filePath);
			this.wb = (Workbook) new XSSFWorkbook(fis);
			createCellStyles();
			this.filePath = filePath;
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return this.wb;
	}

	public void createSheet(String sheetName, List<Map<String, String>> list) {
		Sheet sheet = getSheet(sheetName);
		Iterator<Map<String, String>> listIt = list.iterator();
		boolean builtHeader = false;
		int i = 1;
		Row header = null;
		while (listIt.hasNext()) {
			if (!builtHeader)
				header = sheet.createRow(i++);
			Row values = sheet.getRow(i);
			if (values == null) {
				values = sheet.createRow(i);
			} else {
				while (values != null) {
					i++;
					values = sheet.getRow(i);
				}
				values = sheet.createRow(i);
			}
			Map<String, String> innerMap = listIt.next();
			Iterator<String> innerMapIt = innerMap.keySet().iterator();
			int j = 2;
			while (innerMapIt.hasNext()) {
				String attrName = innerMapIt.next();
				if (!builtHeader) {
					Cell cell = header.createCell(j);
					cell.setCellValue(attrName);
				}
				String value = innerMap.get(attrName);
				Cell valueCell = values.createCell(j);
				valueCell.setCellValue(value);
				sheet.autoSizeColumn(j);
				j++;
			}
			if (!builtHeader)
				builtHeader = true;
			i++;
		}
	}

	public void exitSheet() {
		try {
			FileOutputStream fileOut = new FileOutputStream(this.filePath);
			this.wb.write(fileOut);
			fileOut.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public Sheet getSheet(String sheetName) {
		Sheet sheet = this.wb.getSheet(sheetName);
		if (sheet == null)
			return this.wb.createSheet(sheetName);
		return sheet;
	}

	public void setWorkbook(Workbook wb, String filePath) {
		this.filePath = filePath;
		this.wb = wb;
	}

	public List<List<String>> getSheetData(String fileName) throws IOException {
		List<List<String>> outerList = new ArrayList();
		FileInputStream fiLat = new FileInputStream(fileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(fiLat));
		String line = "";
		List<String> innerList = null;
		while ((line = br.readLine()) != null) {
			innerList = Arrays.asList(line.split(","));
			outerList.add(innerList);
		}
		br.close();
		fiLat.close();
		return outerList;
	}

	public Sheet populateSheet(String sheetName, List<List<String>> list, int rowOffset, int colOffset)
			throws Exception {
		Sheet sheet = getSheet(sheetName);
		return populateSheet(sheet, list, rowOffset, colOffset);
	}

	public Sheet populateSheet(Sheet sheet, List<List<String>> list, int rowOffset, int colOffset) throws Exception {
		CellStyle headerCellStyle = this.wb.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		Font font = this.wb.createFont();
		font.setBold(true);
		headerCellStyle.setFont(font);
	//	CellStyle rowCellStyle = this.wb.createCellStyle();
	//	rowCellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
	//	rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		for (int i = 0; i < list.size(); i++) {
			Row row = getRow(sheet, i + rowOffset);
			for (int j = 0; j < ((List<String>) list.get(i)).size(); j++) {
				Cell cell = null;
				try {
					cell = getCell(row, j + colOffset);
					if (j == 0) {
						cell.setCellValue(((String) ((List<String>) list.get(i)).get(j)).toString());
					} else {
						try {
							cell.setCellType(CellType.NUMERIC);
							cell.setCellValue(Double.parseDouble(((List<String>) list.get(i)).get(j)));
						} catch (NumberFormatException nfe) {
							cell.setCellValue(((String) ((List<String>) list.get(i)).get(j)).toString());
						} catch (NullPointerException npe) {
							log.error("ERRORxxxx, SheetName:{},Other Data:{}, i value :{}, j value:{}" , sheet.getSheetName(),
									(String) ((List<String>) list.get(i)).get(j), i,j );
							log.error("ERRORzzzz, list of i:{}" ,list.get(i));
							throw npe;
						}
					}
					if (i == 0) {
						cell.setCellStyle(headerCellStyle);
					} else {
						//cell.setCellStyle(rowCellStyle);
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
				if (i == list.size() - 1)
					sheet.autoSizeColumn(j + colOffset);
			}
		}
		return sheet;
	}

	private Row getRow(Sheet sheet, int i) {
		Row row = sheet.getRow(i);
		if (row == null)
			row = sheet.createRow(i);
		return row;
	}

	private Cell getCell(Row row, int i) {
		Cell cell = row.getCell(i);
		if (cell == null)
			cell = row.createCell(i);
		return cell;
	}

	public void setCellStyle(Cell cell, String color, boolean boldfont) {
		if (color.equals("red")) {
			cell.setCellStyle(this.redCellStyle);
			if (boldfont)
				cell.setCellStyle(this.redBoldCellStyle);
		} else if (color.equals("")) {
			cell.setCellStyle(this.aquaCellStyle);
			if (boldfont)
				cell.setCellStyle(this.aquaBoldCellStyle);
		} else if (color.equals("Light Gray")) {
			cell.setCellStyle(this.yellowCellStyle);
			if (boldfont)
				cell.setCellStyle(this.yellowBoldCellStyle);
		}
	}

	public void removeSheet(String sheetName) {
		for (int i = this.wb.getNumberOfSheets() - 1; i >= 0; i--) {
			Sheet tmpSheet = this.wb.getSheetAt(i);
			if (tmpSheet.getSheetName().equals(sheetName))
				this.wb.removeSheetAt(i);
		}
	}
}
