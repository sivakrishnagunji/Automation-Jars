package com.infy.apigee.beans;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomReports {
	
	private String name;
	private String chartType;
	private String comments;
	private String createdAt;
	private String createdBy;
	private String dimensions;
	private String displayName;
	private String environment;
	private String lastModifiedAt;
	private String lastModifiedBy;
	private String lastViewedAt;
	private String metrics;
	private String organization;
	private String properties;
	private String sortbyCols;
	private String tags;
	private String timeUnit;
	}
