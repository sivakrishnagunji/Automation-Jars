package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Product {
	private String[] apiResources;
	private String approvalType;
	private NameValue[] attributes;
	private long createdAt;
	private String createdBy;
	private String description;
	private String displayName;
	private String[] environments;
	private long lastModifiedAt;
	private String lastModifiedBy;
	private String name;
	private String[] proxies;
	private String quota;
	private String quotaInterval;
	private String quotaTimeUnit;
	private String[] scopes;
}
