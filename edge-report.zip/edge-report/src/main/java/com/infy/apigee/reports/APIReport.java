package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class APIReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(APIReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private FileWriter fw = null;
  
  public APIReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> envs = new ArrayList();
      envs.add(Arrays.asList(new String[] { "Org Name", "API Proxy Name" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("APIs");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        uri = uri.replaceAll("ORG_NAME", orgName);
        String url = hostname + uri;
        String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        String[] apis = (String[])this.mapper.readValue(result, String[].class);
        for (String api : apis) {
          List<String> envsInner = new ArrayList();
          envsInner.add(orgName);
          envsInner.add(api);
          envs.add(envsInner);
        } 
      } 
      logger.info("[APIPLATRPT] APIs Report took in ms:{} " , (System.currentTimeMillis() - start));
      System.out.println("APIs Report Completed");
      return envs;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{} ",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

