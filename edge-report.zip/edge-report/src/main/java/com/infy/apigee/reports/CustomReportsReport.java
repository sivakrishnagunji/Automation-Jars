package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;


import com.infy.apigee.beans.CustomReports;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CustomReportsReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(CustomReportsReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public CustomReportsReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> customAll = new ArrayList<List<String>>();
      customAll.add(Arrays.asList(new String[] { 
              "Org Name", "Custrom Report Name" , "Display Name" , "chartType" , "comments" ,  "createdAt" , "createdBy" , "dimensions" , "environment" , "Filter" , "lastModifiedAt" , "lastModifiedBy" , "lastViewedAt" , "metrics" , "properties" , "sortbyCols" , "tags" , "TimeUnit" }));
      for (String org : orgs) {
	        String orgName = org;
	        String attr = (String)props.get("CustomReports");
	        String uri = attr.split(",")[0];
	        Class<?> x = attr.split(",")[1].getClass();
	        uri = uri.replaceAll("ORG_NAME", orgName);
	        
	        	 String url = hostname + uri;
	            String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());	          
	          
	          JSONObject json = new JSONObject(result);
		    	
    		  String contents=json.get("qualifier").toString();
    		   JSONArray collection = new JSONArray(contents);
    		   for(int i = 0;i<collection.length();i++) {
		    		  JSONObject report = collection.getJSONObject(i);
		    		  String reportname=report.get("name").toString();
		    		  String reportdisplayname=report.get("displayName").toString();    	
	          
	        	 String url2 = url + "/" + reportname;
	          String results = httpConn.openURL(url2, APIConfig.getInstance().getUserPass());
	          CustomReports output = (CustomReports)this.mapper.readValue(result, CustomReports.class);
	            /*System.out.println(result);*/
	            
	          JSONObject data = new JSONObject(results);
	          
	            List<String> crInner = new ArrayList<String>();
	            crInner.add(orgName);
	            crInner.add(reportname);
	            crInner.add(reportdisplayname);
	            crInner.add(data.get("chartType").toString());
                crInner.add(data.get("comments").toString());
                crInner.add(data.get("createdAt").toString());
                if(results.contains("createdBy"))
                {
                   crInner.add(data.get("createdBy").toString() != null ? data.get("createdBy").toString() : "");
                }else {
                   crInner.add(" ");
                }
                crInner.add(data.get("dimensions").toString());
                crInner.add(data.get("environment").toString());
                if(results.contains("filter"))
                {
                   crInner.add(data.get("filter").toString() != null ? data.get("filter").toString() : "");
                }else {
                   crInner.add(" ");
                }
                
                crInner.add(data.get("lastModifiedAt").toString());
                crInner.add(data.get("lastModifiedBy").toString());
                crInner.add(data.get("lastViewedAt").toString());
                crInner.add(data.get("metrics").toString());
                crInner.add(data.get("properties").toString());
                crInner.add(data.get("sortbyCols").toString());
                if(results.contains("timeUnit"))
                {
                	crInner.add(data.get("timeUnit").toString() !=null ? data.get("timeUnit").toString() : "");
                }else {
                   crInner.add(" ");
                }
                
                
            customAll.add(crInner);
            
          } 
	        }
      
      
      
      logger.info("[APIPLATRPT] Custom Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Custom Report Completed");
      return customAll;
    } catch (JsonMappingException jme) {
        if (logger.isErrorEnabled()) {
          logger.error("[APIPLATRPT] ApiSpecifications Report JsonMappingException occurred.{}",jme.getMessage());
          
        } 
        throw new APIReportException(jme);
      } catch (JsonParseException jpe) {
        if (logger.isErrorEnabled()) {
          logger.error("[APIPLATRPT]  ApiSpecifications ReportJsonParseException occurred.{}",jpe.getMessage());
          
        } 
        throw new APIReportException(jpe);
      } catch (IOException ioe) {
        if (logger.isErrorEnabled()) {
          logger.error("[APIPLATRPT] ApiSpecifications Report IOException occurred.{}",ioe.getMessage());
          
        } 
        throw new APIReportException(ioe);
      } catch (Exception e) {
        if (logger.isErrorEnabled()) {
          logger.error("[APIPLATRPT] ApiSpecifications Report Exception occurred.{}",e.getMessage());
          
        } 
        throw new APIReportException(e);
      } finally {}
    }
  }


