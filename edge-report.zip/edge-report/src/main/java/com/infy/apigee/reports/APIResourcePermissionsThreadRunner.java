package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ResourcePermission;
import com.infy.apigee.beans.ResourcePermissions;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.BSync;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class APIResourcePermissionsThreadRunner implements IThreadRunner {
  
	public static Logger logger = LoggerFactory.getLogger(APIResourcePermissionsThreadRunner.class);
  private String[] orgs = null;  
  private String hostname = null;  
  private HTTPConnection httpConn = HTTPConnection.getInstance();  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private String uri;  
  private List<List<String>> apiRPs = new ArrayList();  
  private BSync bSync;
  
  public void setContext(String[] orgs, String hostname, String uri, BSync bSync) {
    this.hostname = hostname;
    this.orgs = orgs;
    this.uri = uri;
    this.bSync = bSync;
  }
  
  public List<List<String>> getResult() {
    return this.apiRPs;
  }
  
  public void run() {
    try {
      long start = System.currentTimeMillis();
      /*log.info("[APIPLATRPT] Starting Thread:{} ",Thread.currentThread().getName());*/
      for (String org : this.orgs) {
        String orgName = org;
        String httpURI = this.uri.replaceAll("ORG_NAME", orgName);
        String url = this.hostname + httpURI;
        String result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        String[] roles = (String[])this.mapper.readValue(result, String[].class);
        for (String role : roles) {
        	List<String> apiRPInner = new ArrayList<String>();
        	apiRPInner.add(orgName);
            apiRPInner.add(role);
            this.apiRPs.add(apiRPInner);
          /*
          url = this.hostname + httpURI + "/" + role.replaceAll(" ", "%20") + "/permissions";
          result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          ResourcePermissions rps = (ResourcePermissions)this.mapper.readValue(result, ResourcePermissions.class);
          if ((rps.getResourcePermission()).length > 0) {
            boolean matchFound = false;
            for (int n = 0; n < (rps.getResourcePermission()).length; n++) {
              ResourcePermission rp = rps.getResourcePermission()[n];
              String path = rp.getPath();
              if (path.contains("/applications/") && !path.contains("/applications/*")) {
                String path_1 = "";
                if (path.length() > "/applications/".length()) {
                  path_1 = path.substring(path.lastIndexOf("/applications/") + 14);
                  if (path_1.indexOf("/") == -1) {
                    matchFound = true;
                    List<String> apiRPInner = new ArrayList();
                    apiRPInner.add(orgName);
                    apiRPInner.add(role);
                    apiRPInner.add(path_1);
                    apiRPInner.add(Arrays.<String>asList(rp.getPermissions()).toString());
                    this.apiRPs.add(apiRPInner);
                  } 
                } 
              } 
            } 
            if (!matchFound) {
              List<String> apiRPInner = new ArrayList();
              apiRPInner.add(orgName);
              apiRPInner.add(role);
              apiRPInner.add("");
              apiRPInner.add("");
              this.apiRPs.add(apiRPInner);
            } 
          } else {
            List<String> apiRPInner = new ArrayList();
            apiRPInner.add(orgName);
            apiRPInner.add(role);
            apiRPInner.add("");
            apiRPInner.add("");
            this.apiRPs.add(apiRPInner);
          } */
        } 
      } 
      logger.info("[APIPLATRPT] Completed Thread:{}, total time is ms:{} ", Thread.currentThread().getName(), (System.currentTimeMillis() - start));
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred. {}", (Throwable)jme);
        logger.error("[APIPLATRPT] JsonMappingException occurred. {}",jme.getMessage());
      } 
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ", (Throwable)jpe);
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ",jpe.getMessage());
      } 
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{} ", ioe.getMessage());
        
      } 
    } catch (APIReportException are) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ", (Throwable)are);
        logger.error("[APIPLATRPT] APIReportException occurred.{} ", are.getMessage());
      } 
    } finally {
      this.bSync.waitForAll();
    } 
  }
}

