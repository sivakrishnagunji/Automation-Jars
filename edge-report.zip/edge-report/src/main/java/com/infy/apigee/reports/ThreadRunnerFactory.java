package com.infy.apigee.reports;

import com.infy.apigee.exceptions.APIReportException;

public class ThreadRunnerFactory {
  public static IThreadRunner getThreadRunner(String threadRunnerName) throws APIReportException {
    IThreadRunner threadRunner = null;
    if (threadRunnerName.equals("TargetEndpoints")) {
      threadRunner = new APITargetEPThreadRunner();
    } else if (threadRunnerName.equals("ProxyEndpoints")) {
      threadRunner = new APIProxyEPThreadRunner();
    } else if (threadRunnerName.equals("Resources")) {
      threadRunner = new APIResourcesThreadRunner();
    } else if (threadRunnerName.equals("DevApps")) {
      threadRunner = new APIDevAppsThreadRunner();
    } //else if (threadRunnerName.equals("Roles")) {
      //threadRunner = new APIResourcePermissionsThreadRunner();
    //}
  else {
      throw new APIReportException("Invalid thread runner .... ");
    } 
    return threadRunner;
  }
}
