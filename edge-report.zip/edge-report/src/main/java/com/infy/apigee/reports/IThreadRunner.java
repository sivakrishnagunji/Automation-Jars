package com.infy.apigee.reports;

import java.util.List;

import com.infy.apigee.utils.BSync;

public interface IThreadRunner extends Runnable {
  void setContext(String[] paramArrayOfString, String paramString1, String paramString2, BSync paramBSync);
  
  List<List<String>> getResult();
}