package com.infy.apigee.reports;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ApiProduct;
import com.infy.apigee.beans.ApiProducts;
import com.infy.apigee.beans.App;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.BSync;


public class APIDevAppsThreadRunner implements IThreadRunner {
  
  
  private String[] orgs = null;  
  private String hostname = null;  
  private HTTPConnection httpConn = HTTPConnection.getInstance();
  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  public static Logger logger = LoggerFactory.getLogger(APIDevAppsThreadRunner.class);
  private String uri;  
  private List<List<String>> apiDevApps = new ArrayList();  
  private BSync bSync;  
  private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.S z");
  
  public APIDevAppsThreadRunner() {
    this.format.setTimeZone(TimeZone.getTimeZone("MST"));
  }
  
  @Override
  public void setContext(String[] orgs, String hostname, String uri, BSync bSync) {
    this.hostname = hostname;
    this.orgs = orgs;
    this.uri = uri;
    this.bSync = bSync;
  }
  
  @Override
  public List<List<String>> getResult() {
    return this.apiDevApps;
  }
  
  public void run() {
    try {
      long start = System.currentTimeMillis();
     /* log.info("[APIPLATRPT] Starting Thread:{} ",Thread.currentThread().getName());*/
      for (int p = 0; p < this.orgs.length; p++) {
        DeployedAPIProxies deployedApiProxies = APIConfig.getInstance().getDeployedAPIProxies(this.orgs[p]);
        String orgName = deployedApiProxies.getName();
        String httpURI = this.uri.replaceAll("ORG_NAME", orgName);
        String url = "";
        String result = "";
        String startKey = "";
        Set<String> apps = new HashSet();
        String[] appArr = null;
        do {
          url = this.hostname + httpURI + "?expand=false&startKey=" + startKey;
          result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          appArr = (String[])this.mapper.readValue(result, String[].class);
          if (appArr.length <= 0)
            continue; 
          startKey = appArr[appArr.length - 1];
          apps.addAll(new HashSet(Arrays.asList(appArr)));
        } while (appArr.length >= 10000);
        for (String appName : apps) {
          url = this.hostname + httpURI + "/" + appName;
          result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          App app = (App)this.mapper.readValue(result, App.class);
          ApiProducts[] apiProducts = app.getCredentials();
          if (apiProducts.length > 0) {
            for (ApiProducts apiProds : apiProducts) {
              ApiProduct[] apiProduct = apiProds.getApiProducts();
              if (apiProduct.length > 0) {
                for (ApiProduct apiProd : apiProduct) {
                  List<String> list = new ArrayList();
                  list.add(orgName);
                  list.add(app.getName());
                  list.add((app.getAttributes().get("DisplayName") != null) ? (String)app.getAttributes().get("DisplayName") : "");
                  list.add(app.getAppId());
                  list.add(app.getDeveloperId());
                  list.add(app.getStatus());
                  list.add(apiProd.getApiproduct());
                  list.add(apiProds.getExpiresAt() + "");
                  String expiresAtFrmted = "";
                  if (apiProds.getExpiresAt() != -1L) {
                    this.date.setTime(apiProds.getExpiresAt());
                    expiresAtFrmted = this.format.format(this.date);
                  } 
                  list.add(expiresAtFrmted);
                  list.add(app.getCreatedAt() + "");
                  this.date.setTime(app.getCreatedAt());
                  list.add(this.format.format(this.date));
                  list.add(app.getCreatedBy());
                  list.add(app.getLastModifiedAt() + "");
                  this.date.setTime(app.getLastModifiedAt());
                  list.add(this.format.format(this.date));
                  list.add(app.getLastModifiedBy());
                  this.apiDevApps.add(list);
                } 
              } else {
                List<String> list = new ArrayList();
                list.add(orgName);
                list.add(app.getName());
                list.add((app.getAttributes().get("DisplayName") != null) ? (String)app.getAttributes().get("DisplayName") : "");
                list.add(app.getAppId());
                list.add(app.getDeveloperId());
                list.add(app.getStatus());
                list.add("");
                list.add(apiProds.getExpiresAt() + "");
                String expiresAtFrmted = "";
                if (apiProds.getExpiresAt() != -1L) {
                  this.date.setTime(apiProds.getExpiresAt());
                  expiresAtFrmted = this.format.format(this.date);
                } 
                list.add(expiresAtFrmted);
                list.add(app.getCreatedAt() + "");
                this.date.setTime(app.getCreatedAt());
                list.add(this.format.format(this.date));
                list.add(app.getCreatedBy());
                list.add(app.getLastModifiedAt() + "");
                this.date.setTime(app.getLastModifiedAt());
                list.add(this.format.format(this.date));
                list.add(app.getLastModifiedBy());
                this.apiDevApps.add(list);
              } 
            } 
            continue;
          } 
          List<String> apiDevAppsInner = new ArrayList();
          apiDevAppsInner.add(orgName);
          apiDevAppsInner.add(app.getName());
          apiDevAppsInner.add((app.getAttributes().get("DisplayName") != null) ? (String)app.getAttributes().get("DisplayName") : "");
          apiDevAppsInner.add(app.getAppId());
          apiDevAppsInner.add(app.getDeveloperId());
          apiDevAppsInner.add(app.getStatus());
          apiDevAppsInner.add("");
          apiDevAppsInner.add("");
          apiDevAppsInner.add("");
          apiDevAppsInner.add(app.getCreatedAt() + "");
          this.date.setTime(app.getCreatedAt());
          apiDevAppsInner.add(this.format.format(this.date));
          apiDevAppsInner.add(app.getCreatedBy());
          apiDevAppsInner.add(app.getLastModifiedAt() + "");
          this.date.setTime(app.getLastModifiedAt());
          apiDevAppsInner.add(this.format.format(this.date));
          apiDevAppsInner.add(app.getLastModifiedBy());
          this.apiDevApps.add(apiDevAppsInner);
        } 
      } 
      logger.info("[APIPLATRPT] Completed Thread:{} , total time in ms:{}",Thread.currentThread().getName(), (System.currentTimeMillis() - start));
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ", (Throwable)jme);
        logger.error("[APIPLATRPT] JsonMappingException occurred.Error Message:{}",jme.getMessage());
      } 
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}", (Throwable)jpe);
        logger.error("[APIPLATRPT] JsonParseException occurred.Error Message:{} ",jpe.getMessage());
      } 
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {        
        logger.error("[APIPLATRPT] IOException occurred.Error Message:{}",ioe.getMessage());
      } 
    } catch (APIReportException are) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ", (Throwable)are);
        logger.error("[APIPLATRPT] APIReportException occurred.Error Message:{} ",are.getMessage());
      } 
    } finally {
      this.bSync.waitForAll();
    } 
  }
}
