package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Credentials {
	private String apiProducts;
	private String attributes;
	private String consumerKey;
	private String consumerSecret;
	private String expiresAt;
	private String issuedAt;
	private String scopes;
	private String status;
}
