package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Developer {
	 private String[] apps;	  
	  private String email;	  
	  private String developerId;	  
	  private String firstName;	  
	  private String lastName;	  
	  private String userName;	  
	  private String organizationName;	  
	  private String status;	  
	  private NameValue[] attributes;	  
	  private long createdAt;	  
	  private String createdBy;	  
	  private long lastModifiedAt;	  
	  private String[] companies;	  
	  private String lastModifiedBy;
}
