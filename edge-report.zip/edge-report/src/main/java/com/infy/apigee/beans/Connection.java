package com.infy.apigee.beans;

import java.util.Arrays;

import lombok.Getter;
import lombok.Setter;


public class Connection {
	  private String basePath;
	  
	  private String[] arguments;
	  
	  private String connectionType;
	  
	  private Object healthMonitor;
	  
	  private Object loadBalancer;
	  
	  private String path;
	  
	  private NameValue[] environmentVariables;
	  
	  private Property properties;
	  
	  private String[] virtualHost;
	  
	  private SSLInfo sSLInfo;
	  
	  private String uRL;
	  
	  public String[] getVirtualHost() {
	    return this.virtualHost;
	  }
	  
	  public void setVirtualHost(String[] virtualHost) {
	    this.virtualHost = virtualHost;
	  }
	  
	  public String getBasePath() {
	    return this.basePath;
	  }
	  
	  public void setBasePath(String basePath) {
	    this.basePath = basePath;
	  }
	  
	  public String getConnectionType() {
	    return this.connectionType;
	  }
	  
	  public void setConnectionType(String connectionType) {
	    this.connectionType = connectionType;
	  }
	  
	  public NameValue[] getEnvironmentVariables() {
	    return this.environmentVariables;
	  }
	  
	  public void setEnvironmentVariables(NameValue[] environmentVariables) {
	    this.environmentVariables = environmentVariables;
	  }
	  
	  public Property getProperties() {
	    return this.properties;
	  }
	  
	  public void setProperties(Property properties) {
	    this.properties = properties;
	  }
	  
	  public SSLInfo getsSLInfo() {
	    return this.sSLInfo;
	  }
	  
	  public void setsSLInfo(SSLInfo sSLInfo) {
	    this.sSLInfo = sSLInfo;
	  }
	  
	  public String toString() {
	    return "Connection [basePath=" + this.basePath + ", arguments=" + 
	      Arrays.toString((Object[])this.arguments) + ", connectionType=" + this.connectionType + ", healthMonitor=" + this.healthMonitor + ", loadBalancer=" + this.loadBalancer + ", path=" + this.path + ", environmentVariables=" + 
	      
	      Arrays.toString((Object[])this.environmentVariables) + ", properties=" + this.properties + ", virtualHost=" + 
	      Arrays.toString((Object[])this.virtualHost) + ", sSLInfo=" + this.sSLInfo + ", uRL=" + this.uRL + "]";
	  }
	  
	  public String getuRL() {
	    return this.uRL;
	  }
	  
	  public void setuRL(String uRL) {
	    this.uRL = uRL;
	  }
	  
	  public String[] getArguments() {
	    return this.arguments;
	  }
	  
	  public void setArguments(String[] arguments) {
	    this.arguments = arguments;
	  }
	  
	  public Object getHealthMonitor() {
	    return this.healthMonitor;
	  }
	  
	  public void setHealthMonitor(Object healthMonitor) {
	    this.healthMonitor = healthMonitor;
	  }
	  
	  public Object getLoadBalancer() {
	    return this.loadBalancer;
	  }
	  
	  public void setLoadBalancer(Object loadBalancer) {
	    this.loadBalancer = loadBalancer;
	  }
	  
	  public String getPath() {
	    return this.path;
	  }
	  
	  public void setPath(String path) {
	    this.path = path;
	  }
	}

