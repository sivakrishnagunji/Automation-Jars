package com.infy.apigee.connectors;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.infy.apigee.exceptions.APIReportException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HTTPConnection {
	private HTTPConnection() {
	}

	private static class SingletonHolder {
		private static final HTTPConnection INSTANCE = new HTTPConnection();
	}

	public static HTTPConnection getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	 public String openURL(String httpURL, String encUserPass) throws APIReportException {
		    String result = "";
		    HttpURLConnection connection = null;
		    try {
		      System.setProperty("https.protocols", "TLSv1.2");
		      URL httpurl = new URL(httpURL);
		      connection = (HttpURLConnection)httpurl.openConnection();
		      connection.setRequestProperty("Authorization", "Basic " + encUserPass);
		      connection.setRequestProperty("Content-Type", "application/json");
		      connection.setRequestProperty("Accept", "application/json");
		      BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
		      String str = "";
		      while ((str = in.readLine()) != null)
		        result = result + str; 
		      in.close();
		      connection.disconnect();
		      Thread.sleep(100L);
		    } catch (FileNotFoundException fnfe) {
		      try {
		        log.error("[APIPLATRPT] FileNotFoundException occurred. Error code:{}, Error Message:{}" , connection.getResponseCode(), fnfe.getMessage());
		      } catch (IOException ioe) {
		        log.error("[APIPLATRPT] FileNotFoundException occurred. Unable to fetch Error code:{}", ioe.getMessage());
		      } 
		    } catch (IOException ioe) {
		      log.info("[APIPLATRPT] IOException occurred.Exception:{}", ioe.getMessage());
		      log.info("Creds: ******" + encUserPass + "****");
		      throw new APIReportException(ioe);
		    } catch (InterruptedException e) {
		      log.error("[APIPLATRPT] InterruptedException occurred.Exception:{}", e.getMessage());
		    } finally {}
		    return result;
		  }
}
