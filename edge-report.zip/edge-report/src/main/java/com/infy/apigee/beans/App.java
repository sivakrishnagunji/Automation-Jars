package com.infy.apigee.beans;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


public class App {
	private String accessType;
	private Object[] apiProducts;
	private String appFamily;
	private String appId;
	private String callbackUrl;
	private long createdAt;
	private String createdBy;
	private ApiProducts[] credentials;
	private String developerId;
	private long lastModifiedAt;
	private String lastModifiedBy;
	private String name;
	private Object[] scopes;
	private String status;
	private Map<String, String> attributes;

	public Map<String, String> getAttributes() {
		return this.attributes;
	}

	public void setAttributes(NameValue[] property) {
		this.attributes = new HashMap();
		for (NameValue nv : property)
			this.attributes.put(nv.getName(), nv.getValue());
	}

	public String getAccessType() {
		return this.accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public Object[] getApiProducts() {
		return this.apiProducts;
	}

	public void setApiProducts(Object[] apiProducts) {
		this.apiProducts = apiProducts;
	}

	public String getAppFamily() {
		return this.appFamily;
	}

	public void setAppFamily(String appFamily) {
		this.appFamily = appFamily;
	}

	public String getAppId() {
		return this.appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getCallbackUrl() {
		return this.callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public long getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(long createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ApiProducts[] getCredentials() {
		return this.credentials;
	}

	public void setCredentials(ApiProducts[] credentials) {
		this.credentials = credentials;
	}

	public String getDeveloperId() {
		return this.developerId;
	}

	public void setDeveloperId(String developerId) {
		this.developerId = developerId;
	}

	public long getLastModifiedAt() {
		return this.lastModifiedAt;
	}

	public void setLastModifiedAt(long lastModifiedAt) {
		this.lastModifiedAt = lastModifiedAt;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object[] getScopes() {
		return this.scopes;
	}

	public void setScopes(Object[] scopes) {
		this.scopes = scopes;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String toString() {
		return "accessType is " + this.accessType + ", apiProducts is " + Arrays.<Object>asList(this.apiProducts)
				+ ", appFamily is " + this.appFamily + ", appId is " + this.appId + ", attributes is " +

				Arrays.<Map>asList(new Map[] { this.attributes }) + ", callbackUrl is " + this.callbackUrl
				+ ", createdAt is " + this.createdAt + ", createdBy is " + this.createdBy + ", credentials is " +

				Arrays.<ApiProducts>asList(this.credentials) + ", developerId is " + this.developerId
				+ ", lastModifiedAt is " + this.lastModifiedAt + ", lastModifiedBy is " + this.lastModifiedBy
				+ ", name is " + this.name + ", scopes is " +

				Arrays.<Object>asList(this.scopes) + ", status is " + this.status;
	}

}
