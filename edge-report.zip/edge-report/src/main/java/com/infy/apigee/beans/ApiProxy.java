package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiProxy {

	private ApiProxyMetaData metaData;
	private String name;
	private String[] revision;
}
