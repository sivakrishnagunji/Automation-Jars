package com.infy.apigee.beans;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CollectionsResult {
	private String uuid;
	private String organization;
	private String environment;
	private String name;
	private String type;
	private String[] members;
	private String description;
	private String updatedAt;
	private String updatedBy;
	
	
}