package com.infy.apigee.utils;

public class BSync {
	int totalThreads = 0;

	int currentThreads = 0;

	public void setCount(int x) {
		this.totalThreads = x;
		this.currentThreads = 0;
	}

	public synchronized void waitForAll() {
		this.currentThreads++;
		if (this.currentThreads < this.totalThreads) {
			try {
				wait();
			} catch (Exception exception) {
			}
		} else {
			this.currentThreads = 0;
			notifyAll();
		}
	}
}
