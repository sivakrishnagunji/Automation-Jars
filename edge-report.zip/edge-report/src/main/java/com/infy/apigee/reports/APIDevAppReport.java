package com.infy.apigee.reports;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.APIConfig;

public class APIDevAppReport implements IReport {
  private static final Logger logger = LoggerFactory.getLogger(APIDevAppReport.class);
  
  public APIDevAppReport(String env) throws APIReportException {}
  
  @Override
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    long start = System.currentTimeMillis();
    List<List<String>> apiDevApps = APIConfig.getInstance().getApiDevApps();
    apiDevApps.add(0, Arrays.asList(new String[] { 
            "Org Name", "Dev App Name", "Dev App Display Name", "Dev App Id", "Developer Id", "Status", "Product", "ExpiresAt", "ExpiresAt (Frmted)", "CreatedAt", 
            "CreatedAt (Frmted)", "CreatedBy", "LastModifiedAt", "LastModifiedAt (Frmted)", "LastModifiedBy" }));
    logger.info("[APIPLATRPT] API Dev Apps Report took: " + (System.currentTimeMillis() - start) + " ms.");
    System.out.println("Alerts Report Completed");
    return apiDevApps;
  }
}
