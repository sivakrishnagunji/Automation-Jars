package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;


import com.infy.apigee.beans.KVM;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrgKVMReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(OrgKVMReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public OrgKVMReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
	  try {
	      long start = System.currentTimeMillis();
	      System.out.println("KVM Report");
	      HTTPConnection httpConn = HTTPConnection.getInstance();
	      List<List<String>> kvms = new ArrayList();
	      kvms.add(Arrays.asList(new String[] { 
	              "Org Name", "KVM Name", "Encrypted", "KVM Entries" }));
	      for (String org : orgs) {
	        String orgName = org;
	        String attr = (String)props.get("OrgKVM");
	        String uri = attr.split(",")[0];
	        uri = uri.replaceAll("ORG_NAME", orgName);
	           	
	            String url = hostname + uri;
	            String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
	          
	          String[] keyvaluemaps = (String[])this.mapper.readValue(result, String[].class);
	          for (String kvm : keyvaluemaps) {
	        	 String url2 = url + "/" + kvm;
	           String result1 = httpConn.openURL(url2, APIConfig.getInstance().getUserPass());
	            KVM ts = (KVM)this.mapper.readValue(result1, KVM.class);
	            List<String> tsInner = new ArrayList<String>();
	            tsInner.add(orgName);
	            tsInner.add(ts.getName()); 
	            tsInner.add(ts.getEncrypted());
	            tsInner.add(ts.getEntry().toString());           
	       
	            kvms.add(tsInner);
	          } 
	        } 
                 
      
      logger.info("[APIPLATRPT] Org Environment KVM Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Organization KVM Report Completed");
      return kvms;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Org Environment KVM Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Org Environment KVM ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Org Environment KVM Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Org Environment KVM Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}


