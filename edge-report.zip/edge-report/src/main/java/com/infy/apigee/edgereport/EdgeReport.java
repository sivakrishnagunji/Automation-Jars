package com.infy.apigee.edgereport;

import com.infy.apigee.excel.ExcelSheet;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.reports.IReport;
import com.infy.apigee.reports.ReportFactory;
import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.utils.DateFormatter;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.slf4j.*;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;


public class EdgeReport {
	private static Properties props ;

	public EdgeReport() throws APIReportException {
		props = loadProperties();
	}
	public static Logger logger = LoggerFactory.getLogger(EdgeReport.class);
  static String URIpropertiesPath;
  static String ReportPath;
  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy_HH_mm_ss");  
  LocalDateTime now = LocalDateTime.now();  
  //Date current_date = new Date();  
  String date = dtf.format(now);
  //static String credentials=EmailPassword;
	public static void main(String[] args) {
		System.out.println("Hello World!");
		
		try {
			logger.info("[APIPLATRPT] Starting APIPlatformReport .... ");
			logger.info("[APIPLATRPT] APIPlatformReport build version 03072022 alpha .... ");
			
			long start = System.currentTimeMillis();
			
			System.out.println("start:" + args[0] + ":" + args[1] + ":" + args[2] + ":" + args[3] + ":" + args[4]);
			
			URIpropertiesPath=args[2].toString();
			ReportPath=args[3].toString();
			EdgeReport apiPlatformReport = new EdgeReport();
			try {
				System.out.println("Within catch 1" + args[0] + ":" + args[1] + ":" + args[2]);
				APIConfig.getInstance().setUserPass(new String(Base64.encodeBase64(args[4].getBytes("UTF-8"))));
				//String credentials = props.get("Credentials").toString();
				//APIConfig.getInstance().setUserPass(new String(Base64.encodeBase64(credentials.getBytes("UTF-8"))));
				//APIConfig.getInstance().setUserPass(new String(credentials.getBytes("UTF-8")));
			} catch (UnsupportedEncodingException uee) {
				
				throw new APIReportException(uee);
			}
			
			apiPlatformReport.generateReport(args[0], args[1]);
			System.out.println("After Generate Report");
			logger.info(
					"[APIPLATRPT] Completed APIPlatformReport, took: " + (System.currentTimeMillis() - start) + " ms.");
		} catch (APIReportException are) {
			System.out.println("Within catch 1");
			logger.error("[APIPLATRPT] APIReportException occurred. ", (Throwable) are);
		} catch (Exception e) {
			System.out.println("Within catch 2:" + e.getMessage());
			logger.error("[APIPLATRPT] Exception occurred. ", e);
		}
	}

	private void generateReport(String env, String hostname) throws APIReportException {
		String[] orgs = ((String) this.props.get("Orgs." + env)).split(",");
		String[] reports = ((String) this.props.get("Reports")).split(",");
		List<List<List<String>>> obj = new ArrayList();
		List<String> reportList = new ArrayList();
		for (int i = 0; i < reports.length; i++) {
			IReport report = ReportFactory.getReport(reports[i], env);
			obj.add(report.generateReport(hostname, this.props, orgs));
			reportList.add(reports[i]);
		}
		for (String org : orgs) {
		//String orgName = orgs.toString();
		long start = System.currentTimeMillis();
		ExcelSheet consolXls = new ExcelSheet();
		String reportFilePath = ReportPath + "/" + org + ".xlsx";
		logger.info("[APIPLATRPT] Creating final report at path " + reportFilePath);
		consolXls.createWorkbook(reportFilePath);
		try {
			List<List<String>> rows = new ArrayList();
			Sheet summarySheet = consolXls.populateSheet("Summary", rows, 1, 1);
			Row row = summarySheet.createRow((short)1);
			Row header = summarySheet.createRow((short)0);
			header.createCell(1).setCellValue("PARAMETER");
			header.createCell(2).setCellValue("ORG NAME");
			header.createCell(3).setCellValue("COUNT");
	            
			for (int j = 0; j < reports.length; j++) {	
				System.out.println(reports[j]);	
			consolXls.populateSheet(reports[j], obj.get(j), 1, 1);
			
			Map<String, String> orgLevelAPIMap = getConsolCountMap(obj.get(reportList.indexOf("APIProxies")),0);
			List<List<String>> orgApiData = getConsolData(orgLevelAPIMap);
			consolXls.populateSheet(summarySheet, orgApiData, 1, 2);			
			row.createCell(1).setCellValue("Number of APIs");
			
			Map<String, String> orgLevelDeployedAPIMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("DeployedAPIProxies")), 0, 2));
			List<List<String>> orgDeployedApiData = getConsolData(orgLevelDeployedAPIMap);
			row = summarySheet.createRow((short)2);
			consolXls.populateSheet(summarySheet, orgDeployedApiData, 2, 2);			
			row.createCell(1).setCellValue("Number of Deployed APIs");
			
			Map<String, String> orgLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Products")), 0, 1) );
			List<List<String>> orgProdData = getConsolData(orgLevelProdMap);
			row = summarySheet.createRow((short)3);			
			consolXls.populateSheet(summarySheet, orgProdData, 3, 2);			
			row.createCell(1).setCellValue("Number of Products");
			
			Map<String, String> devAppsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("DevApps")), 0, 3));
			List<List<String>> devAppsProdData = getConsolData(devAppsLevelProdMap);
			row = summarySheet.createRow((short)4);
			consolXls.populateSheet(summarySheet, devAppsProdData, 4, 2);			
			row.createCell(1).setCellValue("Number of Dev Apps");
			
			Map<String, String> developersLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("DevelopersList")), 0, 1));
			List<List<String>> developersProdData = getConsolData(developersLevelProdMap);
			row = summarySheet.createRow((short)5);
			consolXls.populateSheet(summarySheet, developersProdData, 5, 2);			
			row.createCell(1).setCellValue("Number of Developers");
			
			/*Map<String, String> targetServerLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("TargetServer")), 0, 2));
			List<List<String>> targetServersProdData = getConsolData(targetServerLevelProdMap);
			row = summarySheet.createRow((short)6);
			consolXls.populateSheet(summarySheet, targetServersProdData, 6, 2);			
			row.createCell(1).setCellValue("Number of TargetServers");
			
			Map<String, String> referencesLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("References")), 0, 2));
			List<List<String>> referencesProdData = getConsolData(referencesLevelProdMap);
			row = summarySheet.createRow((short)7);
			consolXls.populateSheet(summarySheet, referencesProdData, 7, 2);			
			row.createCell(1).setCellValue("Number of References");
			
			Map<String, String> sharedflowsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Shared_Flows")), 0, 1));
			List<List<String>> sharedflowsProdData = getConsolData(sharedflowsLevelProdMap);
			row = summarySheet.createRow((short)8);
			consolXls.populateSheet(summarySheet, sharedflowsProdData, 8, 2);			
			row.createCell(1).setCellValue("Number of Sharedflows");
			
			Map<String, String> kvmLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("KVMs")), 1, 0));
			List<List<String>> kvmProdData = getConsolData(kvmLevelProdMap);
			row = summarySheet.createRow((short)9);
			consolXls.populateSheet(summarySheet, kvmProdData, 9, 2);			
			row.createCell(1).setCellValue("Number of KVMS");
			
			Map<String, String> cachesLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Caches")), 1, 0));
			List<List<String>> cachesProdData = getConsolData(cachesLevelProdMap);
			row = summarySheet.createRow((short)10);
			consolXls.populateSheet(summarySheet, cachesProdData, 10, 2);			
			row.createCell(1).setCellValue("Number of Caches");
			
			Map<String, String> flowhookLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("FlowHooks")), 0, 2));
			List<List<String>> flowhookProdData = getConsolData(flowhookLevelProdMap);
			row = summarySheet.createRow((short)11);
			consolXls.populateSheet(summarySheet, flowhookProdData, 11, 2);			
			row.createCell(1).setCellValue("Number of FlowHooks");
			
			Map<String, String> collectionsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Collections")), 0, 3));
			List<List<String>> collectionsProdData = getConsolData(collectionsLevelProdMap);
			row = summarySheet.createRow((short)12);
			consolXls.populateSheet(summarySheet, collectionsProdData, 12, 2);			
			row.createCell(1).setCellValue("Number of Collections");
			
			Map<String, String> alertsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Alerts")), 1, 0));
			List<List<String>> alertsProdData = getConsolData(alertsLevelProdMap);
			row = summarySheet.createRow((short)13);
			consolXls.populateSheet(summarySheet, alertsProdData, 13, 2);			
			row.createCell(1).setCellValue("Number of Alerts");
			
			Map<String, String> apispecificationsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("ApiSpecificationContents")), 0, 1));
			List<List<String>> apispecificationsProdData = getConsolData(apispecificationsLevelProdMap);
			row = summarySheet.createRow((short)14);
			consolXls.populateSheet(summarySheet, apispecificationsProdData, 14, 2);			
			row.createCell(1).setCellValue("Number of ApiSpecifications");
			
			Map<String, String> customreportsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("CustomReports")), 0, 1));
			List<List<String>> customreportsProdData = getConsolData(customreportsLevelProdMap);
			row = summarySheet.createRow((short)15);
			consolXls.populateSheet(summarySheet, customreportsProdData, 15, 2);			
			row.createCell(1).setCellValue("Number of CustomReports");
			
			Map<String, String> vhostsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("VHosts")), 0, 2));
			List<List<String>> vhostsProdData = getConsolData(vhostsLevelProdMap);
			row = summarySheet.createRow((short)16);
			consolXls.populateSheet(summarySheet, vhostsProdData, 16, 2);			
			row.createCell(1).setCellValue("Number of Virtual Hosts");
			
			Map<String, String> keystoresLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("KeyStores")), 0, 2));
			List<List<String>> keystoresProdData = getConsolData(keystoresLevelProdMap);
			row = summarySheet.createRow((short)17);
			consolXls.populateSheet(summarySheet, keystoresProdData, 17, 2);			
			row.createCell(1).setCellValue( "Number of Keystores");
			
			Map<String, String> resourcepermissionsLevelProdMap = getOrgUniqueServicesMap(getUniqueConsolCountMap(obj.get(reportList.indexOf("Roles")), 0, 1));
			List<List<String>> resourcepermissionsProdData = getConsolData(resourcepermissionsLevelProdMap);
			row = summarySheet.createRow((short)18);
			consolXls.populateSheet(summarySheet, resourcepermissionsProdData, 18, 2);			
			row.createCell(1).setCellValue("Number of Roles	");
			
			Map<String, String> extensionsLevelProdMap = getOrgUniqueServicesMap(
					getUniqueConsolCountMap(obj.get(reportList.indexOf("Extensions")), 1, 0));
			List<List<String>> extensionsProdData = getConsolData(extensionsLevelProdMap);
			row = summarySheet.createRow((short)19);
			consolXls.populateSheet(summarySheet, extensionsProdData, 19, 2);			
			row.createCell(1).setCellValue("Number of Extensions");*/
			
			List<List<String>> tsList = new ArrayList();
			tsList.add(Arrays.asList(new String[] { "This report was generated on " + new Date() }));
			consolXls.populateSheet(summarySheet, tsList, 26, 13);
		} }catch (Exception e) {
			throw new APIReportException(e);
		}
		updateSheetData(consolXls, consolXls.getSheet("KeyStores"), env);
		consolXls.exitSheet();
		if (logger.isInfoEnabled())
			logger.info("[APIPLATRPT] Report creation completed in " + (System.currentTimeMillis() - start) + " ms.");
	}}

	private Map<String, String> getConsolCountMap(List<List<String>> list, int index) {
		Map<String, String> map = new LinkedHashMap();
		//map.put("");
		for (int i = 1; i < list.size(); i++) {
			for (int j = 0; j < ((List) list.get(i)).size(); j++) {
				if (j == index) {
					String value = ((String) ((List<String>) list.get(i)).get(j)).toString().trim();
					if (map.get(value) == null) {
						map.put(value, "1");
						break;
					}
					int data = Integer.parseInt(map.get(value));
					map.put(value, (1 + data) + "");
					break;
				}
			}
		}
		return map;
	}

	private Map<String, String> getUniqueConsolCountMap(List<List<String>> list, int firstKey, int secondKey) {
		Map<String, String> map = new LinkedHashMap();
		for (int i = 1; i < list.size(); i++) {
			String org = ((String) ((List<String>) list.get(i)).get(firstKey)).toString().trim();
			String entity = ((String) ((List<String>) list.get(i)).get(secondKey)).toString().trim();
			String value = org + "," +entity;
			if (map.get(value) == null)
				map.put(value, "1");
		}
		return map;
	}

	private static Map<String, String> getOrgUniqueServicesMap(Map<String, String> map1) {
		Map<String, String> map = new LinkedHashMap();
		//map.put("", title);
		Iterator<String> it = map1.keySet().iterator();
		while (it.hasNext()) {
			String value = ((String) it.next()).trim().split(",")[0];
			if (map.get(value) == null) {
				map.put(value, "1");
				continue;
			}
			int data = Integer.parseInt(map.get(value));
			map.put(value, (1 + data) + "");
		}
		return map;
	}

	private List<List<String>> getConsolData(Map<String, String> inputMap) {
		Map<String, String> dataMap = new LinkedHashMap();
	//	dataMap.put("" , "");
		dataMap.putAll(inputMap);
		List<List<String>> rows = new ArrayList();
		Iterator<String> itp = dataMap.keySet().iterator();
		while (itp.hasNext()) {
			String key = itp.next();
			List<String> cells = new ArrayList();
			cells.add(key);
			cells.add(dataMap.get(key));
			rows.add(cells);
		}
		return rows;
	}

	private void updateSheetData(ExcelSheet consolXls, Sheet sheet, String node) {
		Cell cell2 = null;
		if (sheet.getSheetName().contains("KeyStores")) {
			int i = 0;
			for (Row row : sheet) {
				int lastColumnNum = 18;
				if (i == 0) {
					cell2 = row.createCell(lastColumnNum);
					cell2.setCellValue("Status");
					consolXls.setCellStyle(cell2, "Light Gray", true);
					i++;
					continue;
				}
				int j = 0;
				for (Cell cell : row) {
					
					if (j == 11) {
						Date date1 = DateFormatter.formatDate(cell.getRichStringCellValue().getString().trim());
						Date date2 = new Date();
						if (date1.getTime() - date2.getTime() < (Integer
								.parseInt(this.props.get("CertAlertThresholdInDays").toString().trim()) * 24 * 60 * 60)
								* 1000L) {
							for (Cell cell4 : row) {
								
								consolXls.setCellStyle(cell4, "red", false);}
							Cell cell3 = row.createCell(lastColumnNum);
							consolXls.setCellStyle(cell3, "", false);
							cell3.setCellValue("ERROR");
				            break;
						}
					} else if (j == 14 && cell.getRichStringCellValue().getString().trim().equalsIgnoreCase("No")) {
						for (Cell cell4 : row)
							consolXls.setCellStyle(cell4, "red", false);
						Cell cell3 = row.createCell(lastColumnNum);
						consolXls.setCellStyle(cell3, "", false);
						cell3.setCellValue("ERROR");
						break;
					}
					j++;
				}
				i++;
			}
		}
	}

	private Properties loadProperties() throws APIReportException {
		Properties props = null;
		try {
			props = new Properties();
			//InputStream in = getClass().getClassLoader().getResourceAsStream("URI.properties");
			//InputStream in = new FileInputStream("/URI.properties");
			FileInputStream file = new FileInputStream(URIpropertiesPath);
			//FileInputStream in = new FileInputStream(file);
			InputStreamReader in = new InputStreamReader(file);
			props.load(in);
			in.close();
		} catch (IOException ioe) {
			throw new APIReportException(ioe);
		}
		return props;
	}
}
