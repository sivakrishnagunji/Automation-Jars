package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SSLInfo {
	private String[] ciphers;
	private String clientAuthEnabled;
	private String enabled;
	private String ignoreValidationErrors;
	private String keyAlias;
	private String keyStore;
	private String[] protocols;
	private String trustStore;
}
