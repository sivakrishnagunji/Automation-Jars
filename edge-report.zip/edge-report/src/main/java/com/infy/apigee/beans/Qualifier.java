package com.infy.apigee.beans;


import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Qualifier {
	
	private CustomAnalytics customAnalytics;
	
	}
