package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RouteRule {
	private Object[] ciphers;
	private boolean clientAuthEnabled;
	private boolean enabled;
	private boolean ignoreValidationErrors;
	private String keyAlias;
	private String keyStore;
	private Object[] protocols;
	private String trustStore;
}
