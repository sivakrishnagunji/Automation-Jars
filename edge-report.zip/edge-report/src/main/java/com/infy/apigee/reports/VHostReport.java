package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.VHosts;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class VHostReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(VHostReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private FileWriter fw = null;  
  public VHostReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> vHosts = new ArrayList();
      vHosts.add(Arrays.asList(new String[] { 
              "Org Name", "Env Name", "VHost Name", "Port", "Host Alias", "Interfaces", "KeyAlias", "KeyStore", "TrustStore", "Protocols", 
              "Ciphers" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("VHosts");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        String httpURI = uri.replaceAll("ORG_NAME", orgName);
        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
        for (String env : envs) {
          String uri_2 = httpURI.replaceAll("ENV_NAME", env);
          String url = hostname + uri_2;
          String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          String[] vhs = (String[])this.mapper.readValue(result, String[].class);
          for (String vHost : vhs) {
            url = hostname + uri_2 + "/" + vHost;
            result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
            VHosts vh = (VHosts)this.mapper.readValue(result, VHosts.class);
            List<String> vHostsInner = new ArrayList();
            vHostsInner.add(orgName);
            vHostsInner.add(env);
            vHostsInner.add(vh.getName());
            vHostsInner.add(vh.getPort());
            vHostsInner.add(Arrays.<String>asList(vh.getHostAliases()).toString().replace(',', ' ').toString());
            vHostsInner.add(Arrays.<String>asList(vh.getInterfaces()).toString().replace(',', ' ').toString());
            vHostsInner.add((vh.getSSLInfo() != null) ? vh.getSSLInfo().getKeyAlias() : "");
            vHostsInner.add((vh.getSSLInfo() != null) ? vh.getSSLInfo().getKeyStore() : "");
            vHostsInner.add((vh.getSSLInfo() != null) ? ((vh.getSSLInfo().getTrustStore() != null) ? vh.getSSLInfo().getTrustStore() : "") : "");
            vHostsInner.add((vh.getProperties() != null) ? ((vh.getProperties().getProperty("ssl_protocols") != null) ? vh.getProperties().getProperty("ssl_protocols") : "") : "");
            vHostsInner.add((vh.getProperties() != null) ? ((vh.getProperties().getProperty("ssl_ciphers") != null) ? vh.getProperties().getProperty("ssl_ciphers") : "") : "");
            vHosts.add(vHostsInner);
          } 
        } 
      } 
      logger.info("[APIPLATRPT] VHosts Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Virtual Hosts Report Completed");
      return vHosts;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

