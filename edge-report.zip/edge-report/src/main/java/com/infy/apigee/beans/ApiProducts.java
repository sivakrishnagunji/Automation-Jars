package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiProducts {
	private ApiProduct[] apiProducts;
	private NameValue[] attributes;
	private String consumerKey;
	private String consumerSecret;
	private long expiresAt;
	private long issuedAt;
	private Object[] scopes;
	private String status;
}
