package com.infy.apigee.reports;

import java.util.List;
import java.util.Properties;

import com.infy.apigee.exceptions.APIReportException;

public interface IReport {
	  List<List<String>> generateReport(String paramString, Properties paramProperties, String[] paramArrayOfString) throws APIReportException;
	}
