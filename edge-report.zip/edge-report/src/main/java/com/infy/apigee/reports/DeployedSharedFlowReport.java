package com.infy.apigee.reports;

import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.Caches;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.DeployedSharedFlow;
import com.infy.apigee.beans.DeployedSharedFlows;
import com.infy.apigee.beans.Revision;
import com.infy.apigee.beans.SharedFlowRevision;
import com.infy.apigee.beans.SharedFlows;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DeployedSharedFlowReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(DeployedSharedFlowReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private FileWriter fw = null;  
  private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.S z");  
  public DeployedSharedFlowReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> apis = new ArrayList();
      apis.add(Arrays.asList(new String[] { 
              "Org Name", "Env Name", "SharedFlow Name","Deployed Revision", "CreatedAt", "CreatedAt (Frmted)", "CreatedBy", "LastModifiedAt", "LastModifiedAt (Frmted)", 
              "LastModifiedBy" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("Shared_Flows");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        uri = uri.replaceAll("ORG_NAME", orgName);
        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
        for (String env : envs) {
        String url = hostname + uri;
        String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        
        String[] sharedFlows = (String[])this.mapper.readValue(result, String[].class);
        for (String sharedFlow : sharedFlows) {
      	  url = hostname + uri + "/" + sharedFlow;
          String result1 = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          /*System.out.println(result);*/
          SharedFlows sf = (SharedFlows)this.mapper.readValue(result1, SharedFlows.class);
                List<String> apiInner = new ArrayList();
                apiInner.add(orgName);
                apiInner.add(env);
                apiInner.add(sharedFlow);
                apiInner.add(sf.getRevision().toString());
                apiInner.add(sf.getMetaData().getCreatedAt() + "");
                this.date.setTime(sf.getMetaData().getCreatedAt());
                apiInner.add(this.format.format(this.date));
                apiInner.add((sf.getMetaData().getCreatedBy() != null) ? sf.getMetaData().getCreatedBy() : "");
                apiInner.add(sf.getMetaData().getLastModifiedAt() + "");
                this.date.setTime(sf.getMetaData().getLastModifiedAt());
                apiInner.add(this.format.format(this.date));
                apiInner.add(sf.getMetaData().getLastModifiedBy());
                apis.add(apiInner);
              } 
            } 
          } 
        
      
      logger.info("[APIPLATRPT] Deployed SharedFlows Report took in ms: " ,(System.currentTimeMillis() - start));
      System.out.println("Deployed Shared flow Report Completed");
      return apis;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

