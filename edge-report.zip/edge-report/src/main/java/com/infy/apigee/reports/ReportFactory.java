package com.infy.apigee.reports;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infy.apigee.edgereport.EdgeReport;
import com.infy.apigee.exceptions.APIReportException;

import lombok.extern.slf4j.Slf4j;

public class ReportFactory {
	public static Logger logger = LoggerFactory.getLogger(ReportFactory.class);
	  public static IReport getReport(String reportName, String env) throws APIReportException {
	    IReport report = null;
	    if (reportName.equals("Environments")) {
	      report = new EnvironmentReport(env);
	    } else if (reportName.equals("APIProxies")) {
	      report = new APIReport(env);
	    } else if (reportName.equals("DeployedAPIProxies")) {
	      report = new DeployedAPIReport(env);
	    } else if (reportName.equals("APIEndpoints")) {
	      report = new APIProxyEPTargetEPReport(env);
	    } else if (reportName.equals("APIProxyURIResources")) {
	      report = new APIProxyURIResourcesReport(env);
	    } else if (reportName.equals("Resources")) {
	      report = new ResourceReport(env);
	    } else if (reportName.equals("DevApps")) {
	      report = new APIDevAppReport(env);
	    } else if (reportName.equals("Developers")) {
	      report = new DeveloperReport(env);
	    }else if (reportName.equals("DevelopersList")) {
		      report = new DevelopersList(env);
		 }else if (reportName.equals("APIProxyResources")) {
	      report = new APIProxyResourceReport(env);
	    }else if (reportName.equals("EnvironmentResources")) {
		      report = new EnvironmentResourcesReport(env);
		 }else if (reportName.equals("OrgResources")) {
		      report = new OrgResourcesReport(env);
		 }else if (reportName.equals("Products")) {
	      report = new ProductReport(env);
	    } else if (reportName.equals("VHosts")) {
	      report = new VHostReport(env);
	    } else if (reportName.equals("KeyStores")) {
	      report = new KeyStoreReport(env);
	    } else if (reportName.equals("Roles")) {
	      report = new RolesReport(env);
	    }else if (reportName.equals("TargetServer")) {
		      report = new TargetServerReport(env);
		    }
	    else if (reportName.equals("References")) {
		      report = new ReferenceReport(env);
		    }
	    else if (reportName.equals("Shared_Flows")) {
		      report = new SharedFlowReport(env);
	    }
	    else if (reportName.equals("Caches")) {
		      report = new CachesReport(env);
	    }
	    else if (reportName.equals("DeployedSharedFlows")) {
		      report = new DeployedSharedFlowReport(env);
	    }
	    else if (reportName.equals("KVMs")) {
		      report = new KVMReport(env);
	    }
	    else if (reportName.equals("CustomReports")) {
		      report = new CustomReportsReport(env);
	    }
	    else if (reportName.equals("FlowHooks")) {
		      report = new FlowHookReport(env);
	    }
	    else if (reportName.equals("APIProxyKVM")) {
		      report = new APIProxyKVMReport(env);
	    }
	    else if (reportName.equals("OrgKVM")) {
		      report = new OrgKVMReport(env);
	    }
	    else if (reportName.equals("Collections")) {
		      report = new CollectionReport(env);
	    }
	    else if (reportName.equals("Alerts")) {
		      report = new AlertsReport(env);
	    }
	    else if (reportName.equals("ApiSpecifications")) {
		      report = new ApiSpecificationsReport(env);
	    }
	    else if (reportName.equals("ApiSpecificationContents")) {
		      report = new ApiSpecificationContentsReport(env);
	    }
	    else if (reportName.equals("Extensions")) {
		      report = new ExtensionsReport(env);
	    }
	    else {
	    	logger.info("report name ={}",reportName.toString());
	      throw new APIReportException("Invalid report type .... ");
	    } 
	    return report;
	  }
	}

