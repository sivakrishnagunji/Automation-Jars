package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.ResourceFile;
import com.infy.apigee.beans.Resources;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class OrgResourcesReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(OrgResourcesReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private FileWriter fw = null;
  
  public OrgResourcesReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> resources = new ArrayList();
      resources.add(Arrays.asList(new String[] { "Org Name", "ResourceFile Name" , "Type"}));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("OrgResources");
        String uri = attr.split(",")[0];
        //Class<?> x = attr.split(",")[1].getClass();
        uri = uri.replaceAll("ORG_NAME", orgName);
        String url = hostname + uri;
        
        String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
        if (result.length() != 0) {
            Resources apiRsrcs = (Resources)this.mapper.readValue(result, Resources.class);
            for (ResourceFile resourceFile : apiRsrcs.getResourceFile()) {
              List<String> ResourcesInner = new ArrayList();
              ResourcesInner.add(orgName);
             
              //apiResourcesInner.add(apiName);
             // apiResourcesInner.add(revName);
              ResourcesInner.add(resourceFile.getName());
              ResourcesInner.add(resourceFile.getType());;
		          resources.add(ResourcesInner);
        
        }
        }
      }
      logger.info("[APIPLATRPT] Org ResourceFiles Report took in ms:{} " , (System.currentTimeMillis() - start));
      System.out.println("APIs Report Completed");
      return resources;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{} ",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}


