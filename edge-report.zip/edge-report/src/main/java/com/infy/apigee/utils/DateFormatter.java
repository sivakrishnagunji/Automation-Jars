package com.infy.apigee.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter {
  public static Date formatDate(String dateIn) {
    SimpleDateFormat formatter = new SimpleDateFormat("EEE  dd MMM yyyy HH:mm:ss z");
    Date date = null;
    try {
      date = formatter.parse(dateIn);
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return date;
  }
  

}
