package com.infy.apigee.beans;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Caches {
	private String name;
	private String overflowToDisk;
	private String persistent;
	private String distributed;
	private String description;
	private Long diskSizeInMB;
	private Long inMemorySizeInKB;
	private Long maxElementsInMemory;
	private Long maxElementsOnDisk;
	private ExpirySettings expirySettings;
	}
