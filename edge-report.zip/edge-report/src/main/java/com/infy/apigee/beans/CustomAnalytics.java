package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomAnalytics {

	private String displayname;
	private String name;
}
