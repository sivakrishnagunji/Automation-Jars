package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TargetServer {
	private String host;
	private boolean isEnabled;
	private String name;
	private String port;
	private SSLInfo sSLInfo;
}
