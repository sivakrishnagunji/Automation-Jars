package com.infy.apigee.file;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.infy.apigee.exceptions.APIReportException;

@Getter
@Setter
@ToString
public class FileWriter {
	private FileOutputStream fo = null;
	  
	  private String fileName = null;
	  
	  private static final String nl = System.getProperty("line.separator");
	  
	  public FileWriter(String fileName) {
	    this.fileName = fileName;
	  }
	  
	  public void open() throws APIReportException {
	    try {
	      this.fo = new FileOutputStream(this.fileName, false);
	    } catch (FileNotFoundException fnfe) {
	      throw new APIReportException(fnfe);
	    } 
	  }
	  
	  public void write(String data) throws APIReportException {
	    try {
	      this.fo.write((data + nl).getBytes("UTF-8"));
	    } catch (IOException ioe) {
	      throw new APIReportException(ioe);
	    } 
	  }
	  
	  public void close() throws APIReportException {
	    try {
	      this.fo.close();
	    } catch (IOException ioe) {
	      throw new APIReportException(ioe);
	    } 
	  }
}
