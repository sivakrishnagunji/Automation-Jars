package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiProxyMetaData {
	  private long createdAt;	  
	  private String createdBy;	  
	  private long lastModifiedAt;	  
	  private String lastModifiedBy;
}
