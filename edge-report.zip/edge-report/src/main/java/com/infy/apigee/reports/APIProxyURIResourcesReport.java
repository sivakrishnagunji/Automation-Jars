package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.Flow;
import com.infy.apigee.exceptions.APIReportException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class APIProxyURIResourcesReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(APIProxyURIResourcesReport.class);
  public APIProxyURIResourcesReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    long start = System.currentTimeMillis();
    List<List<String>> apiFinalList = new ArrayList();
    List<List<Object>> apiProxyURIResources = APIConfig.getInstance().getApiProxyURIResources();
    apiFinalList.add(Arrays.asList(new String[] { "Org Name", "Env Name", "API Proxy Name", "Rev Name", "Flow Name", "Flow Condition" }));
    if (apiProxyURIResources != null)
      for (List<Object> apiProxyURIResource : apiProxyURIResources) {
        Flow[] flows = (Flow[])apiProxyURIResource.get(4);
        for (Flow flow : flows) {
          if (flow.getCondition() != null && flow.getCondition().indexOf("/") != -1) {
            List<String> uriResourcesInner = new ArrayList();
            uriResourcesInner.add((new StringBuilder()).append(apiProxyURIResource.get(0)).append("").toString());
            uriResourcesInner.add((new StringBuilder()).append(apiProxyURIResource.get(1)).append("").toString());
            uriResourcesInner.add((new StringBuilder()).append(apiProxyURIResource.get(2)).append("").toString());
            uriResourcesInner.add((new StringBuilder()).append(apiProxyURIResource.get(3)).append("").toString());
            uriResourcesInner.add(flow.getName());
            uriResourcesInner.add(flow.getCondition());
            apiFinalList.add(uriResourcesInner);
          } 
        } 
      }  
    logger.info("[APIPLATRPT] API Proxies URI Resources Report took in ms: {}" ,(System.currentTimeMillis() - start));
    System.out.println("API Proxies URI Report Completed");
    return apiFinalList;
  }
}

