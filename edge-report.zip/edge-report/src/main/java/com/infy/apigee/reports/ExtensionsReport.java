package com.infy.apigee.reports;



import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.infy.apigee.beans.AccessToken;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.APIConfig;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ExtensionsReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(ExtensionsReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.S z"); 
  public ExtensionsReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
	  try {
	      long start = System.currentTimeMillis();
	      HTTPConnection httpConn = HTTPConnection.getInstance();
	      HttpURLConnection connection1 = null;
	      HttpURLConnection connection2 = null;
	      int j=0;
	      String accesstoken="";
	      List<List<String>> allExtensions = new ArrayList();
	      allExtensions.add(Arrays.asList(new String[] { 
	             "S.No" , "Org Name", "Environment", "Name" , "Kind", "Self" , "Created" , "CreatedBy" , "Updated" , "UpdatedBy" , "Description" , "PackageName" , "Version" , "Tenant" , "State" , "Configuration" , "Regions" , "Etag" }));
	      for (String org : orgs) {
	        String orgName = org;
	       
	        String attr = (String)props.get("Oauth2");
	       
	        String tokenresult="";
	        System.setProperty("https.protocols", "TLSv1.2");
	        URL httpurl = new URL(attr);
	        
	        connection1 = (HttpURLConnection) httpurl.openConnection();
	        connection1.setRequestMethod("POST");
	        connection1.setRequestProperty("Authorization", "Basic ZWRnZWNsaTplZGdlY2xpc2VjcmV0" ); 
	         
	         BufferedReader in = new BufferedReader(new InputStreamReader(connection1.getInputStream(), "UTF-8"));
		      String str = "";
		      
		      while ((str = in.readLine()) != null) {
		       String Oauthresult = tokenresult + str; 
		       AccessToken at = (AccessToken)this.mapper.readValue(Oauthresult, AccessToken.class);
		      accesstoken =at.getAccess_token();
		      }
		      String attr2=(String)props.get("Extensions");
		      String uri = attr2.split(",")[0];
		        
		        uri = uri.replaceAll("ORG_NAME", orgName);
		        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
		        for (String env : envs) {
		        	String uri_2 = uri.replaceAll("ENV_NAME", env);
		            String url = hostname + uri_2;
		      
		      URL httpurl2 = new URL(url);
		      connection2=(HttpURLConnection)httpurl2.openConnection();
		      connection2.setRequestProperty("Authorization", "Bearer " + accesstoken);
		     		      
		      BufferedReader results = new BufferedReader(new InputStreamReader(connection2.getInputStream(), "UTF-8"),8*1024);
		      
		      String str2;
		     
		      while((str2 = results.readLine()) != null){
		    	  String key=str2;
		    	  JSONObject collection=new JSONObject(key);
		    	 // JSONArray collection = new JSONArray(key);
		    	  String extensions = collection.get("contents").toString();
		    	  JSONArray extension = new JSONArray(extensions);
	    		   for(int i = 0;i<extension.length();i++) {
			    		  JSONObject json = extension.getJSONObject(i);	   		  
	    	    		         
			    		  List<String> csInner = new ArrayList<String>();
			    		  j++;
		    		    csInner.add(""+ j +"");
				    	csInner.add(orgName);
			            csInner.add(env);
			            csInner.add(json.get("name").toString());
			            csInner.add(json.get("kind").toString());
			            csInner.add(json.get("self").toString());			            
			            csInner.add(json.get("created").toString());
			            csInner.add(json.get("createdBy").toString());
			            csInner.add(json.get("updated").toString()); 
			            csInner.add(json.get("updatedBy").toString());
			            csInner.add(json.get("description").toString()); 			          
			           csInner.add(json.get("packageName").toString());
			            csInner.add(json.get("version").toString());
			            csInner.add(json.get("tenant").toString());
			            csInner.add(json.get("state").toString());
			            if(extension.getJSONObject(i).toString().contains("configuration")) {
			            csInner.add((json.get("configuration").toString() != null ? json.get("configuration").toString() : ""));
			            }else {
			            	csInner.add(" ");
			            }
			            
			            csInner.add(json.get("regions").toString());
			            csInner.add(json.get("etag").toString());
			       
			            allExtensions.add(csInner);
		    	  }
		    	  		    	 
			    	
		          }  
		      }    	     	  
		           
	      }
      logger.info("[APIPLATRPT] Collections Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Extensions Report Completed");
      return allExtensions;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Collections Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Collections ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Collections Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Collections Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}
