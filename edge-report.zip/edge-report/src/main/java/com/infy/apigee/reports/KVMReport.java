package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.KVMs;
import com.infy.apigee.beans.Revision;
import com.infy.apigee.beans.TargetServer;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.Entry;
import com.infy.apigee.beans.KVM;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class KVMReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(KVMReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public KVMReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
	  try {
	      long start = System.currentTimeMillis();
	      System.out.println("KVM Report");
	      HTTPConnection httpConn = HTTPConnection.getInstance();
	      List<List<String>> kvms = new ArrayList();
	      int j=0;
	      kvms.add(Arrays.asList(new String[] { 
	              "S.No" , "Org Name", "Env Name", "KVM Name", "Encrypted", "Entry Name" , " Entry Value" }));
	      for (String org : orgs) {
	        String orgName = org;
	        String attr = (String)props.get("KVMs");
	        String uri = attr.split(",")[0];
	        //Class<?> x = attr.split(",")[1].getClass();
	       String uri1 = uri.replaceAll("ORG_NAME", orgName);
	        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
	        for (String env : envs) {
	        	String uri_2 = uri1.replaceAll("ENV_NAME", env);
	            String url = hostname + uri_2;
	            String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
	          
	          String[] keyvaluemaps = (String[])this.mapper.readValue(result, String[].class);
	         
	          for (String kvm : keyvaluemaps) {
	        	String url2 = url + "/" + kvm;
	            result = httpConn.openURL(url2, APIConfig.getInstance().getUserPass());
	            /*System.out.println(result);*/
	            KVM ts = (KVM)this.mapper.readValue(result, KVM.class);
	            List<String> tsInner = new ArrayList<String>();
	             j++;
	            tsInner.add(""+ j + "");
	            tsInner.add(orgName);
	            tsInner.add(env);
	            tsInner.add(ts.getName()); 
	            tsInner.add(ts.getEncrypted());
	           // String entries = 
	           // Boolean bool = entries.isBlank();
	            JSONObject jsnobject = new JSONObject(ts);
	            JSONArray collection = jsnobject.getJSONArray("entry");
	           // JSONA collection = new JSONArray(ts.getEntry().toString());
	           // System.out.println(collection);
	            if(collection != null && collection.length() !=0) {
	            	 for(int i =0; i<collection.length(); i++)
			            {   
			            	JSONObject json = collection.getJSONObject(i);			            	
			            	
				            tsInner.add(json.toString());
				           // System.out.println(json);
			            } 
	            }else {	            	
	            	
		            tsInner.add("[]");
	            }	            
	            	            	            
	            kvms.add(tsInner);
	            
	          } }
	        } 
          
        
      
      logger.info("[APIPLATRPT] Environment KVM Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("KVM Report Completed");
      return kvms;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Environment KVM Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Environment KVM ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Environment KVM Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Environment KVM Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}


