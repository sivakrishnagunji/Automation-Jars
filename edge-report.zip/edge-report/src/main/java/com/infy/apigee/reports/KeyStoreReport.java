package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.Alias;
import com.infy.apigee.beans.Certificate;
import com.infy.apigee.beans.Certificates;
import com.infy.apigee.beans.KeystoreAlias;
import com.infy.apigee.beans.Keystores;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.file.FileWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class KeyStoreReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(KeyStoreReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);  
  private FileWriter fw = null;  
  private Date date = new Date();  
  private DateFormat format = new SimpleDateFormat("EEE  dd MMM yyyy HH:mm:ss z");  
  public KeyStoreReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> keyStores = new ArrayList();
      keyStores.add(Arrays.asList(new String[] { 
              "Org Name", "Env Name", "Keystore/Truststore Name", "Alias", "Keys", "Cert Name", "Certs", "Subject", "ValidFrom (Epoch)", "ValidFrom", 
              "Expiry Date (Epoch)", "Expiry Date", "Serial Number", "Serial Number (Decimal)", "IsValid", "SAN", "Cert Chain Depth" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("KeyStore");
        String uri = attr.split(",")[0];
        Class<?> x = attr.split(",")[1].getClass();
        String httpURI = uri.replaceAll("ORG_NAME", orgName);
        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
        for (String env : envs) {
          String uri_2 = httpURI.replaceAll("ENV_NAME", env);
          String url = hostname + uri_2;
          String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          String[] keystores = (String[])this.mapper.readValue(result, String[].class);
          for (String keystore : keystores) {
            url = hostname + uri_2 + "/" + keystore.replaceAll(" ", "%20");
            result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
            Keystores ks = (Keystores)this.mapper.readValue(result, Keystores.class);
            List<String> aliases = null;
            List<String> certsProcessed = new ArrayList();
            if (ks.getAliases() != null) {
              aliases = new ArrayList();
              for (KeystoreAlias ksa : ks.getAliases()) {
                String alias = ksa.getAliasName();
                aliases.add(alias);
                certsProcessed.add(ksa.getCert());
              } 
            } else {
              url = hostname + uri_2 + "/" + keystore + "/aliases";
              result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
              String[] aliasesArr = (String[])this.mapper.readValue(result, String[].class);
              aliases = Arrays.asList(aliasesArr);
            } 
            logger.debug("[APIPLATRPT] Total aliases on keystore " + ks.getName() + " found: " + aliases.size());
            List<String> certs = Arrays.asList(ks.getCerts());
            logger.debug("[APIPLATRPT] Total certs on keystore " + ks.getName() + " found: " + certs.size());
            List<String> certsRemaining = new ArrayList(certs);
            for (String alias : aliases) {
              url = hostname + uri_2 + "/" + keystore + "/aliases/" + alias.replaceAll(" ", "%20");
              result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
              Alias certAlias = (Alias)this.mapper.readValue(result, Alias.class);
              String aliasName = certAlias.getAlias();
              List<List<String>> keyStoresTemp = processCert(orgName, env, ks, aliasName, certAlias.getCertsInfo());
              keyStores.addAll(keyStoresTemp);
              if (ks.getAliases() == null)
                certsProcessed.add(certAlias.getCertsInfo().getCertName()); 
            } 
            logger.debug("[APIPLATRPT] Total certs on keystore " + ks.getName() + " processed: " + certsProcessed.size());
            if (certsProcessed.size() > 0)
              certsRemaining.removeAll(certsProcessed); 
            logger.debug("[APIPLATRPT] Total certs on keystore " + ks.getName() + " remaining: " + certsRemaining.size());
            for (String cert : certsRemaining) {
              url = hostname + uri_2 + "/" + keystore + "/certs/" + cert.replaceAll(" ", "%20");
              result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
              Certificates certis = (Certificates)this.mapper.readValue(result, Certificates.class);
              List<List<String>> keyStoresTemp = processCert(orgName, env, ks, "", certis);
              
              System.out.println(keyStoresTemp);
              keyStores.addAll(keyStoresTemp);
            } 
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Keystores and Certificates Report took in ms:{} ", (System.currentTimeMillis() - start));
      System.out.println("KeyStore Report Completed");
      return keyStores;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
  
  private List<List<String>> processCert(String orgName, String env, Keystores ks, String aliasName, Certificates certs) {
    List<List<String>> keyStores = new ArrayList();
    for (Certificate certificate : certs.getCertInfo()) {
      List<String> keyStoresInner = new ArrayList();
      keyStoresInner.add(orgName);
      keyStoresInner.add(env);
      keyStoresInner.add(ks.getName());
      keyStoresInner.add(aliasName);
      keyStoresInner.add(Arrays.<String>asList(ks.getKeys()).toString());
      keyStoresInner.add((certs.getCertName() != null) ? certs.getCertName() : "");
      keyStoresInner.add((certs.getName() != null) ? certs.getName() : "");
      keyStoresInner.add(certificate.getSubject().replace(',', ' '));
      String validFromEpoch = "";
      String validFrom = "";
      try {
        long valFrom = Long.parseLong(certificate.getValidFrom());
        this.date.setTime(valFrom);
        validFromEpoch = valFrom + "";
        validFrom = this.format.format(this.date);
      } catch (NumberFormatException nfe) {
        validFrom = certificate.getValidFrom().replace(',', ' ');
      } 
      keyStoresInner.add(validFromEpoch);
      keyStoresInner.add(validFrom);
      String expiryDtEpoch = "";
      String expiryDt = "";
      try {
        long expDt = Long.parseLong(certificate.getExpiryDate());
        this.date.setTime(expDt);
        expiryDtEpoch = expDt + "";
        expiryDt = this.format.format(this.date);
      } catch (NumberFormatException nfe) {
        expiryDt = certificate.getExpiryDate().replace(',', ' ');
      } 
      keyStoresInner.add(expiryDtEpoch);
      keyStoresInner.add(expiryDt);
      if (certificate.getSerialNumber() != null) {
        keyStoresInner.add(certificate.getSerialNumber());
        BigInteger bigInt = new BigInteger(certificate.getSerialNumber().replaceAll(":", ""), 16);
        keyStoresInner.add("SN=" + bigInt.toString());
      } else {
        keyStoresInner.add("");
        keyStoresInner.add("");
      } 
      keyStoresInner.add(certificate.getIsValid());
      keyStoresInner.add(Arrays.<String>asList(certificate.getSubjectAlternativeNames()).toString().replace(',', ' ').toString());
      keyStoresInner.add((certs.getCertInfo()).length + "");
      keyStores.add(keyStoresInner);
    } 
    return keyStores;
  }
}

