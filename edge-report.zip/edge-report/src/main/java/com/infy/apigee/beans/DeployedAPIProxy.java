package com.infy.apigee.beans;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DeployedAPIProxy {
	private String name;
	private Revision[] revision;
	private List<ApiProxiesRevision> apiRev = new ArrayList();
}
