package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;
import com.infy.apigee.beans.ApiProxiesRevision;
import com.infy.apigee.beans.DeployablesInEnvironment;
import com.infy.apigee.beans.DeployedAPIProxies;
import com.infy.apigee.beans.DeployedAPIProxy;
import com.infy.apigee.beans.TargetEP;
import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.BSync;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class APITargetEPThreadRunner implements IThreadRunner {
 
	public static Logger logger = LoggerFactory.getLogger(APITargetEPThreadRunner.class);
  private String[] orgs = null;  
  private String hostname = null;  
  private HTTPConnection httpConn = HTTPConnection.getInstance();  
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  private String uri;  
  private List<List<String>> apiTargets = new ArrayList();  
  private BSync bsync;
  
  public void setContext(String[] orgs, String hostname, String uri, BSync bsync) {
    this.hostname = hostname;
    this.orgs = orgs;
    this.uri = uri;
    this.bsync = bsync;
  }
  
  public List<List<String>> getResult() {
    return this.apiTargets;
  }
  
  public void run() {
    try {
      long start = System.currentTimeMillis();
      logger.info("[APIPLATRPT] Starting Thread:{} ", Thread.currentThread().getName());
      for (String org : this.orgs) {
        DeployedAPIProxies deployedApiProxies = APIConfig.getInstance().getDeployedAPIProxies(org);
        String orgName = deployedApiProxies.getName();
        for (DeployablesInEnvironment deployedApiProxy : deployedApiProxies.getEnvironment()) {
          String envName = deployedApiProxy.getName();
          DeployedAPIProxy[] apiProxies = deployedApiProxy.getAPIProxy();
          for (DeployedAPIProxy deployedAPIProxy : apiProxies) {
            String apiName = deployedAPIProxy.getName();
            for (ApiProxiesRevision apiRevs : deployedAPIProxy.getApiRev()) {
              String revName = apiRevs.getRevision();
              String httpURI = this.uri.replaceAll("ORG_NAME", orgName);
              httpURI = httpURI.replaceAll("API_NAME", apiName);
              httpURI = httpURI.replaceAll("REV_NAME", revName);
              String url = this.hostname + httpURI;
              if (apiRevs.getTargetEndpoints() != null)
                for (String targetEndpoint : apiRevs.getTargetEndpoints()) {
                  url = this.hostname + httpURI + "/targets/" + targetEndpoint.replaceAll(" ", "%20");
                  String result = this.httpConn.openURL(url, APIConfig.getInstance().getUserPass());
                 /* log.info("Target Endpoint json payload:" + result);*/
                  TargetEP tgt = (TargetEP)this.mapper.readValue(result, TargetEP.class);
                //  logger.info("Target Endpoint json payload:" + tgt);
                  List<String> apiTargetsInner = new ArrayList();
                  apiTargetsInner.add(orgName);
                  apiTargetsInner.add(envName);
                  apiTargetsInner.add(apiName);
                  apiTargetsInner.add(revName);
                  apiTargetsInner.add((tgt.getName() != null) ? tgt.getName() : "");
                  apiTargetsInner.add((tgt.getConnection().getuRL() != null) ? tgt.getConnection().getuRL() : "");
                  apiTargetsInner.add((tgt.getConnection().getProperties() != null) ? tgt.getConnection().getProperties().getUseProxy() : "");
                  apiTargetsInner.add((tgt.getConnection().getProperties() != null) ? tgt.getConnection().getProperties().getUseProxyTunnelling() : "");
                  apiTargetsInner.add((tgt.getConnection().getProperties() != null) ? tgt.getConnection().getProperties().getKeepaliveTimeout() : "");
                  apiTargetsInner.add((tgt.getConnection().getProperties() != null) ? tgt.getConnection().getProperties().getConnTimeout() : "");
                  apiTargetsInner.add((tgt.getConnection().getProperties() != null) ? tgt.getConnection().getProperties().getIOTimeout() : "");
                  apiTargetsInner.add((tgt.getConnection().getsSLInfo() != null) ? ((tgt.getConnection().getsSLInfo().getKeyAlias() != null) ? tgt.getConnection().getsSLInfo().getKeyAlias() : "") : "");
                  apiTargetsInner.add((tgt.getConnection().getsSLInfo() != null) ? ((tgt.getConnection().getsSLInfo().getKeyStore() != null) ? tgt.getConnection().getsSLInfo().getKeyStore() : "") : "");
                  apiTargetsInner.add((tgt.getConnection().getsSLInfo() != null) ? ((tgt.getConnection().getsSLInfo().getTrustStore() != null) ? tgt.getConnection().getsSLInfo().getTrustStore() : "") : "");
                  apiTargetsInner.add((tgt.getConnection().getsSLInfo() != null) ? Arrays.<Object>asList(tgt.getConnection().getsSLInfo().getProtocols()).toString() : "");
                  this.apiTargets.add(apiTargetsInner);
                }  
            } 
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Completed Thread:{}, time in ms:{} ",Thread.currentThread().getName(),(System.currentTimeMillis() - start));
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ", (Throwable)jme);
        logger.error("[APIPLATRPT] JsonMappingException occurred.{} ",jme.getMessage());
      } 
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] JsonParseException occurred.{} ", (Throwable)jpe);
        logger.error("[APIPLATRPT] JsonParseException occurred.{}",jpe.getMessage());
      } 
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] IOException occurred.{} ", ioe.getMessage());        
      } 
    } catch (APIReportException are) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] APIReportException occurred.{} ", (Throwable)are);
        logger.error("[APIPLATRPT] APIReportException occurred.{} ",are.getMessage());
      } 
    } finally {
      this.bsync.waitForAll();
    } 
  }
}
