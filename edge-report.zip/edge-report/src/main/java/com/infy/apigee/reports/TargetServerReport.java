package com.infy.apigee.reports;



import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

import com.infy.apigee.beans.TargetServer;

import com.infy.apigee.connectors.HTTPConnection;
import com.infy.apigee.exceptions.APIReportException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TargetServerReport implements IReport {
  
	public static Logger logger = LoggerFactory.getLogger(TargetServerReport.class);
  private ObjectMapper mapper = (new ObjectMapper())
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  
  
  public TargetServerReport(String env) throws APIReportException {}  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    try {
      long start = System.currentTimeMillis();
      HTTPConnection httpConn = HTTPConnection.getInstance();
      List<List<String>> targetServersAll = new ArrayList<List<String>>();
      targetServersAll.add(Arrays.asList(new String[] { 
              "Org Name", "Env Name", "Target Server Name", "Port", "Host","KeyAlias", "KeyStore", "TrustStore", "Protocols", 
              "Ciphers" }));
      for (String org : orgs) {
        String orgName = org;
        String attr = (String)props.get("TargetServer");
        String uri = attr.split(",")[0];        
        String httpURI = uri.replaceAll("ORG_NAME", orgName);
        List<String> envs = (List<String>)APIConfig.getInstance().getOrgEnvs().get(orgName);
        for (String env : envs) {
          String uri_2 = httpURI.replaceAll("ENV_NAME", env);
          String url = hostname + uri_2;
          String result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
          String[] targetServers = (String[])this.mapper.readValue(result, String[].class);
          for (String targetNS : targetServers) {
            url = hostname + uri_2 + "/" + targetNS;
            result = httpConn.openURL(url, APIConfig.getInstance().getUserPass());
            TargetServer ts = (TargetServer)this.mapper.readValue(result, TargetServer.class);
            List<String> tsInner = new ArrayList<String>();
            tsInner.add(orgName);
            tsInner.add(env);
            tsInner.add(ts.getName());
            tsInner.add(ts.getPort());
            tsInner.add(ts.getHost());            
            tsInner.add((ts.getSSLInfo() != null) ? ts.getSSLInfo().getKeyAlias() : "");
            tsInner.add((ts.getSSLInfo() != null) ? ts.getSSLInfo().getKeyStore() : "");
            tsInner.add((ts.getSSLInfo() != null) ? ((ts.getSSLInfo().getTrustStore() != null) ? ts.getSSLInfo().getTrustStore() : "") : "");
            tsInner.add((ts.getSSLInfo() != null) ? (ts.getSSLInfo().getProtocols() != null ? Arrays.<String>asList(ts.getSSLInfo().getProtocols()).toString().replace(',',' ') : "") : "");
            tsInner.add((ts.getSSLInfo() != null) ? (ts.getSSLInfo().getCiphers() != null ? Arrays.<String>asList(ts.getSSLInfo().getCiphers()).toString().replace(',',' ') : "") : "");
            
            //vHostsInner.add(Arrays.<String>asList(vh.getHostAliases()).toString().replace(',', ' ').toString());


            targetServersAll.add(tsInner);
          } 
        } 
      } 
      logger.info("[APIPLATRPT] Target Server Report took in ms:{} " ,(System.currentTimeMillis() - start));
      System.out.println("Target server Report Completed");
      return targetServersAll;
    } catch (JsonMappingException jme) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Target Server Report JsonMappingException occurred.{}",jme.getMessage());
        
      } 
      throw new APIReportException(jme);
    } catch (JsonParseException jpe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT]  Target Server ReportJsonParseException occurred.{}",jpe.getMessage());
        
      } 
      throw new APIReportException(jpe);
    } catch (IOException ioe) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Target Server Report IOException occurred.{}",ioe.getMessage());
        
      } 
      throw new APIReportException(ioe);
    } catch (Exception e) {
      if (logger.isErrorEnabled()) {
        logger.error("[APIPLATRPT] Target Server Report Exception occurred.{}",e.getMessage());
        
      } 
      throw new APIReportException(e);
    } finally {}
  }
}

