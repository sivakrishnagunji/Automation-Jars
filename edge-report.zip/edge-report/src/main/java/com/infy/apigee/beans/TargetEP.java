package com.infy.apigee.beans;

import java.util.Arrays;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TargetEP {
	 private Connection connection;	  
	  private String connectionType;	  
	  private FaultRule defaultFaultRule;	  
	  private String description;	  
	  private Object[] faultRules;	  
	  private Flow[] flows;	  
	  private String name;	  
	  private Flow preFlow;	  
	  private Flow postFlow;	  
	  private String type;
	  
	  public String toString() {
		    return "Target [connection=" + this.connection + ", connectionType=" + this.connectionType + ", defaultFaultRule=" + this.defaultFaultRule + ", description=" + this.description + ", faultRules=" + 
		      
		      Arrays.toString(this.faultRules) + ", flows=" + 
		      Arrays.toString((Object[])this.flows) + ", name=" + this.name + ", preFlow=" + this.preFlow + ", postFlow=" + this.postFlow + ", type=" + this.type + "]";
		  }
}
