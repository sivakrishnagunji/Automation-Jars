package com.infy.apigee.exceptions;

public class APIReportException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public APIReportException(Exception e) {
		super(e);
		System.out.println("Within API platform Report Exception:" + e.getMessage());
	}

	public APIReportException(String s) {
		super(s);
		System.out.println("Within API platform Report String:" + s);
	}
}
