package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VHosts {
	private String[] hostAliases;
	private String[] interfaces;
	private String name;
	private String port;
	private PropagateTLSInformation propagateTLSInformation;
	private SSLInfo sSLInfo;
	private String[] listenOptions;
	private String[] retryOptions;
	private Property properties;
}
