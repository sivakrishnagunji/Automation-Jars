package com.infy.apigee.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ResourcePermission {
	private String organization;
	private String path;
	private String[] permissions;
}
