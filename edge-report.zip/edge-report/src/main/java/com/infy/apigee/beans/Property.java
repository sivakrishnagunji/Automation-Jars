package com.infy.apigee.beans;

import java.util.HashMap;
import java.util.Map;

import lombok.ToString;

@ToString
public class Property {
	private Map<String, String> property;

	public String getProperty(String key) {
		return this.property.get(key);
	}

	public void setProperty(NameValue[] property) {
		this.property = new HashMap();
		for (NameValue nv : property)
			this.property.put(nv.getName(), nv.getValue());
	}

	public String getUseProxy() {
		return (this.property.get("use.proxy") != null) ? this.property.get("use.proxy") : "";
	}

	public String getUseProxyTunnelling() {
		return (this.property.get("use.proxy.tunneling") != null) ? this.property.get("use.proxy.tunneling") : "";
	}

	public String getKeepaliveTimeout() {
		return (this.property.get("keepalive.timeout.millis") != null) ? this.property.get("keepalive.timeout.millis")
				: "";
	}

	public String getIOTimeout() {
		return (this.property.get("io.timeout.millis") != null) ? this.property.get("io.timeout.millis") : "";
	}

	public String getConnTimeout() {
		return (this.property.get("connect.timeout.millis") != null) ? this.property.get("connect.timeout.millis") : "";
	}
}
