package com.infy.apigee.reports;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;


import com.infy.apigee.exceptions.APIReportException;
import com.infy.apigee.utils.APIConfig;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class APIProxyResourceReport implements IReport {
 
  
  public APIProxyResourceReport(String env) throws APIReportException {}
  
  public List<List<String>> generateReport(String hostname, Properties props, String[] orgs) throws APIReportException {
    long start = System.currentTimeMillis();
    List<List<String>> apiResources = APIConfig.getInstance().getApiResources();
    apiResources.add(0, Arrays.asList(new String[] { "Org Name", "Env Name", "API Proxy Name", "Rev Name", "Resource Name", "Resource Type" }));
    log.info("[APIPLATRPT] API Proxies Resources Report took:{} " ,(System.currentTimeMillis() - start));
    System.out.println("API Proxies Resource Report Completed");
    return apiResources;
  }
}
